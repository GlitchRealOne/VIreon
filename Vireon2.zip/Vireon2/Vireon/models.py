"""
Database models for the Discord security bot.
"""

import os
from datetime import datetime
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    pass


db = SQLAlchemy(model_class=Base)

# Create the app
app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY") or "a secret key"
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
    "connect_args": {
        "connect_timeout": 5,
    }
}

# Initialize the app with the extension
db.init_app(app)





class ServerBackup(db.Model):
    """Model for storing server backup information."""
    __tablename__ = 'server_backup'
    
    id = db.Column(db.Integer, primary_key=True)
    guild_id = db.Column(db.String(20), nullable=False)
    guild_name = db.Column(db.String(100), nullable=False)
    backup_data = db.Column(db.JSON, nullable=False)  # JSON data of server structure
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    created_by = db.Column(db.String(20), nullable=False)  # Discord user ID
    
    def __repr__(self):
        return f'<ServerBackup {self.guild_name} ({self.guild_id})>'


class VerificationData(db.Model):
    """Model for storing user verification data."""
    __tablename__ = 'verification_data'
    
    id = db.Column(db.Integer, primary_key=True)
    guild_id = db.Column(db.String(20), nullable=False)
    user_id = db.Column(db.String(20), nullable=False)
    verification_code = db.Column(db.String(10), nullable=False)
    is_verified = db.Column(db.Boolean, default=False)
    verified_at = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime, nullable=False)
    
    # Composite unique constraint
    __table_args__ = (db.UniqueConstraint('guild_id', 'user_id', name='_guild_user_uc'),)
    
    def __repr__(self):
        return f'<VerificationData {self.user_id} in {self.guild_id}>'


class RaidAlert(db.Model):
    """Model for tracking raid attempts and anti-raid actions."""
    __tablename__ = 'raid_alert'
    
    id = db.Column(db.Integer, primary_key=True)
    guild_id = db.Column(db.String(20), nullable=False)
    alert_type = db.Column(db.String(50), nullable=False)  # 'mass_join', 'mass_message', 'suspicious_activity'
    user_count = db.Column(db.Integer, default=1)
    action_taken = db.Column(db.String(100), nullable=False)  # 'lockdown', 'ban', 'kick', 'alert_only'
    detected_at = db.Column(db.DateTime, default=datetime.utcnow)
    resolved_at = db.Column(db.DateTime, nullable=True)
    is_active = db.Column(db.Boolean, default=True)
    
    def __repr__(self):
        return f'<RaidAlert {self.alert_type} in {self.guild_id}>'


class GuildSettings(db.Model):
    """Model for storing guild-specific security settings."""
    __tablename__ = 'guild_settings'
    
    id = db.Column(db.Integer, primary_key=True)
    guild_id = db.Column(db.String(20), unique=True, nullable=False)
    
    # Anti-raid settings
    anti_raid_enabled = db.Column(db.Boolean, default=True)
    join_rate_limit = db.Column(db.Integer, default=5)  # Max joins per minute
    mass_mention_limit = db.Column(db.Integer, default=3)  # Max mentions per message
    
    # Verification settings
    verification_enabled = db.Column(db.Boolean, default=False)
    verification_channel_id = db.Column(db.String(20), nullable=True)
    verified_role_id = db.Column(db.String(20), nullable=True)
    
    # Backup settings
    auto_backup_enabled = db.Column(db.Boolean, default=True)
    backup_frequency = db.Column(db.Integer, default=24)  # Hours between backups
    last_backup = db.Column(db.DateTime, nullable=True)
    
    # Security settings
    auto_ban_scammers = db.Column(db.Boolean, default=True)
    log_channel_id = db.Column(db.String(20), nullable=True)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<GuildSettings {self.guild_id}>'


def init_db():
    """Initialize the database with all tables."""
    try:
        # Check if DATABASE_URL is available
        database_url = os.environ.get("DATABASE_URL")
        if not database_url:
            return False
            
        # Test connection with timeout
        import sqlalchemy
        from sqlalchemy import text
        
        # Create engine with shorter timeout
        engine = sqlalchemy.create_engine(
            database_url,
            pool_timeout=3,
            pool_pre_ping=True,
            connect_args={'connect_timeout': 3}
        )
        
        # Quick connection test
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        
        # If we get here, connection is good
        with app.app_context():
            db.create_all()
            return True
            
    except Exception:
        # Silently fail and use fallback mode
        return False


if __name__ == "__main__":
    init_db()