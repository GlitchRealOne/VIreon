#!/usr/bin/env python3
"""
Web Dashboard for Discord Security Bot
Provides a web interface for managing scammers and security settings.
"""

import json
import asyncio
from datetime import datetime
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
import os
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'vireon-security-bot-dashboard-2025')

# Configure database with better connection handling
database_url = os.environ.get('DATABASE_URL')
if database_url:
    # Add SSL configuration for better connection stability
    if 'sslmode' not in database_url:
        database_url += '?sslmode=require'
    app.config['SQLALCHEMY_DATABASE_URI'] = database_url
else:
    # Fallback to SQLite for testing
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///scammer_db.sqlite'

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
    'pool_pre_ping': True,
    'pool_recycle': 300,
    'pool_timeout': 20,
    'max_overflow': 0
}

db = SQLAlchemy()
db.init_app(app)

# Database Models
class ScammerEntry(db.Model):
    """Database model for scammer entries."""
    __tablename__ = 'scammer_entries'
    
    id = db.Column(db.Integer, primary_key=True)
    discord_id = db.Column(db.String(20), unique=True, nullable=True)
    username = db.Column(db.String(100), nullable=False)
    discriminator = db.Column(db.String(10), nullable=True)
    reason = db.Column(db.Text, nullable=False)
    evidence_url = db.Column(db.String(500), nullable=True)
    added_by = db.Column(db.String(100), nullable=False)
    added_at = db.Column(db.DateTime, default=datetime.utcnow)
    severity = db.Column(db.String(20), default='medium')  # low, medium, high, critical
    status = db.Column(db.String(20), default='active')  # active, resolved, false_positive
    notes = db.Column(db.Text, nullable=True)

class AutoBanLog(db.Model):
    """Log of automatic bans performed by the bot."""
    __tablename__ = 'auto_ban_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    guild_id = db.Column(db.String(20), nullable=False)
    guild_name = db.Column(db.String(100), nullable=False)
    user_id = db.Column(db.String(20), nullable=False)
    username = db.Column(db.String(100), nullable=False)
    scammer_entry_id = db.Column(db.Integer, db.ForeignKey('scammer_entries.id'), nullable=False)
    banned_at = db.Column(db.DateTime, default=datetime.utcnow)
    ban_reason = db.Column(db.Text, nullable=False)

# Database initialization with error handling
def init_database():
    """Initialize database with proper error handling."""
    try:
        with app.app_context():
            db.create_all()
            # Only print success message once by checking if we're in the main process
            if os.environ.get('WERKZEUG_RUN_MAIN') != 'true':
                print("✅ Database tables created successfully")
            return True
    except Exception as e:
        print(f"❌ Database initialization failed: {e}")
        return False

# Initialize database
db_available = init_database()

@app.route('/')
def dashboard():
    """Main dashboard showing overview."""
    if not db_available:
        return render_template('error.html', 
                             error="Database connection unavailable. Please check your DATABASE_URL configuration.")
    
    try:
        total_scammers = ScammerEntry.query.filter_by(status='active').count()
        total_bans = AutoBanLog.query.count()
        recent_scammers = ScammerEntry.query.order_by(ScammerEntry.added_at.desc()).limit(10).all()
        recent_bans = AutoBanLog.query.order_by(AutoBanLog.banned_at.desc()).limit(10).all()
        
        return render_template('dashboard.html', 
                             total_scammers=total_scammers,
                             total_bans=total_bans,
                             recent_scammers=recent_scammers,
                             recent_bans=recent_bans)
    except Exception as e:
        app.logger.error(f"Dashboard error: {e}")
        return render_template('error.html', error=f"Database error: {str(e)}")

@app.route('/scammers')
def list_scammers():
    """List all scammer entries."""
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    severity = request.args.get('severity', '')
    status = request.args.get('status', 'active')
    
    query = ScammerEntry.query
    
    if search:
        query = query.filter(
            (ScammerEntry.username.contains(search)) |
            (ScammerEntry.discord_id.contains(search)) |
            (ScammerEntry.reason.contains(search))
        )
    
    if severity:
        query = query.filter_by(severity=severity)
        
    if status:
        query = query.filter_by(status=status)
    
    scammers = query.order_by(ScammerEntry.added_at.desc()).paginate(
        page=page, per_page=20, error_out=False
    )
    
    return render_template('scammers.html', scammers=scammers, search=search, 
                         severity=severity, status=status)

@app.route('/add_scammer', methods=['GET', 'POST'])
def add_scammer():
    """Add a new scammer entry."""
    if request.method == 'POST':
        username = request.form['username'].strip()
        discord_id = request.form.get('discord_id', '').strip() or None
        reason = request.form['reason'].strip()
        evidence_url = request.form.get('evidence_url', '').strip() or None
        severity = request.form['severity']
        notes = request.form.get('notes', '').strip() or None
        added_by = request.form['added_by'].strip()
        
        # Extract discriminator if username contains #
        discriminator = None
        if '#' in username:
            username, discriminator = username.split('#', 1)
        
        # Check if already exists
        existing = ScammerEntry.query.filter_by(username=username, discriminator=discriminator).first()
        if existing and existing.status == 'active':
            flash(f'Scammer "{username}" is already in the database!', 'warning')
            return redirect(url_for('add_scammer'))
        
        # Create new entry
        scammer = ScammerEntry(
            username=username,
            discriminator=discriminator,
            discord_id=discord_id,
            reason=reason,
            evidence_url=evidence_url,
            severity=severity,
            notes=notes,
            added_by=added_by
        )
        
        db.session.add(scammer)
        db.session.commit()
        
        flash(f'Successfully added scammer: {username}', 'success')
        return redirect(url_for('list_scammers'))
    
    return render_template('add_scammer.html')

@app.route('/scammer/<int:scammer_id>')
def view_scammer(scammer_id):
    """View detailed information about a scammer."""
    scammer = ScammerEntry.query.get_or_404(scammer_id)
    ban_logs = AutoBanLog.query.filter_by(scammer_entry_id=scammer_id).order_by(AutoBanLog.banned_at.desc()).all()
    
    return render_template('view_scammer.html', scammer=scammer, ban_logs=ban_logs)

@app.route('/update_scammer/<int:scammer_id>', methods=['POST'])
def update_scammer(scammer_id):
    """Update scammer status or notes."""
    scammer = ScammerEntry.query.get_or_404(scammer_id)
    
    action = request.form['action']
    if action == 'resolve':
        scammer.status = 'resolved'
        flash('Marked scammer as resolved', 'success')
    elif action == 'false_positive':
        scammer.status = 'false_positive'
        flash('Marked as false positive', 'info')
    elif action == 'reactivate':
        scammer.status = 'active'
        flash('Reactivated scammer entry', 'warning')
    elif action == 'update_notes':
        scammer.notes = request.form['notes']
        flash('Updated notes', 'success')
    
    db.session.commit()
    return redirect(url_for('view_scammer', scammer_id=scammer_id))

@app.route('/ban_logs')
def ban_logs():
    """View all auto-ban logs."""
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    
    query = AutoBanLog.query
    
    if search:
        query = query.filter(
            (AutoBanLog.username.contains(search)) |
            (AutoBanLog.guild_name.contains(search)) |
            (AutoBanLog.user_id.contains(search))
        )
    
    logs = query.order_by(AutoBanLog.banned_at.desc()).paginate(
        page=page, per_page=25, error_out=False
    )
    
    return render_template('ban_logs.html', logs=logs, search=search)

@app.route('/api/check_scammer/<user_id>')
def api_check_scammer(user_id):
    """API endpoint to check if a user is a known scammer."""
    scammer = ScammerEntry.query.filter_by(discord_id=user_id, status='active').first()
    
    if scammer:
        return jsonify({
            'is_scammer': True,
            'id': scammer.id,
            'reason': scammer.reason,
            'severity': scammer.severity,
            'added_by': scammer.added_by,
            'added_at': scammer.added_at.isoformat()
        })
    
    return jsonify({'is_scammer': False})

@app.route('/api/check_scammer_by_username/<username>')
def api_check_scammer_by_username(username):
    """API endpoint to check if a username is a known scammer."""
    # Handle username with discriminator
    discriminator = None
    if '#' in username:
        username, discriminator = username.split('#', 1)
    
    query = ScammerEntry.query.filter_by(username=username, status='active')
    if discriminator:
        query = query.filter_by(discriminator=discriminator)
    
    scammer = query.first()
    
    if scammer:
        return jsonify({
            'is_scammer': True,
            'id': scammer.id,
            'reason': scammer.reason,
            'severity': scammer.severity,
            'added_by': scammer.added_by,
            'added_at': scammer.added_at.isoformat()
        })
    
    return jsonify({'is_scammer': False})

@app.route('/api/log_ban', methods=['POST'])
def api_log_ban():
    """API endpoint to log an automatic ban."""
    data = request.get_json()
    
    ban_log = AutoBanLog(
        guild_id=data['guild_id'],
        guild_name=data['guild_name'],
        user_id=data['user_id'],
        username=data['username'],
        scammer_entry_id=data['scammer_entry_id'],
        ban_reason=data['ban_reason']
    )
    
    db.session.add(ban_log)
    db.session.commit()
    
    return jsonify({'success': True, 'log_id': ban_log.id})

@app.route('/export_scammers')
def export_scammers():
    """Export scammer database as JSON."""
    scammers = ScammerEntry.query.filter_by(status='active').all()
    
    export_data = []
    for scammer in scammers:
        export_data.append({
            'id': scammer.id,
            'discord_id': scammer.discord_id,
            'username': scammer.username,
            'discriminator': scammer.discriminator,
            'reason': scammer.reason,
            'evidence_url': scammer.evidence_url,
            'added_by': scammer.added_by,
            'added_at': scammer.added_at.isoformat(),
            'severity': scammer.severity,
            'notes': scammer.notes
        })
    
    return jsonify(export_data)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000, debug=True)