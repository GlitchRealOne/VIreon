# Discord Security Bot Project

## Project Overview
A comprehensive Discord security bot designed to enhance server safety and administration through advanced moderation tools and intelligent protection mechanisms. The bot focuses on protective security features rather than destructive operations.

## Recent Changes
- **Duplicate Message Fix** (Current): Fixed duplicate message issue in Discord bot commands
  - Fixed ping and help commands sending multiple responses
  - Added override for on_message handler to control command processing
  - Prevented conflicts between multiple cog event handlers
  - Bot now responds only once per command instead of 2-3 times
- **Bug Fixes & Clear Command**: Fixed dictionary attribute error and added message clearing functionality
  - Fixed 'dict' object has no attribute 'log_channel_id' error in lockdown system
  - Added `!clear` / `!purge` command for deleting messages (1-100, with confirmation for >50)
  - Added `/clear` slash command with channel and amount parameters
  - Enhanced help menu to include clear command documentation
  - Bot now syncs 22 total slash commands (including /lockdown, /emergency-lock, /unlock, /clear)
- **Enhanced Help Menu & Slash Commands**: Added comprehensive slash command support for lockdown features
  - Added `/lockdown` slash command with duration parameter support (including 'permanent')
  - Added `/emergency-lock` slash command for complete server lockdown 
  - Added `/unlock` slash command for removing any lockdown
  - Updated help menu to clearly show `!lock perm` and `!elock` options
- **Verification Bug Fix**: Fixed role hierarchy bug in verification system
  - Fixed bug where verification role setup failed with "higher than me" error when bot and role had equal positions
  - Updated both regular and slash command versions of setup-verification
  - Changed role position check from `>=` to `>` to allow equal position roles
- **Enhanced Lockdown System**: Added emergency lockdown and permanent lock options
  - Added `!emergency-lock` / `!elock` command for complete server lockdown (text + voice channels)
  - Modified `!lock` / `!lockdown` to support permanent duration option
  - Enhanced unlock system to handle both regular and emergency lockdowns
- **Scammer Auto-Ban System Complete**: Added web dashboard for managing scammers + automatic banning across all servers
- **Web Dashboard Added**: Full scammer management interface at port 3000 with database integration
- **Auto-Ban Integration**: Bot automatically bans known scammers when they join any server with auto-ban enabled
- **PostgreSQL Database**: Connected to database for persistent scammer data and ban logging

## User Preferences
- **Security Focus**: User wants security-only documentation without references to destructive operations
- **Clean Documentation**: Remove any mentions of "nuke bot" or destructive capabilities
- **Protective Language**: Focus on protection, containment, and security rather than destruction

## Project Architecture
- **Python-based Discord bot infrastructure**
- **Modular security and verification modules** 
- **Configurable admin and moderation commands**
- **Environment-based configuration management**
- **Interactive help and user experience features**

### Key Components:
- `main.py` - Main bot entry point with AdminBot class
- `security_bot/` - Security modules directory
  - `admin_commands.py` - Administrative command handlers
  - `security_commands.py` - Security and protection commands
  - `automod_commands.py` - Automated moderation system with bad word filtering
  - `verification_commands.py` - User verification system
  - `permissions.py` - Role-based access control
  - `utils.py` - Utility functions for embeds and responses
  - `message_logging.py` - Activity logging system
- `scammer_auto_ban.py` - Auto-ban system for known scammers
- `web_dashboard.py` - Flask web interface for scammer management (port 3000)
- `templates/` - HTML templates for web dashboard
- `config.py` - Bot configuration management
- `models.py` - Database models for threat intelligence
- `database_wrapper.py` - Database connection management

## Technical Notes
- Uses PostgreSQL database for scammer data and ban logging
- Web dashboard running on port 3000 for scammer management
- Auto-ban system checks users on join against database
- Implements multi-layer permission system
- Includes anti-raid, verification, and AutoMod systems
- Features automated backup and recovery capabilities
- Real-time scammer detection with severity levels

## Deployment
- Uses Replit workflows for bot execution
- Environment variables stored securely in .env
- Database integration for persistent threat data
- Comprehensive logging system in place