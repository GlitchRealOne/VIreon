
#!/usr/bin/env python3
"""
This test bot has been replaced by main.py
Use main.py for the full Discord security bot instead.
"""

import sys

def main():
    print("=" * 50)
    print("❌ TEST BOT DEPRECATED")
    print("=" * 50)
    print("This test bot is no longer in use.")
    print("Please use the main Discord security bot instead:")
    print("")
    print("  python main.py")
    print("")
    print("The main bot includes all security features:")
    print("• Anti-raid protection")
    print("• Message logging")
    print("• AutoMod system")
    print("• Scammer auto-ban")
    print("• Verification system")
    print("=" * 50)

if __name__ == "__main__":
    main()
