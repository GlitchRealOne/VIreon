"""
Database wrapper to handle database operations gracefully when DB is unavailable.
"""

import logging
import os
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta

# Suppress SQLAlchemy warnings when database is unavailable
logging.getLogger('sqlalchemy.engine').setLevel(logging.ERROR)
logging.getLogger('sqlalchemy.pool').setLevel(logging.ERROR)

logger = logging.getLogger(__name__)

class DatabaseWrapper:
    """Wrapper class to handle database operations with fallback when DB is unavailable."""

    def __init__(self, db_available: bool = False):
        self.db_available = db_available
        self._fallback_data = {
            'backups': {},
            'verifications': {},
            'settings': {},
            'activity_logs': {}
        }

    def set_availability(self, available: bool):
        """Update database availability status."""
        self.db_available = available

    

    def get_guild_settings(self, guild_id: str) -> Dict[str, Any]:
        """Get guild settings from database or return defaults."""
        if self.db_available:
            try:
                from models import GuildSettings, app
                with app.app_context():
                    settings = GuildSettings.query.filter_by(guild_id=guild_id).first()
                    if settings:
                        return {
                            'guild_id': guild_id,
                            'anti_raid_enabled': settings.anti_raid_enabled,
                            'join_rate_limit': settings.join_rate_limit,
                            'mass_mention_limit': settings.mass_mention_limit,
                            'verification_enabled': settings.verification_enabled,
                            'verification_channel_id': settings.verification_channel_id,
                            'verified_role_id': settings.verified_role_id,
                            'auto_backup_enabled': settings.auto_backup_enabled,
                            'auto_ban_scammers': settings.auto_ban_scammers,
                            'log_channel_id': settings.log_channel_id
                        }
            except Exception as e:
                logger.warning(f"Database operation failed, using fallback: {e}")
                self.db_available = False # Mark as unavailable on error

        # Check fallback storage first
        if guild_id in self._fallback_data.get('settings', {}):
            return self._fallback_data['settings'][guild_id]

        # Return default settings if DB unavailable or no settings found for guild
        default_settings = {
            'guild_id': guild_id,
            'anti_raid_enabled': True,
            'join_rate_limit': 5,
            'mass_mention_limit': 3,
            'verification_enabled': False,
            'verification_channel_id': None,
            'verified_role_id': None,
            'auto_backup_enabled': True,
            'auto_ban_scammers': True,
            'log_channel_id': None
        }

        # Store in fallback for consistency
        if 'settings' not in self._fallback_data:
            self._fallback_data['settings'] = {}
        self._fallback_data['settings'][guild_id] = default_settings

        return default_settings

    def store_guild_settings(self, settings: Dict[str, Any]) -> bool:
        """Store guild settings to database or fallback storage."""
        guild_id = settings.get('guild_id')
        if not guild_id:
            return False

        if self.db_available:
            try:
                from models import GuildSettings, db, app
                with app.app_context():
                    existing_settings = GuildSettings.query.filter_by(guild_id=guild_id).first()
                    if existing_settings:
                        # Update existing settings
                        for key, value in settings.items():
                            if hasattr(existing_settings, key):
                                setattr(existing_settings, key, value)
                    else:
                        # Create new settings
                        new_settings = GuildSettings()
                        for key, value in settings.items():
                            if hasattr(new_settings, key):
                                setattr(new_settings, key, value)
                        db.session.add(new_settings)

                    db.session.commit()
                    return True
            except Exception as e:
                logger.warning(f"Database operation failed, using fallback: {e}")
                self.db_available = False

        # Fallback storage
        if 'settings' not in self._fallback_data:
            self._fallback_data['settings'] = {}

        self._fallback_data['settings'][guild_id] = settings
        return True

    def store_backup(self, guild_id: str, guild_name: str, backup_data: dict, created_by: str) -> bool:
        """Store a server backup."""
        if self.db_available:
            try:
                from models import ServerBackup, db, app
                with app.app_context():
                    backup = ServerBackup()
                    backup.guild_id = guild_id
                    backup.guild_name = guild_name
                    backup.backup_data = backup_data
                    backup.created_by = created_by
                    db.session.add(backup)
                    db.session.commit()
                    return True
            except Exception as e:
                logger.warning(f"Database backup failed, using fallback: {e}")
                self.db_available = False # Mark as unavailable on error

        # Fallback storage
        # Generate a unique ID for fallback data, could use UUID or timestamp for better uniqueness
        backup_id = f"{guild_id}_{datetime.utcnow().strftime('%Y%m%d%H%M%S%f')}"
        self._fallback_data['backups'][backup_id] = {
            'id': backup_id, # Store the generated ID
            'guild_id': guild_id,
            'guild_name': guild_name,
            'backup_data': backup_data,
            'created_by': created_by,
            'created_at': 'Recently', # Fallback doesn't store exact time
            'channel_count': len(backup_data.get('channels', [])),
            'role_count': len(backup_data.get('roles', []))
        }
        return True

    def create_backup(self, guild_id: str, guild_name: str, backup_data: dict, created_by: str) -> int:
        """Create a new backup and return its ID."""
        if self.db_available:
            try:
                from models import ServerBackup, app
                with app.app_context():
                    backup = ServerBackup()
                    backup.guild_id = guild_id
                    backup.guild_name = guild_name
                    backup.backup_data = backup_data
                    backup.created_by = created_by
                    from models import db
                    db.session.add(backup)
                    db.session.commit()
                    return backup.id
            except Exception as e:
                logger.warning(f"Database backup creation failed, using fallback: {e}")
                self.db_available = False

        # Fallback storage
        backup_id = len(self._fallback_data['backups']) + 1
        self._fallback_data['backups'][backup_id] = {
            'id': backup_id,
            'guild_id': guild_id,
            'guild_name': guild_name,
            'backup_data': backup_data,
            'created_by': created_by,
            'created_at': datetime.utcnow().strftime('%Y-%m-%d %H:%M'),
            'channel_count': len(backup_data.get('channels', [])),
            'role_count': len(backup_data.get('roles', []))
        }
        return backup_id

    def get_backups(self, guild_id: str) -> List[Dict[str, Any]]:
        """Get all backups for a guild."""
        if self.db_available:
            try:
                from models import ServerBackup, app
                with app.app_context():
                    backups = ServerBackup.query.filter_by(guild_id=guild_id).order_by(ServerBackup.created_at.desc()).limit(10).all()
                    return [
                        {
                            'id': b.id,
                            'guild_name': b.guild_name,
                            'created_by': b.created_by,
                            'created_at': b.created_at.strftime('%Y-%m-%d %H:%M'),
                            'channel_count': len(b.backup_data.get('channels', [])),
                            'role_count': len(b.backup_data.get('roles', []))
                        }
                        for b in backups
                    ]
            except Exception as e:
                logger.warning(f"Database query failed, using fallback: {e}")
                self.db_available = False # Mark as unavailable on error

        # Fallback storage
        guild_backups = []
        for backup_id, backup in self._fallback_data['backups'].items():
            if backup['guild_id'] == guild_id:
                guild_backups.append(backup)

        # Sort by ID in descending order for most recent first
        return sorted(guild_backups, key=lambda x: x['id'], reverse=True)

    def store_verification(self, guild_id: str, user_id: str, code: str, expires_minutes: int) -> bool:
        """Store verification data."""
        if 'verifications' not in self._fallback_data:
            self._fallback_data['verifications'] = {}

        key = f"{guild_id}:{user_id}"
        self._fallback_data['verifications'][key] = {
            'code': code,
            'expires_at': datetime.utcnow() + timedelta(minutes=expires_minutes),
            'is_verified': False,
            'created_at': datetime.utcnow()
        }
        return True

    def get_verification(self, guild_id: str, user_id: str) -> Optional[Dict[str, Any]]:
        """Get verification data for a user."""
        key = f"{guild_id}:{user_id}"
        return self._fallback_data.get('verifications', {}).get(key)

    def check_verification(self, guild_id: str, user_id: str, code: str) -> str:
        """Check verification code and mark as verified if correct."""
        key = f"{guild_id}:{user_id}"
        verification_data = self._fallback_data.get('verifications', {}).get(key)

        if not verification_data:
            return "invalid"

        if verification_data.get("expires_at") < datetime.utcnow():
            # Optionally remove expired verification from fallback
            # del self._fallback_data['verifications'][key]
            return "expired"

        if verification_data.get("is_verified"):
            return "already_verified"

        if verification_data.get("code") == code:
            verification_data["is_verified"] = True
            verification_data["verified_at"] = datetime.utcnow()
            self._fallback_data['verifications'][key] = verification_data
            return "success"

        return "invalid"

    def count_verifications(self, guild_id: str, is_verified: bool = None, days: int = None) -> int:
        """Count verifications for a guild with optional filters."""
        count = 0
        cutoff_date = datetime.utcnow() - timedelta(days=days) if days else None

        for key, verification_data in self._fallback_data.get('verifications', {}).items():
            if not key.startswith(f"{guild_id}:"):
                continue

            # Filter by verification status
            if is_verified is not None and verification_data.get("is_verified") != is_verified:
                continue

            # Filter by date if specified
            if cutoff_date:
                created_at = verification_data.get("created_at") # Use created_at for filtering by days
                if not created_at or created_at < cutoff_date:
                    continue

            count += 1

        return count

    def log_activity(self, guild_id: str, event_type: str, event_description: str):
        """Log an activity event."""
        if 'activity_logs' not in self._fallback_data:
            self._fallback_data['activity_logs'] = {}

        if guild_id not in self._fallback_data['activity_logs']:
            self._fallback_data['activity_logs'][guild_id] = []

        # Add new log entry
        log_entry = {
            'timestamp': datetime.utcnow().strftime('%H:%M:%S'),
            'event_type': event_type,
            'event': event_description
        }

        self._fallback_data['activity_logs'][guild_id].insert(0, log_entry)

        # Keep only last 100 entries
        if len(self._fallback_data['activity_logs'][guild_id]) > 100:
            self._fallback_data['activity_logs'][guild_id] = self._fallback_data['activity_logs'][guild_id][:100]

    def get_activity_logs(self, guild_id: str, limit: int = 20) -> List[Dict[str, Any]]:
        """Get activity logs for a guild."""
        if guild_id not in self._fallback_data.get('activity_logs', {}):
            return []

        logs = self._fallback_data['activity_logs'][guild_id][:limit]
        return logs

    def get_status(self) -> Dict[str, Any]:
        """Get database status and fallback data counts."""
        return {
            'database_available': self.db_available,
            'fallback_backups': len(self._fallback_data.get('backups', {})),
            'fallback_verifications': len(self._fallback_data.get('verifications', {}))
        }

# Global database wrapper instance
db_wrapper = DatabaseWrapper()