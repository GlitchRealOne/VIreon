
#!/usr/bin/env python3
"""
Discord Server Administration Bot
Main entry point for the bot application.
"""

import asyncio
import logging
import os
from dotenv import load_dotenv
import discord
from discord.ext import commands

from security_bot.admin_commands import AdminCommands
from security_bot.security_commands import SecurityCommands
from security_bot.verification_commands import VerificationCommands
from security_bot.message_logging import MessageLogging
from security_bot.permissions import PermissionManager
from config import BOT_CONFIG
from database_wrapper import db_wrapper
from health_server import HealthServer

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('bot.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

class AdminBot(commands.Bot):
    """Main bot class with enhanced administrative features."""

    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.guilds = True
        # Note: members intent requires enabling in Discord Developer Portal
        try:
            intents.members = True
        except:
            # Fallback if members intent not enabled
            pass

        # Single prefix for all commands
        def get_prefix(bot, message):
            return BOT_CONFIG['prefix']

        super().__init__(
            command_prefix=get_prefix,
            intents=intents,
            help_command=None
        )

        self.permission_manager = PermissionManager()

    async def setup_hook(self):
        """Initialize bot components."""
        logger.info("Setting up bot components...")

        # Initialize database wrapper in memory-only mode
        self.db_available = False
        db_wrapper.set_availability(False)
        logger.info("📝 Running in memory-only mode")

        # Add cogs
        try:
            await self.add_cog(AdminCommands(self))
            # Skip SecurityCommands if database unavailable to prevent errors
            if self.db_available:
                await self.add_cog(SecurityCommands(self))
            await self.add_cog(VerificationCommands(self))
            await self.add_cog(MessageLogging(self))
            logger.info("✅ All cogs loaded successfully")
        except Exception as e:
            logger.error(f"Failed to load cogs: {e}")
            return

        logger.info("Bot setup complete!")

    async def on_ready(self):
        """Called when bot is ready."""
        logger.info(f'{self.user} has connected to Discord!')
        logger.info(f'Bot is in {len(self.guilds)} guilds')

        # Set bot activity
        activity = discord.Activity(
            type=discord.ActivityType.watching,
            name="for raids & protecting servers"
        )
        await self.change_presence(activity=activity)

    async def log_to_channel(self, guild, event_type, description, color=discord.Color.orange()):
        """Log events to the configured log channel."""
        # Get guild settings to find log channel
        settings = db_wrapper.get_guild_settings(str(guild.id))
        log_channel_id = settings.get('log_channel_id')
        
        if not log_channel_id:
            return  # No log channel configured
            
        try:
            channel = guild.get_channel(int(log_channel_id))
            if channel and hasattr(channel, 'send'):
                embed = discord.Embed(
                    title=f"📋 {event_type}",
                    description=description,
                    color=color,
                    timestamp=discord.utils.utcnow()
                )
                embed.set_footer(text=f"Server: {guild.name}")
                await channel.send(embed=embed)
        except (discord.Forbidden, discord.NotFound, ValueError):
            pass  # Log channel not accessible or invalid

    async def on_message_delete(self, message):
        """Log deleted messages."""
        if message.author.bot or not message.guild:
            return
            
        description = (
            f"**Message deleted in {message.channel.mention}**\n"
            f"**Author:** {message.author.mention} ({message.author})\n"
            f"**Content:** {message.content[:1000] if message.content else '*No text content*'}\n"
            f"**Message ID:** {message.id}"
        )
        
        if message.attachments:
            description += f"\n**Attachments:** {len(message.attachments)} file(s)"
            
        await self.log_to_channel(message.guild, "Message Deleted", description, discord.Color.red())

    async def on_message_edit(self, before, after):
        """Log edited messages."""
        if before.author.bot or not before.guild or before.content == after.content:
            return
            
        description = (
            f"**Message edited in {before.channel.mention}**\n"
            f"**Author:** {before.author.mention} ({before.author})\n"
            f"**Before:** {before.content[:500] if before.content else '*No content*'}\n"
            f"**After:** {after.content[:500] if after.content else '*No content*'}\n"
            f"**Message ID:** {before.id}"
        )
        
        await self.log_to_channel(before.guild, "Message Edited", description, discord.Color.orange())

    async def on_member_join(self, member):
        """Log when members join."""
        description = (
            f"**{member.mention} joined the server**\n"
            f"**Account created:** <t:{int(member.created_at.timestamp())}:R>\n"
            f"**User ID:** {member.id}\n"
            f"**Member count:** {member.guild.member_count}"
        )
        
        await self.log_to_channel(member.guild, "Member Joined", description, discord.Color.green())

    async def on_member_remove(self, member):
        """Log when members leave."""
        description = (
            f"**{member} left the server**\n"
            f"**User ID:** {member.id}\n"
            f"**Joined:** <t:{int(member.joined_at.timestamp())}:R>\n" if member.joined_at else "**Joined:** Unknown\n"
            f"**Member count:** {member.guild.member_count}"
        )
        
        await self.log_to_channel(member.guild, "Member Left", description, discord.Color.red())

    async def on_member_ban(self, guild, user):
        """Log when members are banned."""
        try:
            ban_entry = None
            async for entry in guild.audit_logs(action=discord.AuditLogAction.ban, limit=1):
                if entry.target.id == user.id:
                    ban_entry = entry
                    break
            
            moderator = ban_entry.user if ban_entry else "Unknown"
            reason = ban_entry.reason if ban_entry and ban_entry.reason else "No reason provided"
            
            description = (
                f"**{user} was banned**\n"
                f"**Moderator:** {moderator}\n"
                f"**Reason:** {reason}\n"
                f"**User ID:** {user.id}"
            )
        except:
            description = f"**{user} was banned**\n**User ID:** {user.id}"
            
        await self.log_to_channel(guild, "Member Banned", description, discord.Color.dark_red())

    async def on_member_unban(self, guild, user):
        """Log when members are unbanned."""
        try:
            unban_entry = None
            async for entry in guild.audit_logs(action=discord.AuditLogAction.unban, limit=1):
                if entry.target.id == user.id:
                    unban_entry = entry
                    break
            
            moderator = unban_entry.user if unban_entry else "Unknown"
            
            description = (
                f"**{user} was unbanned**\n"
                f"**Moderator:** {moderator}\n"
                f"**User ID:** {user.id}"
            )
        except:
            description = f"**{user} was unbanned**\n**User ID:** {user.id}"
            
        await self.log_to_channel(guild, "Member Unbanned", description, discord.Color.green())

    async def on_guild_channel_create(self, channel):
        """Log when channels are created."""
        description = (
            f"**Channel created: {channel.mention}**\n"
            f"**Type:** {channel.type.name.title()}\n"
            f"**Channel ID:** {channel.id}"
        )
        
        if hasattr(channel, 'category') and channel.category:
            description += f"\n**Category:** {channel.category.name}"
            
        await self.log_to_channel(channel.guild, "Channel Created", description, discord.Color.green())

    async def on_guild_channel_delete(self, channel):
        """Log when channels are deleted."""
        description = (
            f"**Channel deleted: #{channel.name}**\n"
            f"**Type:** {channel.type.name.title()}\n"
            f"**Channel ID:** {channel.id}"
        )
        
        if hasattr(channel, 'category') and channel.category:
            description += f"\n**Category:** {channel.category.name}"
            
        await self.log_to_channel(channel.guild, "Channel Deleted", description, discord.Color.red())

    async def on_guild_role_create(self, role):
        """Log when roles are created."""
        description = (
            f"**Role created: {role.mention}**\n"
            f"**Color:** {str(role.color)}\n"
            f"**Permissions:** {role.permissions.value}\n"
            f"**Role ID:** {role.id}"
        )
        
        await self.log_to_channel(role.guild, "Role Created", description, discord.Color.green())

    async def on_guild_role_delete(self, role):
        """Log when roles are deleted."""
        description = (
            f"**Role deleted: {role.name}**\n"
            f"**Color:** {str(role.color)}\n"
            f"**Role ID:** {role.id}"
        )
        
        await self.log_to_channel(role.guild, "Role Deleted", description, discord.Color.red())

    async def on_voice_state_update(self, member, before, after):
        """Log voice channel activity."""
        if before.channel == after.channel:
            return  # No channel change
            
        if before.channel is None and after.channel is not None:
            # Member joined voice
            description = (
                f"**{member.mention} joined voice channel**\n"
                f"**Channel:** {after.channel.mention}\n"
                f"**User ID:** {member.id}"
            )
            await self.log_to_channel(member.guild, "Voice Channel Joined", description, discord.Color.blue())
            
        elif before.channel is not None and after.channel is None:
            # Member left voice
            description = (
                f"**{member.mention} left voice channel**\n"
                f"**Channel:** {before.channel.mention}\n"
                f"**User ID:** {member.id}"
            )
            await self.log_to_channel(member.guild, "Voice Channel Left", description, discord.Color.blue())
            
        elif before.channel != after.channel:
            # Member switched channels
            description = (
                f"**{member.mention} switched voice channels**\n"
                f"**From:** {before.channel.mention}\n"
                f"**To:** {after.channel.mention}\n"
                f"**User ID:** {member.id}"
            )
            await self.log_to_channel(member.guild, "Voice Channel Switched", description, discord.Color.blue())

    async def on_guild_join(self, guild):
        """Send introduction message when bot joins a server."""
        logger.info(f'Bot joined server: {guild.name} ({guild.id})')

        # Log activity
        db_wrapper.log_activity(str(guild.id), "bot_join", f"Security bot deployed to {guild.name}")

        # Find a suitable channel to send introduction
        channel = None

        # Try to find general/welcome channels first
        for ch in guild.text_channels:
            if ch.name.lower() in ['general', 'welcome', 'bot-commands', 'commands']:
                channel = ch
                break

        # If no suitable channel found, use the first available text channel
        if not channel:
            for ch in guild.text_channels:
                if ch.permissions_for(guild.me).send_messages:
                    channel = ch
                    break

        if channel:
            intro_embed = discord.Embed(
                title="🛡️ Security Bot Deployed",
                description="**Real Anti-Raid, Anti-Nuke & Verification Protection**\n*Made by you - Genuine server security*",
                color=0x00ff41
            )

            intro_embed.add_field(
                name="🛡️ Security Features",
                value=(
                    "`!anti-raid` - Toggle anti-raid protection\n"
                    "`!lockdown` - Emergency server lockdown\n"
                    "`!add-scammer` - Add known scammers\n"
                    "`!backup-server` - Create server backup"
                ),
                inline=True
            )

            intro_embed.add_field(
                name="✅ Verification System",
                value=(
                    "`!setup-verification` - Setup user verification\n"
                    "`!verify` - Start verification process\n"
                    "`!verification-stats` - View verification stats"
                ),
                inline=True
            )

            intro_embed.add_field(
                name="🚨 Important Notes",
                value=(
                    "• All commands use `!` prefix\n"
                    "• Bot requires Administrator permissions\n"
                    "• Anti-raid protection is active by default\n"
                    "• Set a log channel with `!set-log-channel #channel`"
                ),
                inline=False
            )

            intro_embed.set_footer(
                text="Security system operational • Type !help for full command list",
                icon_url=self.user.display_avatar.url if self.user else None
            )

            try:
                await channel.send(embed=intro_embed)
                logger.info(f'Introduction sent to {guild.name} in #{channel.name}')
            except discord.Forbidden:
                logger.warning(f'Could not send introduction to {guild.name} - missing permissions')
            except Exception as e:
                logger.error(f'Error sending introduction to {guild.name}: {e}')

    async def on_command_error(self, ctx, error):
        """Handle command errors gracefully."""
        if isinstance(error, commands.CommandNotFound):
            return  # Ignore unknown commands

        if isinstance(error, commands.MissingRequiredArgument):
            embed = discord.Embed(
                title="❌ Missing Argument",
                description=f"Missing required argument: `{error.param.name}`\nExample: `{ctx.prefix}{ctx.command} <{error.param.name}>`",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return

        if isinstance(error, commands.BadArgument):
            embed = discord.Embed(
                title="❌ Invalid Argument",
                description=str(error),
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return

        if isinstance(error, commands.CheckFailure):
            embed = discord.Embed(
                title="❌ Permission Denied",
                description="You don't have permission to use this command.",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return

        # Handle channel not found errors (like deleted channels)
        if isinstance(error, discord.NotFound) and error.code == 10003:
            logger.warning(f"Channel not found error in {ctx.command}: {error}")
            return  # Silently ignore channel not found errors

        # Handle database connection errors gracefully
        if "OperationalError" in str(error) or "database" in str(error).lower():
            embed = discord.Embed(
                title="🟡 Database Unavailable",
                description="The bot is running in memory-only mode. Some features may be limited.",
                color=discord.Color.orange()
            )
            try:
                await ctx.send(embed=embed)
            except discord.NotFound:
                pass  # Channel was deleted during command execution
            return

        # Log the error for debugging
        logger.error(f"Unhandled error in {ctx.command}: {error}")

        # Send a generic error message
        embed = discord.Embed(
            title="❌ Command Error",
            description="An error occurred while processing your command. Please try again.",
            color=discord.Color.red()
        )
        try:
            await ctx.send(embed=embed)
        except discord.NotFound:
            pass  # Channel was deleted during command execution


async def main():
    """Main function to run the bot."""
    token = os.getenv('DISCORD_BOT_TOKEN')

    if not token:
        logger.error("DISCORD_BOT_TOKEN not found in environment variables!")
        logger.error("Please check your .env file or environment configuration.")
        return

    bot = AdminBot()

    # Start health monitoring server
    health_server = HealthServer(bot, port=5000)
    health_runner = await health_server.start_server()
    logger.info("🌐 Health monitoring web dashboard started")

    try:
        await bot.start(token)
    except discord.LoginFailure:
        logger.error("Invalid bot token provided!")
    except Exception as e:
        logger.error(f"Error starting bot: {e}")
    finally:
        # Clean up health server
        try:
            await health_runner.cleanup()
        except:
            pass

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot shutdown requested by user")
    except Exception as e:
        logger.error(f"Fatal error: {e}")
