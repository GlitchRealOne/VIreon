"""
Configuration settings for the Discord bot.
Centralized configuration management with environment variable support.
"""

import os
from typing import List

# Bot Configuration
BOT_CONFIG = {
    # Bot settings
    'prefix': os.getenv('BOT_PREFIX', '!'),
    'description': 'Advanced Discord Security Bot - Made by you! Real anti-raid, anti-nuke, scammer protection, and verification system.',
    
    # Permission settings
    'admin_roles': [
        role.strip() for role in os.getenv('ADMIN_ROLES', 'Admin,Administrator,Moderator,Owner').split(',')
        if role.strip()
    ],
    
    # Allowed user IDs (comma-separated list of Discord user IDs)
    'allowed_users': [
        int(user_id.strip()) for user_id in os.getenv('ALLOWED_USERS', '').split(',')
        if user_id.strip().isdigit()
    ],
    
    # Safety settings
    'require_confirmation': True,
    'confirmation_timeout': 30,  # seconds
    'rate_limit_per_guild': 300,  # seconds between nuke commands per guild
    
    # Logging settings
    'log_level': os.getenv('LOG_LEVEL', 'INFO'),
    'log_file': os.getenv('LOG_FILE', 'bot.log'),
    'log_format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    
    # Feature flags
    'enable_detailed_logging': os.getenv('ENABLE_DETAILED_LOGGING', 'true').lower() == 'true',
    'enable_auto_backup': os.getenv('ENABLE_AUTO_BACKUP', 'true').lower() == 'true',
    'enable_anti_raid': os.getenv('ENABLE_ANTI_RAID', 'true').lower() == 'true',
}

# Discord API Configuration
DISCORD_CONFIG = {
    'token': os.getenv('DISCORD_BOT_TOKEN', ''),
    'application_id': os.getenv('DISCORD_APPLICATION_ID', ''),
    'permissions_integer': 8,  # Administrator permission
}

# Rate Limiting Configuration
RATE_LIMIT_CONFIG = {
    'backup_command': {
        'rate': 1,
        'per': 1800,  # 30 minutes
        'bucket': 'guild'
    },
    'info_command': {
        'rate': 5,
        'per': 60,  # 1 minute
        'bucket': 'user'
    },
    'scammer_commands': {
        'rate': 10,
        'per': 60,  # 1 minute
        'bucket': 'user'
    }
}

# Embed Colors (Discord color integers)
EMBED_COLORS = {
    'success': 0x00ff00,    # Green
    'error': 0xff0000,      # Red
    'warning': 0xffa500,    # Orange
    'info': 0x0099ff,       # Blue
    'confirmation': 0xffd700 # Gold
}

# Messages Configuration
MESSAGES = {
    'bot_ready': "🤖 Bot is online and ready!",
    'permission_denied': "❌ You don't have permission to use this command.",
    'server_only': "❌ This command can only be used in a server.",
    'confirmation_timeout': "⏰ Confirmation timeout. Operation cancelled.",
    'operation_cancelled': "❌ Operation cancelled by user.",
    'lockdown_warning': (
        "🔒 **SERVER LOCKDOWN ACTIVATED** 🔒\n\n"
        "The server is now in lockdown mode due to security concerns.\n"
        "Only administrators can send messages during this time.\n"
        "Normal operations will resume shortly."
    )
}

# Validation
def validate_config():
    """Validate configuration settings."""
    
    errors = []
    
    # Check required environment variables
    if not DISCORD_CONFIG['token']:
        errors.append("DISCORD_BOT_TOKEN environment variable is required")
    
    # Check admin roles
    if not BOT_CONFIG['admin_roles']:
        errors.append("At least one admin role must be specified")
    
    # Check timeouts
    if BOT_CONFIG['confirmation_timeout'] < 10:
        errors.append("Confirmation timeout must be at least 10 seconds")
    
    if BOT_CONFIG['rate_limit_per_guild'] < 60:
        errors.append("Rate limit per guild must be at least 60 seconds")
    
    if errors:
        raise ValueError("Configuration errors:\n" + "\n".join(f"- {error}" for error in errors))
    
    return True

# Auto-validate on import
try:
    validate_config()
except ValueError as e:
    print(f"Configuration Error: {e}")
    print("Please check your environment variables and configuration.")
