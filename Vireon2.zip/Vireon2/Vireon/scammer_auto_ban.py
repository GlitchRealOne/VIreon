#!/usr/bin/env python3
"""
Scammer Auto-Ban System for Discord Security Bot
Automatically bans known scammers when they join servers.
"""

import discord
from discord.ext import commands
import aiohttp
import asyncio
import logging
from datetime import datetime
from security_bot.utils import create_error_embed, create_success_embed

logger = logging.getLogger(__name__)

class ScammerAutoBan(commands.Cog):
    """Auto-ban system for known scammers."""
    
    def __init__(self, bot):
        self.bot = bot
        self.web_api_url = "http://localhost:3000/api"  # Web dashboard API
        self.enabled_guilds = set()  # Guilds with auto-ban enabled
        
    def is_auto_ban_enabled(self, guild_id):
        """Check if auto-ban is enabled for this guild."""
        return guild_id in self.enabled_guilds
        
    async def check_scammer_by_id(self, user_id):
        """Check if user ID is in scammer database."""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"{self.web_api_url}/check_scammer/{user_id}") as response:
                    if response.status == 200:
                        data = await response.json()
                        return data if data.get('is_scammer') else None
            return None
        except Exception as e:
            logger.error(f"Error checking scammer by ID {user_id}: {e}")
            return None
            
    async def check_scammer_by_username(self, username, discriminator=None):
        """Check if username is in scammer database."""
        try:
            full_username = f"{username}#{discriminator}" if discriminator else username
            async with aiohttp.ClientSession() as session:
                async with session.get(f"{self.web_api_url}/check_scammer_by_username/{full_username}") as response:
                    if response.status == 200:
                        data = await response.json()
                        return data if data.get('is_scammer') else None
            return None
        except Exception as e:
            logger.error(f"Error checking scammer by username {username}: {e}")
            return None
            
    async def log_auto_ban(self, guild, user, scammer_data, ban_reason):
        """Log the auto-ban action to the web dashboard."""
        try:
            log_data = {
                'guild_id': str(guild.id),
                'guild_name': guild.name,
                'user_id': str(user.id),
                'username': f"{user.name}#{user.discriminator}" if hasattr(user, 'discriminator') and user.discriminator != '0' else user.name,
                'scammer_entry_id': scammer_data['id'],
                'ban_reason': ban_reason
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(f"{self.web_api_url}/log_ban", json=log_data) as response:
                    if response.status == 200:
                        logger.info(f"Logged auto-ban for {user.name} in {guild.name}")
                    else:
                        logger.error(f"Failed to log auto-ban: {response.status}")
        except Exception as e:
            logger.error(f"Error logging auto-ban: {e}")
            
    async def perform_auto_ban(self, member, scammer_data):
        """Perform the actual ban and logging."""
        guild = member.guild
        
        # Create ban reason
        ban_reason = (
            f"Auto-Ban: Known scammer detected\n"
            f"Reason: {scammer_data['reason']}\n"
            f"Severity: {scammer_data['severity'].upper()}\n"
            f"Added by: {scammer_data['added_by']}\n"
            f"Detection: Automatic on join"
        )
        
        try:
            # Ban the user
            await member.ban(reason=ban_reason, delete_message_days=1)
            logger.info(f"Auto-banned {member.name} from {guild.name} - Known scammer")
            
            # Log to web dashboard
            await self.log_auto_ban(guild, member, scammer_data, ban_reason)
            
            # Send notification to log channel if configured
            await self.send_auto_ban_notification(guild, member, scammer_data, ban_reason)
            
            return True
            
        except discord.Forbidden:
            logger.error(f"Failed to auto-ban {member.name} in {guild.name} - Missing permissions")
            await self.send_permission_error(guild, member, scammer_data)
            return False
        except Exception as e:
            logger.error(f"Error auto-banning {member.name} in {guild.name}: {e}")
            return False
            
    async def send_auto_ban_notification(self, guild, member, scammer_data, ban_reason):
        """Send notification about the auto-ban to the log channel."""
        try:
            # Try to get log channel from guild settings
            from database_wrapper import db_wrapper
            settings = db_wrapper.get_guild_settings(str(guild.id))
            log_channel_id = settings.get('log_channel_id')
            
            if log_channel_id:
                log_channel = guild.get_channel(int(log_channel_id))
                if log_channel:
                    embed = discord.Embed(
                        title="🚨 Auto-Ban Executed",
                        description=f"Automatically banned **{member.name}#{member.discriminator if hasattr(member, 'discriminator') else ''}** - Known scammer detected",
                        color=discord.Color.red(),
                        timestamp=datetime.utcnow()
                    )
                    
                    embed.add_field(name="User", value=f"{member.mention} (`{member.id}`)", inline=True)
                    embed.add_field(name="Severity", value=scammer_data['severity'].upper(), inline=True)
                    embed.add_field(name="Detection", value="On server join", inline=True)
                    embed.add_field(name="Reason", value=scammer_data['reason'], inline=False)
                    embed.add_field(name="Added by", value=scammer_data['added_by'], inline=True)
                    embed.add_field(name="Added on", value=scammer_data['added_at'][:10], inline=True)
                    
                    embed.set_footer(text="Vireon Security Bot • Auto-Ban System")
                    
                    await log_channel.send(embed=embed)
                    
        except Exception as e:
            logger.error(f"Error sending auto-ban notification: {e}")
            
    async def send_permission_error(self, guild, member, scammer_data):
        """Send error notification when lacking permissions to ban."""
        try:
            from database_wrapper import db_wrapper
            settings = db_wrapper.get_guild_settings(str(guild.id))
            log_channel_id = settings.get('log_channel_id')
            
            if log_channel_id:
                log_channel = guild.get_channel(int(log_channel_id))
                if log_channel:
                    embed = discord.Embed(
                        title="⚠️ Auto-Ban Failed - Permission Error",
                        description=f"Could not ban **{member.name}** - Known scammer detected but lacking permissions",
                        color=discord.Color.orange(),
                        timestamp=datetime.utcnow()
                    )
                    
                    embed.add_field(name="User", value=f"{member.mention} (`{member.id}`)", inline=True)
                    embed.add_field(name="Severity", value=scammer_data['severity'].upper(), inline=True)
                    embed.add_field(name="Required Action", value="Manual ban recommended", inline=True)
                    embed.add_field(name="Reason", value=scammer_data['reason'], inline=False)
                    
                    embed.set_footer(text="Please ensure bot has Ban Members permission")
                    
                    await log_channel.send(embed=embed)
                    
        except Exception as e:
            logger.error(f"Error sending permission error notification: {e}")

    @commands.Cog.listener()
    async def on_member_join(self, member):
        """Check new members against scammer database."""
        if member.bot:
            return
            
        guild = member.guild
        
        # Check if auto-ban is enabled for this guild
        if not self.is_auto_ban_enabled(guild.id):
            return
            
        logger.info(f"Checking new member {member.name} in {guild.name} against scammer database")
        
        # Check by Discord ID first (more accurate)
        scammer_data = await self.check_scammer_by_id(member.id)
        
        # If not found by ID, check by username
        if not scammer_data:
            discriminator = member.discriminator if hasattr(member, 'discriminator') and member.discriminator != '0' else None
            scammer_data = await self.check_scammer_by_username(member.name, discriminator)
            
        # If found in database, perform auto-ban
        if scammer_data:
            logger.warning(f"Scammer detected: {member.name} ({member.id}) in {guild.name}")
            await self.perform_auto_ban(member, scammer_data)
        else:
            logger.debug(f"Member {member.name} clean - not in scammer database")

    @commands.command(name='auto-ban-toggle', aliases=['toggle-auto-ban'])
    @commands.has_permissions(administrator=True)
    async def toggle_auto_ban(self, ctx, enabled: bool = None):
        """Enable or disable auto-ban for known scammers."""
        guild_id = ctx.guild.id
        
        if enabled is None:
            current_status = self.is_auto_ban_enabled(guild_id)
            enabled = not current_status
            
        if enabled:
            self.enabled_guilds.add(guild_id)
            status = "enabled"
            color = discord.Color.green()
        else:
            self.enabled_guilds.discard(guild_id)
            status = "disabled"
            color = discord.Color.red()
            
        embed = discord.Embed(
            title="🚨 Auto-Ban System Updated",
            description=f"Scammer auto-ban has been **{status}** for this server.",
            color=color
        )
        
        if enabled:
            embed.add_field(
                name="What happens now?",
                value="• New members are checked against scammer database\n"
                      "• Known scammers are automatically banned on join\n"
                      "• All actions are logged to your log channel\n"
                      "• Web dashboard tracks all auto-bans",
                inline=False
            )
        else:
            embed.add_field(
                name="Auto-ban disabled",
                value="New members will not be checked against the scammer database.",
                inline=False
            )
            
        embed.set_footer(text="Manage scammer database at: http://localhost:3000")
        await ctx.send(embed=embed)

    @commands.command(name='auto-ban-status')
    @commands.has_permissions(administrator=True)
    async def auto_ban_status(self, ctx):
        """Check auto-ban system status."""
        guild_id = ctx.guild.id
        enabled = self.is_auto_ban_enabled(guild_id)
        
        embed = discord.Embed(
            title="🚨 Auto-Ban System Status",
            color=discord.Color.green() if enabled else discord.Color.red()
        )
        
        status = "🟢 Enabled" if enabled else "🔴 Disabled"
        embed.add_field(name="Status", value=status, inline=True)
        
        embed.add_field(
            name="Web Dashboard",
            value="[Manage Scammers](http://localhost:3000)",
            inline=True
        )
        
        if enabled:
            embed.add_field(
                name="Protection Active",
                value="✅ New members checked automatically\n"
                      "✅ Known scammers banned on join\n"
                      "✅ Actions logged and tracked",
                inline=False
            )
        else:
            embed.add_field(
                name="To Enable",
                value="Use `!auto-ban-toggle true` to activate protection",
                inline=False
            )
            
        embed.set_footer(text="Use !auto-ban-toggle to change settings")
        await ctx.send(embed=embed)

    @commands.command(name='check-scammer')
    @commands.has_permissions(administrator=True)
    async def check_scammer_command(self, ctx, *, user_input):
        """Check if a user is in the scammer database."""
        # Try to parse as Discord ID first
        if user_input.isdigit() and len(user_input) >= 17:
            scammer_data = await self.check_scammer_by_id(user_input)
            search_type = "Discord ID"
        else:
            # Parse as username
            scammer_data = await self.check_scammer_by_username(user_input)
            search_type = "Username"
            
        embed = discord.Embed(
            title="🔍 Scammer Database Lookup",
            timestamp=datetime.utcnow()
        )
        
        if scammer_data:
            embed.color = discord.Color.red()
            embed.description = f"**⚠️ SCAMMER FOUND** - User is in the database"
            
            embed.add_field(name="Search Term", value=user_input, inline=True)
            embed.add_field(name="Search Type", value=search_type, inline=True)
            embed.add_field(name="Severity", value=scammer_data['severity'].upper(), inline=True)
            embed.add_field(name="Reason", value=scammer_data['reason'], inline=False)
            embed.add_field(name="Added By", value=scammer_data['added_by'], inline=True)
            embed.add_field(name="Added On", value=scammer_data['added_at'][:10], inline=True)
            
        else:
            embed.color = discord.Color.green()
            embed.description = f"✅ **Clean** - User not found in scammer database"
            embed.add_field(name="Search Term", value=user_input, inline=True)
            embed.add_field(name="Search Type", value=search_type, inline=True)
            
        embed.set_footer(text="Manage database at: http://localhost:3000")
        await ctx.send(embed=embed)

async def setup(bot):
    """Setup function for the cog."""
    await bot.add_cog(ScammerAutoBan(bot))