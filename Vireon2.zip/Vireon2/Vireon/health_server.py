#!/usr/bin/env python3
"""
Simple health check web server for UptimeRobot monitoring.
This creates an HTTP endpoint that UptimeRobot can ping to monitor bot uptime.
"""

import asyncio
import json
import logging
from datetime import datetime
from aiohttp import web

logger = logging.getLogger(__name__)

class HealthServer:
    def __init__(self, bot=None, port=5000):
        self.bot = bot
        self.port = port
        self.app = web.Application()
        self.setup_routes()
        
    def setup_routes(self):
        """Set up web routes for health monitoring."""
        self.app.router.add_get('/', self.web_dashboard)
        self.app.router.add_get('/health', self.health_check)
        self.app.router.add_get('/status', self.detailed_status)
        self.app.router.add_get('/dashboard', self.web_dashboard)
        
    async def health_check(self, request):
        """Simple health check endpoint for UptimeRobot."""
        
        # Check if bot is connected
        if self.bot and hasattr(self.bot, 'is_ready') and self.bot.is_ready():
            status = "healthy"
            code = 200
        else:
            status = "unhealthy"
            code = 503
            
        response_data = {
            "status": status,
            "timestamp": datetime.utcnow().isoformat(),
            "service": "Discord Security Bot"
        }
        
        return web.json_response(response_data, status=code)
        
    async def detailed_status(self, request):
        """Detailed status endpoint with bot information."""
        
        if self.bot and hasattr(self.bot, 'is_ready') and self.bot.is_ready():
            guilds_count = len(self.bot.guilds) if self.bot.guilds else 0
            latency = round(self.bot.latency * 1000, 2) if hasattr(self.bot, 'latency') else 0
            
            response_data = {
                "status": "healthy",
                "bot_ready": True,
                "guilds": guilds_count,
                "latency_ms": latency,
                "timestamp": datetime.utcnow().isoformat(),
                "service": "Discord Security Bot",
                "version": "1.0.0"
            }
            code = 200
        else:
            response_data = {
                "status": "unhealthy",
                "bot_ready": False,
                "timestamp": datetime.utcnow().isoformat(),
                "service": "Discord Security Bot"
            }
            code = 503
            
        return web.json_response(response_data, status=code)
    
    async def web_dashboard(self, request):
        """Web dashboard for health monitoring."""
        
        # Get bot status
        if self.bot and hasattr(self.bot, 'is_ready') and self.bot.is_ready():
            status = "🟢 ONLINE"
            status_color = "#28a745"
            guilds_count = len(self.bot.guilds) if self.bot.guilds else 0
            latency = round(self.bot.latency * 1000, 2) if hasattr(self.bot, 'latency') else 0
            uptime_info = "Connected and Ready"
        else:
            status = "🔴 OFFLINE"
            status_color = "#dc3545"
            guilds_count = 0
            latency = 0
            uptime_info = "Bot Not Connected"
        
        html_content = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Discord Security Bot - Health Monitor</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #333;
            min-height: 100vh;
            padding: 20px;
        }}
        
        .container {{
            max-width: 1200px;
            margin: 0 auto;
        }}
        
        .header {{
            text-align: center;
            color: white;
            margin-bottom: 30px;
        }}
        
        .header h1 {{
            font-size: 2.5em;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }}
        
        .header p {{
            font-size: 1.2em;
            opacity: 0.9;
        }}
        
        .dashboard {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }}
        
        .card {{
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }}
        
        .card:hover {{
            transform: translateY(-5px);
        }}
        
        .card-header {{
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }}
        
        .card-icon {{
            font-size: 2em;
            margin-right: 15px;
        }}
        
        .card-title {{
            font-size: 1.3em;
            font-weight: bold;
            color: #2c3e50;
        }}
        
        .status-badge {{
            display: inline-block;
            padding: 8px 16px;
            border-radius: 25px;
            color: white;
            font-weight: bold;
            font-size: 1.1em;
            background-color: {status_color};
        }}
        
        .metric {{
            margin: 15px 0;
        }}
        
        .metric-label {{
            font-weight: bold;
            color: #555;
            margin-bottom: 5px;
        }}
        
        .metric-value {{
            font-size: 1.8em;
            font-weight: bold;
            color: #2c3e50;
        }}
        
        .security-features {{
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }}
        
        .feature-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }}
        
        .feature-item {{
            display: flex;
            align-items: center;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 10px;
            border-left: 4px solid #28a745;
        }}
        
        .feature-icon {{
            margin-right: 15px;
            font-size: 1.5em;
        }}
        
        .footer {{
            text-align: center;
            color: white;
            margin-top: 30px;
            opacity: 0.8;
        }}
        
        .refresh-btn {{
            position: fixed;
            top: 20px;
            right: 20px;
            background: #28a745;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 25px;
            cursor: pointer;
            font-weight: bold;
            box-shadow: 0 4px 15px rgba(40,167,69,0.3);
            transition: all 0.3s ease;
        }}
        
        .refresh-btn:hover {{
            background: #218838;
            transform: translateY(-2px);
        }}
    </style>
</head>
<body>
    <button class="refresh-btn" onclick="location.reload()">🔄 Refresh</button>
    
    <div class="container">
        <div class="header">
            <h1>🛡️ Discord Security Bot</h1>
            <p>Real-time Health & Status Monitor</p>
        </div>
        
        <div class="dashboard">
            <div class="card">
                <div class="card-header">
                    <div class="card-icon">🤖</div>
                    <div class="card-title">Bot Status</div>
                </div>
                <div class="status-badge">{status}</div>
                <div class="metric">
                    <div class="metric-label">Connection Status</div>
                    <div class="metric-value">{uptime_info}</div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <div class="card-icon">🌐</div>
                    <div class="card-title">Server Stats</div>
                </div>
                <div class="metric">
                    <div class="metric-label">Servers Protected</div>
                    <div class="metric-value">{guilds_count}</div>
                </div>
                <div class="metric">
                    <div class="metric-label">Response Time</div>
                    <div class="metric-value">{latency}ms</div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <div class="card-icon">⏰</div>
                    <div class="card-title">System Info</div>
                </div>
                <div class="metric">
                    <div class="metric-label">Last Updated</div>
                    <div class="metric-value">{datetime.utcnow().strftime('%H:%M:%S')}</div>
                </div>
                <div class="metric">
                    <div class="metric-label">Mode</div>
                    <div class="metric-value">Security</div>
                </div>
            </div>
        </div>
        
        <div class="security-features">
            <h2 style="color: #2c3e50; margin-bottom: 20px; text-align: center;">🔒 Active Security Features</h2>
            <div class="feature-grid">
                <div class="feature-item">
                    <div class="feature-icon">🛡️</div>
                    <div>
                        <strong>Anti-Raid Protection</strong><br>
                        <small>Real-time monitoring active</small>
                    </div>
                </div>
                <div class="feature-item">
                    <div class="feature-icon">✅</div>
                    <div>
                        <strong>User Verification</strong><br>
                        <small>Automated security checks</small>
                    </div>
                </div>
                <div class="feature-item">
                    <div class="feature-icon">📊</div>
                    <div>
                        <strong>Activity Monitoring</strong><br>
                        <small>24/7 server surveillance</small>
                    </div>
                </div>
                <div class="feature-item">
                    <div class="feature-icon">💾</div>
                    <div>
                        <strong>Backup System</strong><br>
                        <small>Automated server backups</small>
                    </div>
                </div>
                <div class="feature-item">
                    <div class="feature-icon">🚨</div>
                    <div>
                        <strong>Threat Detection</strong><br>
                        <small>Advanced security scanning</small>
                    </div>
                </div>
                <div class="feature-item">
                    <div class="feature-icon">🔐</div>
                    <div>
                        <strong>Permission Control</strong><br>
                        <small>Role-based security</small>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="footer">
            <p>Discord Security Bot v1.0 | Status updated every 30 seconds | 
            <a href="/health" style="color: #fff; text-decoration: underline;">JSON Health Check</a></p>
        </div>
    </div>
    
    <script>
        // Auto-refresh every 30 seconds
        setTimeout(function(){{
            location.reload();
        }}, 30000);
        
        // Add loading animation to refresh button
        document.querySelector('.refresh-btn').addEventListener('click', function() {{
            this.innerHTML = '⏳ Refreshing...';
            this.disabled = true;
        }});
    </script>
</body>
</html>
        """
        
        return web.Response(text=html_content, content_type='text/html')
        
    async def start_server(self):
        """Start the health check web server."""
        runner = web.AppRunner(self.app)
        await runner.setup()
        
        site = web.TCPSite(runner, '0.0.0.0', self.port)
        await site.start()
        
        logger.info(f"Health check server started on port {self.port}")
        logger.info(f"Health endpoint: http://0.0.0.0:{self.port}/health")
        
        return runner

if __name__ == "__main__":
    # For testing the health server independently
    async def main():
        server = HealthServer()
        await server.start_server()
        
        print(f"Health server running on http://0.0.0.0:{server.port}")
        print("Available endpoints:")
        print("  /health - Simple health check")
        print("  /status - Detailed status")
        print("Press Ctrl+C to stop")
        
        try:
            await asyncio.Event().wait()
        except KeyboardInterrupt:
            print("Server stopped")
    
    asyncio.run(main())