"""
Utility functions for the Discord bot.
Contains helper functions for embeds, formatting, and common operations.
"""

import discord
from datetime import datetime
from typing import Optional

def create_embed(title: str, description: str, color: discord.Color = discord.Color.blue()) -> discord.Embed:
    """Create a basic embed with title and description."""

    embed = discord.Embed(
        title=title,
        description=description,
        color=color,
        timestamp=datetime.utcnow()
    )
    return embed

def create_success_embed(title: str = "✅ Success", description: str = "") -> discord.Embed:
    """Create a success embed with green color."""
    return create_embed(title, description, discord.Color.green())

def create_error_embed(description: str, title: str = "❌ Error") -> discord.Embed:
    """Create an error embed with red color."""
    return create_embed(title, description, discord.Color.red())

def create_warning_embed(title: str, description: str) -> discord.Embed:
    """Create a warning embed with orange color."""
    return create_embed(title, description, discord.Color.orange())

def create_info_embed(title: str, description: str) -> discord.Embed:
    """Create an info embed with blue color."""
    return create_embed(title, description, discord.Color.blue())

def create_confirmation_embed(title: str, description: str) -> discord.Embed:
    """Create a confirmation embed with yellow color."""
    embed = discord.Embed(
        title=title,
        description=description,
        color=discord.Color.gold(),
        timestamp=datetime.utcnow()
    )

    embed.set_footer(text="⚠️ This action requires confirmation")
    return embed

def format_channel_list(channels: list, max_items: int = 10) -> str:
    """Format a list of channels for display."""

    if not channels:
        return "No channels found."

    formatted_list = []

    for i, channel in enumerate(channels[:max_items]):
        if channel.type == discord.ChannelType.text:
            emoji = "💬"
        elif channel.type == discord.ChannelType.voice:
            emoji = "🔊"
        elif channel.type == discord.ChannelType.category:
            emoji = "📁"
        elif channel.type == discord.ChannelType.stage_voice:
            emoji = "🎭"
        elif channel.type == discord.ChannelType.news:
            emoji = "📢"
        elif channel.type == discord.ChannelType.forum:
            emoji = "💭"
        else:
            emoji = "📄"

        formatted_list.append(f"{emoji} {channel.name}")

    result = "\n".join(formatted_list)

    if len(channels) > max_items:
        result += f"\n... and {len(channels) - max_items} more"

    return result

def format_user_mention(user: discord.User) -> str:
    """Format a user mention with fallback to username."""
    return f"{user.mention} (`{user.display_name}`)"

def format_role_list(roles: list) -> str:
    """Format a list of roles for display."""

    if not roles:
        return "No roles"

    # Skip @everyone role and format others
    role_names = [role.name for role in roles if role.name != "@everyone"]

    if not role_names:
        return "No special roles"

    return ", ".join(role_names)

def format_permissions(permissions: discord.Permissions) -> str:
    """Format permissions into a readable string."""

    important_perms = {
        'administrator': 'Administrator',
        'manage_guild': 'Manage Server',
        'manage_channels': 'Manage Channels',
        'manage_roles': 'Manage Roles',
        'manage_messages': 'Manage Messages',
        'kick_members': 'Kick Members',
        'ban_members': 'Ban Members',
        'mention_everyone': 'Mention Everyone',
        'manage_webhooks': 'Manage Webhooks'
    }

    user_perms = []

    for perm_name, display_name in important_perms.items():
        if getattr(permissions, perm_name, False):
            user_perms.append(display_name)

    if not user_perms:
        return "No special permissions"

    return ", ".join(user_perms)

def truncate_text(text: str, max_length: int = 2000) -> str:
    """Truncate text to fit Discord's limits."""

    if len(text) <= max_length:
        return text

    return text[:max_length - 3] + "..."

def format_duration(seconds: float) -> str:
    """Format duration in seconds to human-readable format."""

    if seconds < 60:
        return f"{seconds:.1f} seconds"
    elif seconds < 3600:
        minutes = seconds / 60
        return f"{minutes:.1f} minutes"
    else:
        hours = seconds / 3600
        return f"{hours:.1f} hours"

def create_progress_bar(current: int, total: int, length: int = 20) -> str:
    """Create a text-based progress bar."""

    if total == 0:
        return "█" * length

    filled = int((current / total) * length)
    empty = length - filled

    return "█" * filled + "░" * empty + f" {current}/{total}"

def safe_string(text: str, max_length: int = 100) -> str:
    """Safely format a string for Discord, removing potential mentions and limiting length."""

    # Remove potential mentions
    text = text.replace("@", "@\u200b").replace("#", "#\u200b")

    # Limit length
    if len(text) > max_length:
        text = text[:max_length - 3] + "..."

    return text

def format_timestamp(timestamp: datetime, style: str = "f") -> str:
    """Format a timestamp for Discord's timestamp formatting."""

    unix_timestamp = int(timestamp.timestamp())
    return f"<t:{unix_timestamp}:{style}>"

def get_channel_type_emoji(channel_type: discord.ChannelType) -> str:
    """Get emoji for channel type."""

    emoji_map = {
        discord.ChannelType.text: "💬",
        discord.ChannelType.voice: "🔊",
        discord.ChannelType.category: "📁",
        discord.ChannelType.news: "📢",
        discord.ChannelType.stage_voice: "🎭",
        discord.ChannelType.forum: "💭",
        discord.ChannelType.news_thread: "🧵",
        discord.ChannelType.public_thread: "🧵",
        discord.ChannelType.private_thread: "🔒"
    }

    return emoji_map.get(channel_type, "📄")