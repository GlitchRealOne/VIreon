"""
Basic administrative commands for the security bot.
"""

import asyncio
import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime

from security_bot.permissions import require_admin_role
from security_bot.utils import create_success_embed, create_error_embed, create_info_embed, create_warning_embed
from database_wrapper import db_wrapper


async def setup(bot):
    """Setup function for the cog."""
    await bot.add_cog(AdminCommands(bot))



class AdminCommands(commands.Cog):
    """Basic administrative commands."""

    def __init__(self, bot):
        self.bot = bot

    def get_guild_settings(self, guild_id: int) -> dict:
        """Get or create guild settings."""
        return db_wrapper.get_guild_settings(str(guild_id))

    async def log_security_event(self, guild: discord.Guild, event_type: str, description: str, color: discord.Color = discord.Color.orange()):
        """Log security events to the configured log channel."""
        settings = self.get_guild_settings(guild.id)
        if settings.get('log_channel_id'):
            channel = guild.get_channel(int(settings['log_channel_id']))
            if channel and hasattr(channel, 'send'):
                embed = discord.Embed(
                    title=f"🛡️ Security Event: {event_type}",
                    description=description,
                    color=color,
                    timestamp=datetime.utcnow()
                )
                embed.set_footer(text=f"Guild: {guild.name}")
                try:
                    await channel.send(embed=embed)
                except discord.Forbidden:
                    pass

    @commands.command(name='ping')
    async def ping(self, ctx):
        """Check bot latency and status."""
        latency = round(self.bot.latency * 1000)

        embed = discord.Embed(
            title="🏓 Pong!",
            description=f"Bot latency: **{latency}ms**",
            color=discord.Color.green() if latency < 100 else discord.Color.orange()
        )

        embed.add_field(name="Status", value="✅ Online", inline=True)
        embed.add_field(name="Uptime", value="Available", inline=True)

        await ctx.send(embed=embed)

    @app_commands.command(name="ping", description="Check bot latency and status")
    async def slash_ping(self, interaction: discord.Interaction):
        """Slash command version of ping."""
        latency = round(self.bot.latency * 1000)

        embed = discord.Embed(
            title="🏓 Pong!",
            description=f"Bot latency: **{latency}ms**",
            color=discord.Color.green() if latency < 100 else discord.Color.orange()
        )

        embed.add_field(name="Status", value="✅ Online", inline=True)
        embed.add_field(name="Uptime", value="Available", inline=True)

        await interaction.response.send_message(embed=embed)

    @commands.command(name='pong')
    async def pong(self, ctx):
        """Respond with ping - fun command."""
        latency = round(self.bot.latency * 1000)

        embed = discord.Embed(
            title="🏓 Ping!",
            description=f"You said pong, I say ping! Latency: **{latency}ms**",
            color=discord.Color.blue()
        )

        await ctx.send(embed=embed)

    @commands.command(name='info', aliases=['botinfo'])
    async def show_info(self, ctx):
        """Display bot information."""
        embed = discord.Embed(
            title="🛡️ Security Bot Information",
            description="Advanced Discord server protection bot - Made by you!\nReal anti-raid, anti-nuke, and scammer protection system.",
            color=discord.Color.blue()
        )

        embed.add_field(
            name="📊 Statistics",
            value=f"**Servers:** {len(self.bot.guilds)}\n"
                  f"**Users:** {sum(guild.member_count or 0 for guild in self.bot.guilds)}\n"
                  f"**Channels:** {sum(len(guild.channels) for guild in self.bot.guilds)}",
            inline=True
        )

        embed.add_field(
            name="🔧 Features",
            value="• Anti-raid protection\n"
                  "• Scammer database\n"
                  "• Server backups\n"
                  "• User verification\n"
                  "• Security logging",
            inline=True
        )

        embed.add_field(
            name="📝 Commands",
            value=f"Use `{ctx.prefix}help` to see all commands",
            inline=False
        )

        embed.set_footer(
            text=f"Running on {len(self.bot.guilds)} servers",
            icon_url=self.bot.user.display_avatar.url
        )

        await ctx.send(embed=embed)

    @app_commands.command(name="info", description="Display bot information and statistics")
    async def slash_info(self, interaction: discord.Interaction):
        """Slash command version of info."""
        embed = discord.Embed(
            title="🛡️ Security Bot Information",
            description="Advanced Discord server protection bot - Made by you!\nReal anti-raid, anti-nuke, and scammer protection system.",
            color=discord.Color.blue()
        )

        embed.add_field(
            name="📊 Statistics",
            value=f"**Servers:** {len(self.bot.guilds)}\n"
                  f"**Users:** {sum(guild.member_count or 0 for guild in self.bot.guilds)}\n"
                  f"**Channels:** {sum(len(guild.channels) for guild in self.bot.guilds)}",
            inline=True
        )

        embed.add_field(
            name="🔧 Features",
            value="• Anti-raid protection\n"
                  "• Scammer database\n"
                  "• Server backups\n"
                  "• User verification\n"
                  "• Security logging",
            inline=True
        )

        embed.add_field(
            name="📝 Commands",
            value="Use `/help` or `!help` to see all commands",
            inline=False
        )

        embed.set_footer(
            text=f"Running on {len(self.bot.guilds)} servers",
            icon_url=self.bot.user.display_avatar.url
        )

        await interaction.response.send_message(embed=embed)

    @commands.command(name='help', aliases=['commands'])
    async def help_command(self, ctx, category: str = None):
        """Display help information for bot commands."""

        if category is None:
            # Main help menu
            embed = discord.Embed(
                title="🛡️ Vireon Security Bot Commands",
                description="**Advanced server protection and administration system**",
                color=discord.Color.blue()
            )

            # Basic Commands
            embed.add_field(
                name="🔧 Basic Commands",
                value=f"`{ctx.prefix}ping` - Check bot latency and status\n"
                      f"`{ctx.prefix}info` - Bot information and statistics\n"
                      f"`{ctx.prefix}settings` - View server security settings\n"
                      f"`{ctx.prefix}set-log-channel #channel` / `{ctx.prefix}setlog #channel` - Set logging channel\n"
                      f"`{ctx.prefix}log` - View security event logs\n"
                      f"`{ctx.prefix}activity-log` - View detailed activity logs\n"
                      f"`{ctx.prefix}why-administrator` - Explain admin permission requirements",
                inline=False
            )

            # Logging System
            embed.add_field(
                name="📝 Message Logging",
                value=f"`{ctx.prefix}set-log-channel` - Set channel for all logs\n"
                      f"`{ctx.prefix}toggle-message-logs` - Track edited/deleted messages\n"
                      f"`{ctx.prefix}toggle-member-logs` - Track joins/leaves\n"
                      f"`{ctx.prefix}logging-status` - View logging configuration",
                inline=False
            )



            # Moderation Commands
            embed.add_field(
                name="👮 Moderation Commands",
                value=f"`{ctx.prefix}kick @user [reason]` - Kick a user\n"
                      f"`{ctx.prefix}ban @user [reason]` - Ban a user\n"
                      f"`{ctx.prefix}unban <user_id> [reason]` - Unban a user\n"
                      f"`{ctx.prefix}mute @user [minutes] [reason]` - Mute a user\n"
                      f"`{ctx.prefix}unmute @user [reason]` - Unmute a user\n"
                      f"`{ctx.prefix}warn @user [reason]` - Warn a user\n"
                      f"`{ctx.prefix}clear [amount] [#channel]` - Delete messages (1-100)",
                inline=False
            )

            

            # Backup System
            embed.add_field(
                name="💾 Backup System", 
                value=f"`{ctx.prefix}backup-server` - Create complete server backup\n"
                      f"`{ctx.prefix}list-backups` - View all available backups\n"
                      f"`{ctx.prefix}restore-backup <id>` - Restore a backup by ID",
                inline=False
            )

            # Verification System
            embed.add_field(
                name="✅ Verification System",
                value=f"`{ctx.prefix}setup-verification` - Setup user verification\n"
                      f"`{ctx.prefix}verify` - Start verification process\n"
                      f"`{ctx.prefix}verification-stats` - View verification stats",
                inline=False
            )

            embed.set_footer(text="All commands require admin permissions | Use !help <category> for detailed help")

        elif category.lower() == 'security':
            embed = discord.Embed(
                title="🔧 Server Protection",
                description="Server protection and safety tools",
                color=discord.Color.red()
            )

            embed.add_field(
                name="Protection Tools",
                value=f"`{ctx.prefix}lockdown` / `{ctx.prefix}lock [duration]` - Lock server (use 'permanent' for no time limit)\n"
                      f"`{ctx.prefix}lock perm` - Permanent server lockdown\n"
                      f"`{ctx.prefix}emergency-lock` / `{ctx.prefix}elock` - Complete server lockdown (text + voice)\n"
                      f"`{ctx.prefix}unlock` - Remove any lockdown\n"
                      f"`{ctx.prefix}security-scan` - Analyze server safety",
                inline=False
            )

        

        elif category.lower() == 'backup':
            embed = discord.Embed(
                title="💾 Backup System",
                description="Server backup and recovery tools",
                color=discord.Color.purple()
            )

            embed.add_field(
                name="Backup Commands",
                value=f"`{ctx.prefix}backup-server` - Create complete server backup\n"
                      f"`{ctx.prefix}list-backups` - View all available backups\n"
                      f"`{ctx.prefix}restore-backup <id>` - Restore a backup by ID",
                inline=False
            )

        elif category.lower() == 'verify':
            embed = discord.Embed(
                title="✅ Verification System",
                description="User verification and access control",
                color=discord.Color.teal()
            )

            embed.add_field(
                name="Verification Commands",
                value=f"`{ctx.prefix}setup-verification` - Setup verification system\n"
                      f"`{ctx.prefix}verify` - Start verification process\n"
                      f"`{ctx.prefix}verification-stats` - View verification statistics",
                inline=False
            )

        else:
            embed = create_error_embed(f"Unknown help category: {category}")
            await ctx.send(embed=embed)
            return

        embed.timestamp = discord.utils.utcnow()
        await ctx.send(embed=embed)





    @commands.command(name='settings')
    @require_admin_role()
    async def server_settings(self, ctx):
        """Display current server settings."""
        settings = self.get_guild_settings(ctx.guild.id)

        embed = discord.Embed(
            title="⚙️ Server Settings",
            description=f"Current settings for **{ctx.guild.name}**",
            color=discord.Color.blue()
        )

        # Anti-raid settings
        embed.add_field(
            name="🛡️ Anti-Raid Protection",
            value=f"**Enabled:** {'✅' if settings.get('anti_raid_enabled', True) else '❌'}\n"
                  f"**Join Rate Limit:** {settings.get('join_rate_limit', 5)}/minute\n"
                  f"**Mass Mention Limit:** {settings.get('mass_mention_limit', 3)}/message",
            inline=False
        )

        # Verification settings
        verification_channel_id = settings.get('verification_channel_id')
        verified_role_id = settings.get('verified_role_id')
        verification_channel = ctx.guild.get_channel(int(verification_channel_id)) if verification_channel_id else None
        verified_role = ctx.guild.get_role(int(verified_role_id)) if verified_role_id else None

        embed.add_field(
            name="✅ Verification System",
            value=f"**Enabled:** {'✅' if settings.get('verification_enabled', False) else '❌'}\n"
                  f"**Channel:** {verification_channel.mention if verification_channel else 'Not set'}\n"
                  f"**Role:** {verified_role.mention if verified_role else 'Not set'}",
            inline=False
        )

        # Backup settings
        embed.add_field(
            name="💾 Backup System",
            value=f"**Manual Backup:** ✅ Available\n"
                  f"**Storage:** Memory mode\n"
                  f"**Status:** Ready for manual backup",
            inline=False
        )

        # Security settings
        log_channel_id = settings.get('log_channel_id')
        log_channel = ctx.guild.get_channel(int(log_channel_id)) if log_channel_id else None
        embed.add_field(
            name="🔒 Security & Logging",
            value=f"**Auto-ban Scammers:** {'✅' if settings.get('auto_ban_scammers', True) else '❌'}\n"
                  f"**Event Logging:** {'✅ Active' if log_channel else '❌ Not configured'}\n"
                  f"**Log Channel:** {log_channel.mention if log_channel else '⚠️ Use `!set-log-channel #channel`'}",
            inline=False
        )

        embed.timestamp = datetime.utcnow()
        embed.set_footer(text="Use help commands to learn how to modify these settings")

        await ctx.send(embed=embed)

    @commands.command(name='set-log-channel', aliases=['set-logs', 'setlog'])
    @require_admin_role()
    async def set_log_channel(self, ctx, channel: discord.TextChannel):
        """Set the security log channel."""
        settings = self.get_guild_settings(ctx.guild.id)

        # Check if bot can send messages to the channel
        if not channel.permissions_for(ctx.guild.me).send_messages:
            await ctx.send(embed=create_error_embed("I don't have permission to send messages in that channel."))
            return

        # Save log channel to settings
        settings['log_channel_id'] = str(channel.id)
        db_wrapper.store_guild_settings(settings)

        embed = create_success_embed(
            "Log Channel Updated",
            f"Security events will now be logged to {channel.mention}\n\n"
            f"**Events that will be logged:**\n"
            f"• Message edits and deletions\n"
            f"• Member joins and leaves\n"
            f"• Bans and unbans\n"
            f"• Channel/role changes\n"
            f"• Voice activity\n"
            f"• Security events"
        )
        await ctx.send(embed=embed)

        # Send test message to log channel
        test_embed = discord.Embed(
            title="🛡️ Security Logging Enabled",
            description=f"This channel is now configured for comprehensive event logging.\n\n"
                       f"**Configured by:** {ctx.author.mention}\n"
                       f"**Events monitored:** Messages, Members, Channels, Roles, Voice, Security\n"
                       f"**Status:** ✅ Active",
            color=discord.Color.green(),
            timestamp=datetime.utcnow()
        )
        test_embed.set_footer(text=f"Server: {ctx.guild.name}")

        try:
            await channel.send(embed=test_embed)
        except discord.Forbidden:
            pass

    @commands.command(name='auto-ban-scammers', aliases=['auto-ban'])
    @require_admin_role()
    async def toggle_auto_ban(self, ctx, enabled: bool = None):
        """Enable or disable auto-banning of known scammers."""
        settings = self.get_guild_settings(ctx.guild.id)

        if enabled is None:
            # Show current status
            status = "Enabled" if settings.auto_ban_scammers else "Disabled"
            embed = create_info_embed(
                "Auto-Ban Status",
                f"Auto-banning of known scammers is currently **{status}**"
            )
            await ctx.send(embed=embed)
            return

        # In memory mode, this is just for demonstration
        # Would normally save to database

        status = "enabled" if enabled else "disabled"
        embed = create_success_embed(
            "Auto-Ban Updated",
            f"Auto-banning of known scammers has been **{status}**"
        )
        await ctx.send(embed=embed)

    @commands.command(name='server-stats', aliases=['stats'])
    async def server_stats(self, ctx):
        """Display detailed server statistics."""
        guild = ctx.guild

        # Count different channel types
        text_channels = len(guild.text_channels)
        voice_channels = len(guild.voice_channels)
        categories = len(guild.categories)

        # Count members by status
        online = sum(1 for m in guild.members if m.status == discord.Status.online)
        offline = sum(1 for m in guild.members if m.status == discord.Status.offline)
        bots = sum(1 for m in guild.members if m.bot)

        embed = discord.Embed(
            title=f"📊 {guild.name} Statistics",
            color=discord.Color.blue(),
            timestamp=datetime.utcnow()
        )

        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)

        embed.add_field(
            name="👥 Members",
            value=f"**Total:** {guild.member_count}\n"
                  f"**Online:** {online}\n"
                  f"**Offline:** {offline}\n"
                  f"**Bots:** {bots}",
            inline=True
        )

        embed.add_field(
            name="💬 Channels",
            value=f"**Text:** {text_channels}\n"
                  f"**Voice:** {voice_channels}\n"
                  f"**Categories:** {categories}\n"
                  f"**Total:** {len(guild.channels)}",
            inline=True
        )

        embed.add_field(
            name="🎭 Roles",
            value=f"**Total:** {len(guild.roles)}\n"
                  f"**Highest:** {guild.roles[-1].name}\n"
                  f"**Color Roles:** {sum(1 for r in guild.roles if r.color != discord.Color.default())}",
            inline=True
        )

        embed.add_field(
            name="🛡️ Security",
            value=f"**Verification:** {guild.verification_level.name.title()}\n"
                  f"**Content Filter:** {guild.explicit_content_filter.name.title()}\n"
                  f"**2FA Required:** {'Yes' if guild.mfa_level else 'No'}",
            inline=True
        )

        embed.add_field(
            name="📅 Server Info",
            value=f"**Created:** {guild.created_at.strftime('%Y-%m-%d')}\n"
                  f"**Owner:** {guild.owner.mention if guild.owner else 'Unknown'}\n"
                  f"**Region:** {getattr(guild, 'region', 'Unknown')}",
            inline=True
        )

        # Get guild settings for security info
        settings = self.get_guild_settings(guild.id)
        embed.add_field(
            name="🔒 Bot Security",
            value=f"**Anti-raid:** {'✅' if settings.get('anti_raid_enabled', True) else '❌'}\n"
                  f"**Backup:** ✅ Manual backup available\n"
                  f"**Verification:** {'✅' if settings.get('verification_enabled', False) else '❌'}",
            inline=True
        )

        await ctx.send(embed=embed)

    @commands.command(name='purge-bots', aliases=['purgeb'])
    @require_admin_role()
    async def purge_bots(self, ctx):
        """Remove all offline bots from the server."""
        embed = discord.Embed(
            title="⚠️ Purge Offline Bots",
            description="This will kick all offline bot accounts. React with ✅ to confirm.",
            color=discord.Color.orange()
        )

        message = await ctx.send(embed=embed)
        await message.add_reaction("✅")
        await message.add_reaction("❌")

        def check(reaction, user):
            return user == ctx.author and str(reaction.emoji) in ["✅", "❌"]

        try:
            reaction, user = await self.bot.wait_for('reaction_add', timeout=30.0, check=check)

            if str(reaction.emoji) == "❌":
                await ctx.send(embed=create_error_embed("Bot purge cancelled."))
                return

            offline_bots = [m for m in ctx.guild.members if m.bot and m.status == discord.Status.offline]
            kicked_count = 0

            for bot in offline_bots:
                try:
                    await bot.kick(reason=f"Offline bot purge by {ctx.author}")
                    kicked_count += 1
                except discord.Forbidden:
                    continue
                except Exception:
                    continue

            result_embed = create_success_embed(
                "Bot Purge Complete",
                f"Removed {kicked_count} offline bots from the server"
            )
            await ctx.send(embed=result_embed)

        except asyncio.TimeoutError:
            await ctx.send(embed=create_error_embed("Confirmation timed out."))

    @commands.command(name='emergency-stop', aliases=['emergency'])
    @require_admin_role()
    async def emergency_stop(self, ctx):
        """Emergency command to stop all bot operations temporarily."""
        embed = create_warning_embed(
            "🚨 Emergency Stop Activated",
            "Bot operations have been temporarily suspended. Use `!emergency-resume` to resume."
        )

        # In memory mode, this is just for demonstration
        # Would normally update database settings

        await ctx.send(embed=embed)

        await self.log_security_event(
            ctx.guild,
            "Emergency Stop",
            f"Emergency stop activated by {ctx.author.mention}",
            discord.Color.red()
        )

    @commands.command(name='whitelist-user', aliases=['whitelist'])
    @require_admin_role()
    async def whitelist_user(self, ctx, user: discord.Member):
        """Whitelist a user from all security checks."""
        # This would require adding a whitelist table to the database
        # For now, we'll just send a confirmation message
        embed = create_success_embed(
            "User Whitelisted",
            f"{user.mention} has been whitelisted from security checks.\n"
            f"Note: This feature requires database implementation."
        )
        await ctx.send(embed=embed)

    @commands.command(name='backup-server', aliases=['backup'])
    @require_admin_role()
    async def backup_server_command(self, ctx):
        """Create a complete backup of the server structure."""
        # Create backup data
        backup_data = {
            'guild_info': {
                'name': ctx.guild.name,
                'description': ctx.guild.description,
                'icon_url': str(ctx.guild.icon.url) if ctx.guild.icon else None,
                'verification_level': str(ctx.guild.verification_level),
                'explicit_content_filter': str(ctx.guild.explicit_content_filter),
                'default_notifications': str(ctx.guild.default_notifications)
            },
            'channels': [],
            'roles': [],
            'created_at': datetime.utcnow().isoformat()
        }

        # Backup channels
        for channel in ctx.guild.channels:
            channel_data = {
                'id': str(channel.id),
                'name': channel.name,
                'type': str(channel.type),
                'position': channel.position
            }

            if isinstance(channel, discord.TextChannel):
                channel_data.update({
                    'topic': channel.topic,
                    'slowmode_delay': channel.slowmode_delay,
                    'nsfw': channel.nsfw
                })
            elif isinstance(channel, discord.VoiceChannel):
                channel_data.update({
                    'bitrate': channel.bitrate,
                    'user_limit': channel.user_limit
                })
            elif isinstance(channel, discord.CategoryChannel):
                channel_data['channels'] = [str(c.id) for c in channel.channels]

            backup_data['channels'].append(channel_data)

        # Backup roles (excluding @everyone and bot roles)
        for role in ctx.guild.roles:
            if role.name != "@everyone" and not role.managed:
                role_data = {
                    'id': str(role.id),
                    'name': role.name,
                    'color': role.color.value,
                    'permissions': role.permissions.value,
                    'hoist': role.hoist,
                    'mentionable': role.mentionable,
                    'position': role.position
                }
                backup_data['roles'].append(role_data)

        # Store backup using database wrapper
        success = db_wrapper.store_backup(str(ctx.guild.id), ctx.guild.name, backup_data, str(ctx.author.id))

        if success:
            embed = create_success_embed(
                "Server Backup Created",
                f"Successfully backed up **{ctx.guild.name}**\n"
                f"**Channels:** {len(backup_data['channels'])}\n"
                f"**Roles:** {len(backup_data['roles'])}\n"
                f"**Created by:** {ctx.author.mention}"
            )
        else:
            embed = create_error_embed("Backup failed to save")

        await ctx.send(embed=embed)

        await self.log_security_event(
            ctx.guild,
            "Server Backup",
            f"Server backup created by {ctx.author.mention}",
            discord.Color.green()
        )

    @commands.command(name='restore-backup', aliases=['restore'])
    @require_admin_role()
    async def restore_backup_command(self, ctx, backup_id: int = None):
        """Restore a server backup by ID."""
        if backup_id is None:
            await ctx.send(embed=create_error_embed("Missing Backup ID", "Please specify a backup ID. Use `!list-backups` to see available backups."))
            return

        # Get available backups
        backups = db_wrapper.get_backups(str(ctx.guild.id))

        if not backups:
            await ctx.send(embed=create_error_embed("No Backups", "No backups found for this server."))
            return

        # Find the requested backup (adjust for 0-indexed list)
        backup = None
        for i, b in enumerate(backups):
            if i + 1 == backup_id:  # Use 1-based indexing for user display
                backup = b
                backup['id'] = i + 1  # Set display ID
                break

        if not backup:
            await ctx.send(embed=create_error_embed("Backup Not Found", f"No backup with ID {backup_id} found for this server."))
            return

        # Confirmation prompt
        embed = discord.Embed(
            title="⚠️ Restore Backup Confirmation",
            description=f"**WARNING:** This will restore the server to backup #{backup_id}\n"
                       f"**Created:** {backup['created_at']}\n"
                       f"**Created by:** <@{backup['created_by']}>\n"
                       f"**Channels:** {backup['channel_count']}\n"
                       f"**Roles:** {backup['role_count']}\n\n"
                       f"**This action will:**\n"
                       f"• Delete current channels not in backup\n"
                       f"• Recreate channels from backup\n"
                       f"• Restore roles (excluding managed roles)\n\n"
                       f"React with ✅ to confirm or ❌ to cancel.",
            color=discord.Color.red()
        )

        message = await ctx.send(embed=embed)
        await message.add_reaction("✅")
        await message.add_reaction("❌")

        def check(reaction, user):
            return user == ctx.author and str(reaction.emoji) in ["✅", "❌"]

        try:
            reaction, user = await self.bot.wait_for('reaction_add', timeout=60.0, check=check)

            if str(reaction.emoji) == "❌":
                await ctx.send(embed=create_error_embed("Restore Cancelled", "Backup restore has been cancelled."))
                return

            # Start restoration process
            restore_embed = discord.Embed(
                title="🔄 Restoring Backup...",
                description="This may take several minutes. Please wait...",
                color=discord.Color.orange()
            )
            status_message = await ctx.send(embed=restore_embed)

            backup_data = backup['backup_data']
            restored_channels = 0
            restored_roles = 0
            errors = []

            try:
                # Restore roles first (excluding @everyone and managed roles)
                existing_role_names = [role.name.lower() for role in ctx.guild.roles]

                for role_data in backup_data.get('roles', []):
                    try:
                        if role_data['name'].lower() not in existing_role_names:
                            await ctx.guild.create_role(
                                name=role_data['name'],
                                permissions=discord.Permissions(permissions=role_data['permissions']),
                                color=discord.Color(role_data['color']),
                                hoist=role_data['hoist'],
                                mentionable=role_data['mentionable'],
                                reason=f"Backup restore #{backup_id}"
                            )
                            restored_roles += 1
                    except Exception as e:
                        errors.append(f"Role '{role_data['name']}': {str(e)}")

                # Store backup channel data for recreation
                backup_channels = backup_data.get('channels', [])
                category_mapping = {}

                # Delete existing channels (except system channels)
                channels_to_delete = []
                categories_to_delete = []

                for channel in ctx.guild.channels:
                    if channel.name.lower() not in ['rules', 'announcements', 'general']:
                        if isinstance(channel, discord.CategoryChannel):
                            categories_to_delete.append(channel)
                        else:
                            channels_to_delete.append(channel)

                # Delete non-category channels first
                for channel in channels_to_delete:
                    try:
                        await channel.delete(reason=f"Backup restore #{backup_id}")
                        await asyncio.sleep(0.5)  # Rate limit protection
                    except Exception as e:
                        errors.append(f"Failed to delete {channel.name}: {str(e)}")

                # Delete categories
                for category in categories_to_delete:
                    try:
                        await category.delete(reason=f"Backup restore #{backup_id}")
                        await asyncio.sleep(0.5)  # Rate limit protection
                    except Exception as e:
                        errors.append(f"Failed to delete category {category.name}: {str(e)}")

                # Create categories first
                for channel_data in backup_channels:
                    if 'category' in str(channel_data.get('type', '')).lower():
                        try:
                            category = await ctx.guild.create_category(
                                name=channel_data['name'],
                                reason=f"Backup restore #{backup_id}"
                            )
                            category_mapping[channel_data['id']] = category
                            restored_channels += 1
                            await asyncio.sleep(0.5)  # Rate limit protection
                        except Exception as e:
                            errors.append(f"Category '{channel_data['name']}': {str(e)}")

                # Create text and voice channels
                for channel_data in backup_channels:
                    channel_type = str(channel_data.get('type', '')).lower()
                    if 'text' in channel_type or 'voice' in channel_type:
                        try:
                            # Find parent category
                            category = None
                            for cat_data in backup_channels:
                                if ('category' in str(cat_data.get('type', '')).lower() and 
                                    channel_data['id'] in cat_data.get('channels', [])):
                                    category = category_mapping.get(cat_data['id'])
                                    break

                            if 'text' in channel_type:
                                await ctx.guild.create_text_channel(
                                    name=channel_data['name'],
                                    category=category,
                                    topic=channel_data.get('topic'),
                                    slowmode_delay=channel_data.get('slowmode_delay', 0),
                                    nsfw=channel_data.get('nsfw', False),
                                    reason=f"Backup restore #{backup_id}"
                                )
                                restored_channels += 1
                            elif 'voice' in channel_type:
                                await ctx.guild.create_voice_channel(
                                    name=channel_data['name'],
                                    category=category,
                                    bitrate=min(channel_data.get('bitrate', 64000), ctx.guild.bitrate_limit),
                                    user_limit=channel_data.get('user_limit', 0),
                                    reason=f"Backup restore #{backup_id}"
                                )
                                restored_channels += 1

                            await asyncio.sleep(0.5)  # Rate limit protection
                        except Exception as e:
                            errors.append(f"Channel '{channel_data['name']}': {str(e)}")

                # Update success message
                success_embed = create_success_embed(
                    "Backup Restored Successfully",
                    f"**Backup ID:** #{backup_id}\n"
                    f"**Channels Restored:** {restored_channels}\n"
                    f"**Roles Restored:** {restored_roles}\n"
                    f"**Errors:** {len(errors)}"
                )

                if errors:
                    error_text = '\n'.join(errors[:5])
                    if len(errors) > 5:
                        error_text += f"\n... and {len(errors) - 5} more errors"
                    success_embed.add_field(name="Errors", value=error_text, inline=False)

                await status_message.edit(embed=success_embed)

                # Log the restoration
                await self.log_security_event(
                    ctx.guild,
                    "Backup Restored",
                    f"Backup #{backup_id} restored by {ctx.author.mention}\n"
                    f"Restored {restored_channels} channels and {restored_roles} roles",
                    discord.Color.green()
                )

            except Exception as e:
                error_embed = create_error_embed(
                    "Restore Failed",
                    f"An error occurred during restoration: {str(e)}"
                )
                await status_message.edit(embed=error_embed)

        except asyncio.TimeoutError:
            await ctx.send(embed=create_error_embed("Confirmation Timeout", "Backup restore confirmation timed out."))

    @commands.command(name='list-backups', aliases=['backups'])
    @require_admin_role()
    async def list_backups_command(self, ctx):
        """List all backups for this server."""
        backups = db_wrapper.get_backups(str(ctx.guild.id))

        if not backups:
            await ctx.send(embed=create_info_embed("No Backups", "No backups found for this server."))
            return

        embed = discord.Embed(
            title="📋 Server Backups",
            description=f"Available backups for **{ctx.guild.name}**",
            color=discord.Color.blue()
        )

        backup_list = ""
        for i, backup in enumerate(backups[:10], 1):
            backup_list += f"**{i}.** Backup #{backup['id']}\n"
            backup_list += f"└ Created: {backup['created_at']}\n"
            backup_list += f"└ By: <@{backup['created_by']}>\n"
            backup_list += f"└ Channels: {backup['channel_count']}, Roles: {backup['role_count']}\n\n"

        embed.add_field(name="Available Backups", value=backup_list or "No backups", inline=False)
        embed.set_footer(text="Backups are stored in memory mode")

        await ctx.send(embed=embed)

    @commands.command(name='security-logs', aliases=['log'])
    @require_admin_role()
    async def security_log(self, ctx):
        """View comprehensive security logs and system status."""
        # Get database status
        db_status = db_wrapper.get_status()

        # Get bot activity logs
        activity_logs = db_wrapper.get_activity_logs(str(ctx.guild.id))

        embed = discord.Embed(
            title="🔍 Security System Dashboard",
            description=f"**Security Status for {ctx.guild.name}**",
            color=discord.Color.blue()
        )

        # System Status
        embed.add_field(
            name="🖥️ System Status",
            value=f"**Database:** {'🟢 Connected' if db_status['database_available'] else '🟡 Memory Mode'}\n"
                  f"**Anti-Raid:** 🟢 Active\n"
                  f"**Auto-Backup:** 🟢 Enabled\n"
                  f"**Verification:** 🟢 Ready",
            inline=True
        )

        # Security Statistics
        embed.add_field(
            name="📊 Security Stats",
            value=f"**Scammers Blocked:** {db_status['fallback_scammers']}\n"
                  f"**Backups Created:** {db_status['fallback_backups']}\n"
                  f"**Verifications:** {db_status['fallback_verifications']}\n"
                  f"**Server Members:** {ctx.guild.member_count}",
            inline=True
        )

        # Recent Activity
        if activity_logs:
            activity_text = ""
            for log in activity_logs[:5]:
                activity_text += f"• {log['timestamp']} - {log['event']}\n"
        else:
            activity_text = "• System monitoring active\n• No recent security events\n• All systems operational"

        embed.add_field(
            name="📝 Recent Activity",
            value=activity_text,
            inline=False
        )

        # Security Recommendations
        recommendations = []
        settings = self.get_guild_settings(ctx.guild.id)

        if not settings.get('verification_enabled'):
            recommendations.append("Enable verification system")
        if not settings.get('log_channel_id'):
            recommendations.append("Set up security log channel")
        if ctx.guild.verification_level.value < 2:
            recommendations.append("Increase server verification level")

        if recommendations:
            embed.add_field(
                name="💡 Security Recommendations",
                value='\n'.join(f"• {rec}" for rec in recommendations[:3]),
                inline=False
            )

        # Guild Security Score
        score = 85
        if settings.get('verification_enabled'):
            score += 5
        if settings.get('log_channel_id'):
            score += 5
        if ctx.guild.verification_level.value >= 2:
            score += 5

        embed.add_field(
            name="🛡️ Security Score",
            value=f"**{score}/100** {'🟢 Excellent' if score >= 90 else '🟡 Good' if score >= 75 else '🟠 Fair'}",
            inline=True
        )

        embed.timestamp = datetime.utcnow()
        embed.set_footer(text="Security logs updated in real-time")

        await ctx.send(embed=embed)

    @commands.command(name='activity-log', aliases=['activity'])
    @require_admin_role()
    async def activity_log(self, ctx, limit: int = 20):
        """View detailed activity logs."""
        if limit > 50:
            limit = 50
        elif limit < 1:
            limit = 10

        logs = db_wrapper.get_activity_logs(str(ctx.guild.id), limit)

        embed = discord.Embed(
            title="📋 Activity Log",
            description=f"Last {len(logs)} events in **{ctx.guild.name}**",
            color=discord.Color.blue()
        )

        if logs:
            log_text = ""
            for log in logs:
                emoji = {
                    'member_join': '👋',
                    'member_leave': '👋',
                    'message_delete': '🗑️',
                    'role_update': '🎭',
                    'channel_update': '📝',
                    'security_event': '🛡️',
                    'backup_created': '💾',
                    'verification': '✅'
                }.get(log['event_type'], '📝')

                log_text += f"{emoji} **{log['timestamp']}**\n"
                log_text += f"└ {log['event']}\n\n"
        else:
            log_text = "No recent activity recorded.\nSystem is monitoring for events..."

        embed.add_field(name="Recent Events", value=log_text[:4000], inline=False)
        embed.set_footer(text="Activity logs are stored in memory")

        await ctx.send(embed=embed)

    @commands.command(name='why-administrator', aliases=['why-admin'])
    async def why_administrator(self, ctx):
        """Explain why administrator permissions are required."""
        embed = discord.Embed(
            title="🛡️ Why Administrator Permissions?",
            description="This security bot requires Administrator permissions for several critical reasons:",
            color=discord.Color.blue()
        )

        embed.add_field(
            name="🚨 Anti-Raid Protection",
            value="• **Ban malicious users** during raids\n"
                  "• **Delete spam messages** rapidly\n"
                  "• **Lockdown channels** to prevent damage\n"
                  "• **Manage roles** for verification systems",
            inline=False
        )

        embed.add_field(
            name="💾 Server Backup & Restore",
            value="• **Create/delete channels** during restoration\n"
                  "• **Create/modify roles** from backups\n"
                  "• **Access all channels** for comprehensive backups\n"
                  "• **Manage permissions** on restored content",
            inline=False
        )

        embed.add_field(
            name="🔍 Security Monitoring",
            value="• **View audit logs** to track security events\n"
                  "• **Access member lists** to identify threats\n"
                  "• **Monitor all channels** for suspicious activity\n"
                  "• **Manage webhooks** that could be exploited",
            inline=False
        )

        embed.add_field(
            name="⚡ Emergency Response",
            value="• **Immediate action** during security incidents\n"
                  "• **Server lockdown** capabilities\n"
                  "• **Mass user management** during raids\n"
                  "• **Quick channel cleanup** after attacks",
            inline=False
        )

        embed.add_field(
            name="🔒 Security Guarantee",
            value="**This bot does NOT:**\n"
                  "• Delete your server without explicit backup restore commands\n"
                  "• Share your server data with third parties\n"
                  "• Modify settings without command usage\n"
                  "• Act without administrator input\n\n"
                  "**All destructive actions require explicit confirmation.**",
            inline=False
        )

        embed.set_footer(text="Administrator permissions ensure complete server protection")
        await ctx.send(embed=embed)

    @app_commands.command(name="settings", description="View server security settings")
    @app_commands.describe()
    async def slash_settings(self, interaction: discord.Interaction):
        """Slash command to display server settings."""
        # Check admin permissions
        if not interaction.user.guild_permissions.administrator:
            embed = create_error_embed("Permission Denied", "You need the Administrator permission to use this command.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        settings = self.get_guild_settings(interaction.guild.id)

        embed = discord.Embed(
            title="⚙️ Server Settings",
            description=f"Current settings for **{interaction.guild.name}**",
            color=discord.Color.blue()
        )

        # Anti-raid settings
        embed.add_field(
            name="🛡️ Anti-Raid Protection",
            value=f"**Enabled:** {'✅' if settings.get('anti_raid_enabled', True) else '❌'}\n"
                  f"**Join Rate Limit:** {settings.get('join_rate_limit', 5)}/minute\n"
                  f"**Mass Mention Limit:** {settings.get('mass_mention_limit', 3)}/message",
            inline=False
        )

        # Verification settings
        verification_channel_id = settings.get('verification_channel_id')
        verified_role_id = settings.get('verified_role_id')
        verification_channel = interaction.guild.get_channel(int(verification_channel_id)) if verification_channel_id else None
        verified_role = interaction.guild.get_role(int(verified_role_id)) if verified_role_id else None

        embed.add_field(
            name="✅ Verification System",
            value=f"**Enabled:** {'✅' if settings.get('verification_enabled', False) else '❌'}\n"
                  f"**Channel:** {verification_channel.mention if verification_channel else 'Not set'}\n"
                  f"**Role:** {verified_role.mention if verified_role else 'Not set'}",
            inline=False
        )

        # Backup settings
        embed.add_field(
            name="💾 Backup System",
            value=f"**Manual Backup:** ✅ Available\n"
                  f"**Storage:** Memory mode\n"
                  f"**Status:** Ready for manual backup",
            inline=False
        )

        # Security settings
        log_channel_id = settings.get('log_channel_id')
        log_channel = interaction.guild.get_channel(int(log_channel_id)) if log_channel_id else None
        embed.add_field(
            name="🔒 Security & Logging",
            value=f"**Auto-ban Scammers:** {'✅' if settings.get('auto_ban_scammers', True) else '❌'}\n"
                  f"**Event Logging:** {'✅ Active' if log_channel else '❌ Not configured'}\n"
                  f"**Log Channel:** {log_channel.mention if log_channel else '⚠️ Use `/set-log-channel` or `!set-log-channel #channel`'}",
            inline=False
        )

        embed.timestamp = datetime.utcnow()
        embed.set_footer(text="Use help commands to learn how to modify these settings")

        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="set-log-channel", description="Set the security log channel")
    @app_commands.describe(channel="The channel where security events will be logged")
    async def slash_set_log_channel(self, interaction: discord.Interaction, channel: discord.TextChannel):
        """Slash command to set log channel."""
        # Check admin permissions
        if not interaction.user.guild_permissions.administrator:
            embed = create_error_embed("Permission Denied", "You need the Administrator permission to use this command.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        settings = self.get_guild_settings(interaction.guild.id)

        # Check if bot can send messages to the channel
        if not channel.permissions_for(interaction.guild.me).send_messages:
            await interaction.response.send_message(embed=create_error_embed("Permission Error", "I don't have permission to send messages in that channel."), ephemeral=True)
            return

        # Save log channel to settings
        settings['log_channel_id'] = str(channel.id)
        db_wrapper.store_guild_settings(settings)

        embed = create_success_embed(
            "Log Channel Updated",
            f"Security events will now be logged to {channel.mention}\n\n"
            f"**Events that will be logged:**\n"
            f"• Message edits and deletions\n"
            f"• Member joins and leaves\n"
            f"• Bans and unbans\n"
            f"• Channel/role changes\n"
            f"• Voice activity\n"
            f"• Security events"
        )
        await interaction.response.send_message(embed=embed)

        # Send test message to log channel
        test_embed = discord.Embed(
            title="🛡️ Security Logging Enabled",
            description=f"This channel is now configured for comprehensive event logging.\n\n"
                       f"**Configured by:** {interaction.user.mention}\n"
                       f"**Events monitored:** Messages, Members, Channels, Roles, Voice, Security\n"
                       f"**Status:** ✅ Active",
            color=discord.Color.green(),
            timestamp=datetime.utcnow()
        )
        test_embed.set_footer(text=f"Server: {interaction.guild.name}")

        try:
            await channel.send(embed=test_embed)
        except discord.Forbidden:
            pass

    @app_commands.command(name="backup-server", description="Create a complete backup of the server structure")
    async def slash_backup_server(self, interaction: discord.Interaction):
        """Slash command to backup server."""
        # Check admin permissions
        if not interaction.user.guild_permissions.administrator:
            embed = create_error_embed("Permission Denied", "You need the Administrator permission to use this command.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        await interaction.response.defer()

        # Create backup data
        backup_data = {
            'guild_info': {
                'name': interaction.guild.name,
                'description': interaction.guild.description,
                'icon_url': str(interaction.guild.icon.url) if interaction.guild.icon else None,
                'verification_level': str(interaction.guild.verification_level),
                'explicit_content_filter': str(interaction.guild.explicit_content_filter),
                'default_notifications': str(interaction.guild.default_notifications)
            },
            'channels': [],
            'roles': [],
            'created_at': datetime.utcnow().isoformat()
        }

        # Backup channels
        for channel in interaction.guild.channels:
            channel_data = {
                'id': str(channel.id),
                'name': channel.name,
                'type': str(channel.type),
                'position': channel.position
            }

            if isinstance(channel, discord.TextChannel):
                channel_data.update({
                    'topic': channel.topic,
                    'slowmode_delay': channel.slowmode_delay,
                    'nsfw': channel.nsfw
                })
            elif isinstance(channel, discord.VoiceChannel):
                channel_data.update({
                    'bitrate': channel.bitrate,
                    'user_limit': channel.user_limit
                })
            elif isinstance(channel, discord.CategoryChannel):
                channel_data['channels'] = [str(c.id) for c in channel.channels]

            backup_data['channels'].append(channel_data)

        # Backup roles (excluding @everyone and bot roles)
        for role in interaction.guild.roles:
            if role.name != "@everyone" and not role.managed:
                role_data = {
                    'id': str(role.id),
                    'name': role.name,
                    'color': role.color.value,
                    'permissions': role.permissions.value,
                    'hoist': role.hoist,
                    'mentionable': role.mentionable,
                    'position': role.position
                }
                backup_data['roles'].append(role_data)

        # Store backup using database wrapper
        success = db_wrapper.store_backup(str(interaction.guild.id), interaction.guild.name, backup_data, str(interaction.user.id))

        if success:
            embed = create_success_embed(
                "Server Backup Created",
                f"Successfully backed up **{interaction.guild.name}**\n"
                f"**Channels:** {len(backup_data['channels'])}\n"
                f"**Roles:** {len(backup_data['roles'])}\n"
                f"**Created by:** {interaction.user.mention}"
            )
        else:
            embed = create_error_embed("Backup Error", "Backup failed to save")

        await interaction.followup.send(embed=embed)

        await self.log_security_event(
            interaction.guild,
            "Server Backup",
            f"Server backup created by {interaction.user.mention}",
            discord.Color.green()
        )



    @app_commands.command(name="help", description="Display comprehensive command help")
    async def slash_help(self, interaction: discord.Interaction):
        """Slash command version of help."""
        embed = discord.Embed(
            title="🛡️ Vireon Security Bot Commands",
            description="**Advanced server protection and administration system**",
            color=discord.Color.blue()
        )

        # Basic Commands
        embed.add_field(
            name="🔧 Basic Commands",
            value="`/ping` - Check bot latency and status\n"
                  "`/info` - Bot information and statistics\n"
                  "`/settings` - View server security settings\n"
                  "`/set-log-channel #channel` - Set logging channel\n"
                  "`/version-help` - Version and quick help\n"
                  "`!log` - View security event logs\n"
                  "`!activity-log` - View detailed activity logs",
            inline=False
        )

        # Logging System
        embed.add_field(
            name="📝 Message Logging",
            value="`/set-log-channel` - Set channel for all logs\n"
                  "`!toggle-message-logs` - Track edited/deleted messages\n"
                  "`!toggle-member-logs` - Track joins/leaves\n"
                  "`!logging-status` - View logging configuration",
            inline=False
        )

        # Server Protection & AutoMod
        embed.add_field(
            name="🔧 Server Protection & AutoMod",
            value="`!lockdown` - Emergency server lockdown\n"
                  "`!unlock` - Remove server lockdown\n"
                  "`!security-scan` - Run server safety analysis\n"
                  "`!automod` or `/automod` - View AutoMod status\n"
                  "`!automod-toggle` or `/automod-toggle` - Enable/disable AutoMod\n"
                  "`!automod-setup` or `/automod-setup` - Configure AutoMod settings\n"
                  "`!auto-ban-toggle` - Enable/disable scammer auto-ban\n"
                  "`!check-scammer <user>` - Check if user is known scammer",
            inline=False
        )

        # Moderation Commands
        embed.add_field(
            name="👮 Moderation Commands",
            value="`/kick @user [reason]` or `!kick @user [reason]` - Kick a user from server\n"
                  "`/ban @user [reason]` or `!ban @user [reason]` - Ban a user from server\n"
                  "`/unban <user_id> [reason]` or `!unban <user_id> [reason]` - Unban a user by ID\n"
                  "`/mute @user [minutes] [reason]` or `!mute @user [minutes] [reason]` - Timeout a user\n"
                  "`/unmute @user [reason]` or `!unmute @user [reason]` - Remove user timeout\n"
                  "`/warn @user [reason]` or `!warn @user [reason]` - Issue warning to user\n"
                  "`!mass-ban <user_ids>` - Ban multiple users by IDs\n"
                  "`!audit-log [limit]` - View recent audit log entries\n"
                  "`!member-info @user` - Get detailed member information\n"
                  "`!kick-inactive [days]` - Remove inactive members\n"
                  "`!channel-lockdown [channels]` - Lock specific channels\n"
                  "`!role-audit` - Audit dangerous role permissions",
            inline=False
        )

        

        # Backup System
        embed.add_field(
            name="💾 Backup System", 
            value="`/backup-server` - Create complete server backup\n"
                  "`!list-backups` - View all available backups\n"
                  "`!restore-backup <id>` - Restore a backup by ID",
            inline=False
        )

        # Verification System
        embed.add_field(
            name="✅ Verification System",
            value="`!setup-verification` - Setup user verification\n"
                  "`!verify` - Start verification process\n"
                  "`!verification-stats` - View verification stats",
            inline=False
        )

        embed.set_footer(text="All commands require admin permissions | Mix of slash (/) and text (!) commands")

        await interaction.response.send_message(embed=embed)