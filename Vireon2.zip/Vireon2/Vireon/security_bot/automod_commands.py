"""
AutoMod Commands Module
Handles automated moderation features including spam detection, content filtering, and rule enforcement.
"""

import discord
from discord.ext import commands
import asyncio
import re
from datetime import datetime, timedelta
from collections import defaultdict
from .permissions import require_admin_role
from .utils import create_success_embed, create_error_embed, create_warning_embed, create_info_embed

class AutoModCommands(commands.Cog):
    """AutoMod system for automated server moderation."""
    
    def __init__(self, bot):
        self.bot = bot
        self.user_message_cache = defaultdict(list)  # Track recent messages per user
        self.user_warnings = defaultdict(int)  # Track warnings per user
        self.spam_timeouts = {}  # Track users in timeout for spam
        
        # Default automod settings
        self.default_settings = {
            'automod_enabled': True,
            'spam_detection': True,
            'spam_message_limit': 5,  # messages
            'spam_time_window': 10,   # seconds
            'spam_action': 'timeout', # timeout, kick, ban, warn
            'spam_timeout_duration': 300,  # 5 minutes
            'caps_filter': True,
            'caps_percentage': 70,    # % of caps to trigger
            'caps_min_length': 10,    # minimum message length to check
            'link_filter': False,
            'allowed_domains': [],
            'invite_filter': True,
            'repeated_text_filter': True,
            'repeated_text_limit': 4,  # same message count
            'mass_mention_filter': True,
            'mass_mention_limit': 5,
            'bad_words_filter': True,
            'bad_words_list': [
                # Racial slurs and hate speech
                'nigger', 'nigga', 'nigg', 'n1gg', 'n1gga', 'nig', 'negro',
                'faggot', 'fag', 'f4g', 'f4gg0t', 'homo', 'dyke', 'tranny',
                'retard', 'retarded', 'autistic', 'spastic', 'mongoloid',
                'kike', 'jew', 'jewboy', 'goyim', 'chink', 'gook', 'wetback',
                'spic', 'beaner', 'towelhead', 'raghead', 'camel jockey',
                # Other offensive terms
                'whore', 'slut', 'bitch', 'cunt', 'twat', 'pussy',
                'cock', 'dick', 'penis', 'vagina', 'tits', 'boobs',
                'fuck', 'fucking', 'shit', 'damn', 'hell', 'ass',
                'piss', 'bastard', 'motherfucker', 'asshole'
            ],
            'automod_log_channel': None,
            'automod_immune_roles': [],
            'violation_threshold': 3,  # warnings before action
            'escalation_actions': ['warn', 'timeout', 'kick', 'ban'],
            'bad_word_action': 'delete_warn',  # delete_warn, timeout, kick, ban
            'bad_word_timeout_duration': 600,  # 10 minutes
            'bypass_detection': True,  # detect attempts to bypass filters
            'zero_tolerance_words': [  # Immediate severe action for these words
                'nigger', 'faggot', 'kike', 'chink', 'spic'
            ]
        }

    def get_automod_settings(self, guild_id):
        """Get automod settings for a guild with defaults."""
        try:
            from database_wrapper import db_wrapper
            settings = db_wrapper.get_guild_settings(str(guild_id))
            automod_settings = settings.get('automod', {})
            
            # Merge with defaults
            for key, default_value in self.default_settings.items():
                if key not in automod_settings:
                    automod_settings[key] = default_value
                    
            return automod_settings
        except Exception:
            return self.default_settings.copy()

    def save_automod_settings(self, guild_id, automod_settings):
        """Save automod settings for a guild."""
        try:
            from database_wrapper import db_wrapper
            settings = db_wrapper.get_guild_settings(str(guild_id))
            settings['automod'] = automod_settings
            db_wrapper.save_guild_settings(str(guild_id), settings)
        except Exception:
            pass

    async def is_immune_user(self, member, automod_settings):
        """Check if user is immune to automod actions."""
        # Only bot owner is immune for testing - remove admin immunity for now
        if member.id == 898498764199854100:  # Your user ID - you can test automod
            return False
            
        immune_roles = automod_settings.get('automod_immune_roles', [])
        user_role_ids = [role.id for role in member.roles]
        
        return any(role_id in immune_roles for role_id in user_role_ids)

    async def log_automod_action(self, guild, action, user, reason, details=""):
        """Log automod actions to the designated channel."""
        automod_settings = self.get_automod_settings(guild.id)
        log_channel_id = automod_settings.get('automod_log_channel')
        
        if not log_channel_id:
            return
            
        log_channel = guild.get_channel(int(log_channel_id))
        if not log_channel:
            return

        embed = discord.Embed(
            title="🤖 AutoMod Action",
            color=discord.Color.orange(),
            timestamp=datetime.utcnow()
        )
        
        embed.add_field(name="Action", value=action, inline=True)
        embed.add_field(name="User", value=f"{user.mention} ({user.id})", inline=True)
        embed.add_field(name="Reason", value=reason, inline=True)
        
        if details:
            embed.add_field(name="Details", value=details, inline=False)
            
        embed.set_footer(text=f"AutoMod • {guild.name}")
        
        try:
            await log_channel.send(embed=embed)
        except Exception:
            pass

    async def apply_automod_action(self, member, action, reason, duration=None):
        """Apply automod action to a user."""
        try:
            if action == 'warn':
                self.user_warnings[member.id] += 1
                await self.log_automod_action(member.guild, "Warning", member, reason)
                
            elif action == 'timeout':
                timeout_duration = duration or 300  # 5 minutes default
                await member.timeout(timedelta(seconds=timeout_duration), reason=f"AutoMod: {reason}")
                await self.log_automod_action(member.guild, f"Timeout ({timeout_duration}s)", member, reason)
                
            elif action == 'kick':
                await member.kick(reason=f"AutoMod: {reason}")
                await self.log_automod_action(member.guild, "Kick", member, reason)
                
            elif action == 'ban':
                await member.ban(reason=f"AutoMod: {reason}", delete_message_days=1)
                await self.log_automod_action(member.guild, "Ban", member, reason)
                
        except discord.Forbidden:
            await self.log_automod_action(member.guild, f"Failed {action}", member, f"Missing permissions: {reason}")
        except Exception as e:
            await self.log_automod_action(member.guild, f"Error {action}", member, f"Error: {str(e)}")

    async def process_message_for_automod(self, message):
        """Process message for automod violations (called from main bot)."""
        if message.author.bot or not message.guild:
            return

        automod_settings = self.get_automod_settings(message.guild.id)
        
        if not automod_settings.get('automod_enabled', True):  # Default to True
            return

        # Check if user is immune
        if await self.is_immune_user(message.author, automod_settings):
            print(f"User {message.author} is immune to automod")
            return

        violations = []
        
        # Spam Detection
        if automod_settings.get('spam_detection', True):
            user_id = message.author.id
            now = datetime.utcnow()
            
            # Clean old messages
            self.user_message_cache[user_id] = [
                msg_time for msg_time in self.user_message_cache[user_id]
                if (now - msg_time).total_seconds() < automod_settings.get('spam_time_window', 10)
            ]
            
            # Add current message
            self.user_message_cache[user_id].append(now)
            
            # Check spam threshold
            if len(self.user_message_cache[user_id]) >= automod_settings.get('spam_message_limit', 5):
                violations.append("Spam detected")
                
        # Caps Filter
        if automod_settings.get('caps_filter', True) and len(message.content) >= automod_settings.get('caps_min_length', 10):
            caps_count = sum(1 for c in message.content if c.isupper())
            caps_percentage = (caps_count / len(message.content)) * 100
            
            if caps_percentage >= automod_settings.get('caps_percentage', 70):
                violations.append("Excessive caps")
                
        # Invite Filter
        if automod_settings.get('invite_filter', True):
            invite_pattern = r'discord\.gg/|discordapp\.com/invite/|discord\.com/invite/'
            if re.search(invite_pattern, message.content, re.IGNORECASE):
                violations.append("Discord invite link")
                
        # Link Filter
        if automod_settings.get('link_filter', False):
            url_pattern = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
            urls = re.findall(url_pattern, message.content)
            
            allowed_domains = automod_settings.get('allowed_domains', [])
            for url in urls:
                domain = re.search(r'://([^/]+)', url)
                if domain and domain.group(1) not in allowed_domains:
                    violations.append("Unauthorized link")
                    break
                    
        # Mass Mention Filter
        if automod_settings.get('mass_mention_filter', True):
            mention_count = len(message.mentions) + len(message.role_mentions)
            if mention_count >= automod_settings.get('mass_mention_limit', 5):
                violations.append("Mass mentions")
                
        # Repeated Text Filter
        if automod_settings.get('repeated_text_filter', True):
            words = message.content.split()
            word_counts = defaultdict(int)
            for word in words:
                word_counts[word.lower()] += 1
                if word_counts[word.lower()] >= automod_settings.get('repeated_text_limit', 4):
                    violations.append("Repeated text")
                    break
                    
        # Bad Words Filter
        if automod_settings.get('bad_words_filter', True):
            bad_words = automod_settings.get('bad_words_list', [])
            zero_tolerance = automod_settings.get('zero_tolerance_words', [])
            content_lower = message.content.lower()
            
            # Remove special characters and numbers to detect bypassing
            if automod_settings.get('bypass_detection', True):
                clean_content = re.sub(r'[^a-z\s]', '', content_lower)
                clean_content = re.sub(r'\s+', ' ', clean_content).strip()
            else:
                clean_content = content_lower
            
            detected_word = None
            is_zero_tolerance = False
            
            # Check for bad words
            for bad_word in bad_words:
                bad_word_clean = bad_word.lower()
                
                # Direct match
                if bad_word_clean in content_lower:
                    detected_word = bad_word
                    break
                    
                # Bypass detection - check cleaned content
                if automod_settings.get('bypass_detection', True) and bad_word_clean in clean_content:
                    detected_word = bad_word
                    break
                    
                # Partial match for certain words (like "nigg" matching various forms)
                if len(bad_word_clean) >= 4:
                    if bad_word_clean in clean_content or any(bad_word_clean in word for word in clean_content.split()):
                        detected_word = bad_word
                        break
            
            if detected_word:
                print(f"AutoMod detected bad word: {detected_word} in message: {message.content}")
                
                # Check if it's zero tolerance
                is_zero_tolerance = any(zt_word.lower() in detected_word.lower() for zt_word in zero_tolerance)
                
                if is_zero_tolerance:
                    violations.append(f"SEVERE: Hate speech detected")
                else:
                    violations.append(f"Inappropriate language: {detected_word}")
                    
                # Apply immediate action for bad words
                try:
                    await message.delete()
                    print(f"AutoMod deleted message containing: {detected_word}")
                except (discord.NotFound, discord.Forbidden) as e:
                    print(f"AutoMod failed to delete message: {e}")
                    pass
                    
                # Apply punishment based on severity
                if is_zero_tolerance:
                    # Immediate timeout or ban for hate speech
                    await self.apply_automod_action(
                        message.author, 
                        'timeout', 
                        f"Zero tolerance violation: {detected_word}",
                        automod_settings.get('bad_word_timeout_duration', 3600)  # 1 hour
                    )
                else:
                    # Regular bad word punishment
                    action = automod_settings.get('bad_word_action', 'delete_warn')
                    if action == 'delete_warn':
                        self.user_warnings[message.author.id] += 1
                        await self.log_automod_action(message.guild, "Warning (Bad Language)", message.author, f"Used inappropriate language: {detected_word}")
                    elif action == 'timeout':
                        await self.apply_automod_action(
                            message.author, 
                            'timeout', 
                            f"Inappropriate language: {detected_word}",
                            automod_settings.get('bad_word_timeout_duration', 600)
                        )
                    elif action in ['kick', 'ban']:
                        await self.apply_automod_action(message.author, action, f"Inappropriate language: {detected_word}")
                        
                return  # Skip other violation processing for bad words

        # Process violations
        if violations:
            try:
                await message.delete()
            except discord.NotFound:
                pass
            except discord.Forbidden:
                pass
                
            # Get current warning count
            current_warnings = self.user_warnings[message.author.id]
            violation_threshold = automod_settings.get('violation_threshold', 3)
            escalation_actions = automod_settings.get('escalation_actions', ['warn', 'timeout', 'kick', 'ban'])
            
            # Determine action based on warning count
            if current_warnings < len(escalation_actions):
                action = escalation_actions[current_warnings]
            else:
                action = escalation_actions[-1]  # Use last action for repeat offenders
                
            # Apply action
            reason = f"AutoMod violation: {', '.join(violations)}"
            
            if action == 'timeout':
                duration = automod_settings.get('spam_timeout_duration', 300)
                await self.apply_automod_action(message.author, action, reason, duration)
            else:
                await self.apply_automod_action(message.author, action, reason)

    @commands.command(name='automod', aliases=['auto-mod'])
    async def automod_status(self, ctx):
        """View automod configuration and status."""
        automod_settings = self.get_automod_settings(ctx.guild.id)
        
        embed = discord.Embed(
            title="🤖 AutoMod Configuration",
            description=f"Automated moderation settings for **{ctx.guild.name}**",
            color=discord.Color.blue()
        )
        
        # Main status
        status = "🟢 Enabled" if automod_settings.get('automod_enabled') else "🔴 Disabled"
        embed.add_field(name="Status", value=status, inline=True)
        
        # Active filters
        active_filters = []
        if automod_settings.get('spam_detection'): active_filters.append("Spam")
        if automod_settings.get('caps_filter'): active_filters.append("Caps")
        if automod_settings.get('invite_filter'): active_filters.append("Invites")
        if automod_settings.get('link_filter'): active_filters.append("Links")
        if automod_settings.get('mass_mention_filter'): active_filters.append("Mass Mentions")
        if automod_settings.get('repeated_text_filter'): active_filters.append("Repeated Text")
        if automod_settings.get('bad_words_filter'): active_filters.append("Bad Words")
        
        embed.add_field(
            name="Active Filters", 
            value=", ".join(active_filters) if active_filters else "None", 
            inline=False
        )
        
        # Settings summary
        settings_text = (
            f"**Spam:** {automod_settings.get('spam_message_limit')} msgs in {automod_settings.get('spam_time_window')}s\n"
            f"**Caps:** {automod_settings.get('caps_percentage')}% threshold\n"
            f"**Mass Mentions:** {automod_settings.get('mass_mention_limit')} limit\n"
            f"**Violation Threshold:** {automod_settings.get('violation_threshold')} warnings"
        )
        embed.add_field(name="Settings", value=settings_text, inline=False)
        
        # Log channel
        log_channel_id = automod_settings.get('automod_log_channel')
        if log_channel_id:
            log_channel = ctx.guild.get_channel(int(log_channel_id))
            embed.add_field(
                name="Log Channel", 
                value=log_channel.mention if log_channel else "Not found", 
                inline=True
            )
        
        embed.set_footer(text="Use !automod-setup to configure automod settings")
        await ctx.send(embed=embed)

    @commands.command(name='automod-toggle')
    @require_admin_role()
    async def toggle_automod(self, ctx, enabled: bool = None):
        """Enable or disable automod system."""
        automod_settings = self.get_automod_settings(ctx.guild.id)
        
        if enabled is None:
            current_status = automod_settings.get('automod_enabled', False)
            enabled = not current_status
            
        automod_settings['automod_enabled'] = enabled
        self.save_automod_settings(ctx.guild.id, automod_settings)
        
        status = "enabled" if enabled else "disabled"
        embed = create_success_embed(
            "AutoMod Updated",
            f"AutoMod system has been **{status}** for this server."
        )
        await ctx.send(embed=embed)

    @commands.command(name='automod-setup')
    @require_admin_role()
    async def automod_setup(self, ctx):
        """Interactive automod configuration."""
        embed = discord.Embed(
            title="🤖 AutoMod Setup",
            description="React to configure automod settings:\n\n"
                       "🟢 **Enable/Disable AutoMod**\n"
                       "📧 **Spam Detection Settings**\n"
                       "🔤 **Caps Filter Settings**\n"
                       "🔗 **Link & Invite Filters**\n"
                       "👥 **Mass Mention Filter**\n"
                       "📝 **Set Log Channel**\n"
                       "⚠️ **Violation Threshold**\n"
                       "❌ **Cancel Setup**",
            color=discord.Color.blue()
        )
        
        message = await ctx.send(embed=embed)
        reactions = ["🟢", "📧", "🔤", "🔗", "👥", "📝", "⚠️", "❌"]
        
        for reaction in reactions:
            await message.add_reaction(reaction)
            
        def check(reaction, user):
            return user == ctx.author and str(reaction.emoji) in reactions and reaction.message.id == message.id
            
        try:
            reaction, user = await self.bot.wait_for('reaction_add', timeout=60.0, check=check)
            
            if str(reaction.emoji) == "❌":
                await ctx.send(embed=create_info_embed("Setup Cancelled", "AutoMod setup has been cancelled."))
                return
                
            elif str(reaction.emoji) == "🟢":
                await self.setup_automod_toggle(ctx)
            elif str(reaction.emoji) == "📧":
                await self.setup_spam_detection(ctx)
            elif str(reaction.emoji) == "🔤":
                await self.setup_caps_filter(ctx)
            elif str(reaction.emoji) == "🔗":
                await self.setup_link_filters(ctx)
            elif str(reaction.emoji) == "👥":
                await self.setup_mention_filter(ctx)
            elif str(reaction.emoji) == "📝":
                await self.setup_log_channel(ctx)
            elif str(reaction.emoji) == "⚠️":
                await self.setup_violation_threshold(ctx)
                
        except asyncio.TimeoutError:
            await ctx.send(embed=create_error_embed("Setup Timeout", "AutoMod setup timed out."))

    async def setup_automod_toggle(self, ctx):
        """Setup automod enable/disable."""
        automod_settings = self.get_automod_settings(ctx.guild.id)
        current_status = automod_settings.get('automod_enabled', False)
        
        embed = discord.Embed(
            title="🟢 AutoMod Toggle",
            description=f"AutoMod is currently **{'Enabled' if current_status else 'Disabled'}**\n\n"
                       f"React with ✅ to enable or ❌ to disable AutoMod.",
            color=discord.Color.green() if current_status else discord.Color.red()
        )
        
        message = await ctx.send(embed=embed)
        await message.add_reaction("✅")
        await message.add_reaction("❌")
        
        def check(reaction, user):
            return user == ctx.author and str(reaction.emoji) in ["✅", "❌"]
            
        try:
            reaction, user = await self.bot.wait_for('reaction_add', timeout=30.0, check=check)
            
            enabled = str(reaction.emoji) == "✅"
            automod_settings['automod_enabled'] = enabled
            self.save_automod_settings(ctx.guild.id, automod_settings)
            
            status = "enabled" if enabled else "disabled"
            await ctx.send(embed=create_success_embed("AutoMod Updated", f"AutoMod has been **{status}**."))
            
        except asyncio.TimeoutError:
            await ctx.send(embed=create_error_embed("Timeout", "AutoMod toggle setup timed out."))

    async def setup_log_channel(self, ctx):
        """Setup automod log channel."""
        embed = discord.Embed(
            title="📝 AutoMod Log Channel",
            description="Please mention the channel where automod actions should be logged.\n\n"
                       "Example: #automod-logs\n\n"
                       "Type 'cancel' to abort.",
            color=discord.Color.blue()
        )
        
        await ctx.send(embed=embed)
        
        def check(message):
            return message.author == ctx.author and message.channel == ctx.channel
            
        try:
            message = await self.bot.wait_for('message', timeout=60.0, check=check)
            
            if message.content.lower() == 'cancel':
                await ctx.send(embed=create_info_embed("Cancelled", "Log channel setup cancelled."))
                return
                
            if message.channel_mentions:
                channel = message.channel_mentions[0]
                automod_settings = self.get_automod_settings(ctx.guild.id)
                automod_settings['automod_log_channel'] = str(channel.id)
                self.save_automod_settings(ctx.guild.id, automod_settings)
                
                await ctx.send(embed=create_success_embed(
                    "Log Channel Set", 
                    f"AutoMod actions will be logged to {channel.mention}"
                ))
            else:
                await ctx.send(embed=create_error_embed("Invalid Channel", "Please mention a valid channel."))
                
        except asyncio.TimeoutError:
            await ctx.send(embed=create_error_embed("Timeout", "Log channel setup timed out."))

    # Slash Commands
    @discord.app_commands.command(name="automod", description="View AutoMod configuration and status")
    async def automod_slash(self, interaction: discord.Interaction):
        """View automod configuration and status."""
        await interaction.response.defer()
        
        automod_settings = self.get_automod_settings(interaction.guild.id)
        
        embed = discord.Embed(
            title="🤖 AutoMod Configuration",
            description=f"Automated moderation settings for **{interaction.guild.name}**",
            color=discord.Color.blue()
        )
        
        # Main status
        status = "🟢 Enabled" if automod_settings.get('automod_enabled') else "🔴 Disabled"
        embed.add_field(name="Status", value=status, inline=True)
        
        # Active filters
        active_filters = []
        if automod_settings.get('spam_detection'): active_filters.append("Spam")
        if automod_settings.get('caps_filter'): active_filters.append("Caps")
        if automod_settings.get('invite_filter'): active_filters.append("Invites")
        if automod_settings.get('link_filter'): active_filters.append("Links")
        if automod_settings.get('mass_mention_filter'): active_filters.append("Mass Mentions")
        if automod_settings.get('repeated_text_filter'): active_filters.append("Repeated Text")
        if automod_settings.get('bad_words_filter'): active_filters.append("Bad Words")
        
        embed.add_field(
            name="Active Filters", 
            value=", ".join(active_filters) if active_filters else "None", 
            inline=False
        )
        
        # Settings summary
        settings_text = (
            f"**Spam:** {automod_settings.get('spam_message_limit')} msgs in {automod_settings.get('spam_time_window')}s\n"
            f"**Caps:** {automod_settings.get('caps_percentage')}% threshold\n"
            f"**Mass Mentions:** {automod_settings.get('mass_mention_limit')} limit\n"
            f"**Violation Threshold:** {automod_settings.get('violation_threshold')} warnings"
        )
        embed.add_field(name="Settings", value=settings_text, inline=False)
        
        # Log channel
        log_channel_id = automod_settings.get('automod_log_channel')
        if log_channel_id:
            log_channel = interaction.guild.get_channel(int(log_channel_id))
            embed.add_field(
                name="Log Channel", 
                value=log_channel.mention if log_channel else "Not found", 
                inline=True
            )
        
        embed.set_footer(text="Use /automod-toggle to enable/disable AutoMod")
        await interaction.followup.send(embed=embed)

    @discord.app_commands.command(name="automod-toggle", description="Enable or disable AutoMod system")
    @discord.app_commands.describe(enabled="True to enable, False to disable AutoMod")
    async def automod_toggle_slash(self, interaction: discord.Interaction, enabled: bool = None):
        """Enable or disable automod system."""
        # Check permissions
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(
                embed=create_error_embed("Permission Denied", "You need administrator permissions to use this command."),
                ephemeral=True
            )
            return
            
        await interaction.response.defer()
        
        automod_settings = self.get_automod_settings(interaction.guild.id)
        
        if enabled is None:
            current_status = automod_settings.get('automod_enabled', False)
            enabled = not current_status
            
        automod_settings['automod_enabled'] = enabled
        self.save_automod_settings(interaction.guild.id, automod_settings)
        
        status = "enabled" if enabled else "disabled"
        embed = create_success_embed(
            "AutoMod Updated",
            f"AutoMod system has been **{status}** for this server."
        )
        await interaction.followup.send(embed=embed)

    @discord.app_commands.command(name="automod-setup", description="Interactive AutoMod configuration")
    async def automod_setup_slash(self, interaction: discord.Interaction):
        """Interactive automod configuration."""
        # Check permissions
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(
                embed=create_error_embed("Permission Denied", "You need administrator permissions to use this command."),
                ephemeral=True
            )
            return
            
        embed = discord.Embed(
            title="🤖 AutoMod Setup",
            description="AutoMod is automatically protecting your server with:\n\n"
                       "✅ **Bad Word Filtering** - Detects and removes offensive language\n"
                       "✅ **Spam Detection** - Prevents message flooding\n"
                       "✅ **Caps Filter** - Removes excessive capital letters\n"
                       "✅ **Invite Filter** - Blocks unauthorized Discord invites\n"
                       "✅ **Mass Mention Filter** - Prevents mention spam\n"
                       "✅ **Zero Tolerance** - Instant punishment for hate speech\n\n"
                       "Use `/automod` to view current settings and `/automod-toggle` to enable/disable.",
            color=discord.Color.green()
        )
        
        await interaction.response.send_message(embed=embed, ephemeral=True)

async def setup(bot):
    """Setup function for the cog."""
    await bot.add_cog(AutoModCommands(bot))