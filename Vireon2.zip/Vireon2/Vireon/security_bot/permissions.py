"""
Permission management system for the Discord bot.
Handles role-based access control and permission checks.
"""

import logging
from functools import wraps
from typing import Optional
import discord
from discord.ext import commands

from config import BOT_CONFIG

logger = logging.getLogger(__name__)

class PermissionManager:
    """Manages bot permissions and access control."""
    
    def __init__(self):
        self.admin_roles = BOT_CONFIG['admin_roles']
        self.allowed_users = BOT_CONFIG['allowed_users']
        
    def is_admin(self, user: discord.Member, guild: Optional[discord.Guild] = None) -> bool:
        """Check if user has admin permissions."""
        
        # Only check if user has administrator permission
        if user.guild_permissions.administrator:
            return True
                
        return False
        
    def has_manage_channels_permission(self, user: discord.Member) -> bool:
        """Check if user can manage channels."""
        return user.guild_permissions.manage_channels
        
    def can_use_destructive_commands(self, user: discord.Member, guild: discord.Guild) -> bool:
        """Check if user can use destructive commands like nuke."""
        
        # Must be admin AND have manage channels permission
        return self.is_admin(user, guild) and self.has_manage_channels_permission(user)

def require_admin_role():
    """Decorator to require admin role for command execution."""
    
    def decorator(func):
        @wraps(func)
        async def wrapper(self, ctx, *args, **kwargs):
            
            # Check if in DM
            if not ctx.guild:
                embed = discord.Embed(
                    title="❌ Server Only Command",
                    description="This command can only be used in a server, not in DMs.",
                    color=discord.Color.red()
                )
                await ctx.send(embed=embed)
                return
                
            permission_manager = PermissionManager()
            
            # Check if user has admin permissions
            if not permission_manager.is_admin(ctx.author, ctx.guild):
                embed = discord.Embed(
                    title="❌ Insufficient Permissions",
                    description=(
                        "You need the **Administrator** permission to use this command.\n"
                        "Only users with the Administrator permission can access bot commands."
                    ),
                    color=discord.Color.red()
                )
                await ctx.send(embed=embed)
                return
                
            # Check for destructive commands specifically
            if func.__name__ in ['nuke_channels', 'delete_all_channels']:
                if not permission_manager.can_use_destructive_commands(ctx.author, ctx.guild):
                    embed = discord.Embed(
                        title="❌ Insufficient Permissions",
                        description=(
                            "You need **both** admin permissions AND 'Manage Channels' "
                            "permission to use destructive commands."
                        ),
                        color=discord.Color.red()
                    )
                    await ctx.send(embed=embed)
                    return
                    
            # Log command usage
            logger.info(
                f"Admin command '{func.__name__}' used by {ctx.author} "
                f"({ctx.author.id}) in {ctx.guild.name} ({ctx.guild.id})"
            )
            
            return await func(self, ctx, *args, **kwargs)
            
        return wrapper
    return decorator

def require_manage_channels():
    """Decorator to require manage channels permission."""
    
    def decorator(func):
        @wraps(func)
        async def wrapper(self, ctx, *args, **kwargs):
            
            if not ctx.guild:
                embed = discord.Embed(
                    title="❌ Server Only Command",
                    description="This command can only be used in a server.",
                    color=discord.Color.red()
                )
                await ctx.send(embed=embed)
                return
                
            if not ctx.author.guild_permissions.manage_channels:
                embed = discord.Embed(
                    title="❌ Missing Permission",
                    description="You need the 'Manage Channels' permission to use this command.",
                    color=discord.Color.red()
                )
                await ctx.send(embed=embed)
                return
                
            return await func(self, ctx, *args, **kwargs)
            
        return wrapper
    return decorator

def require_owner():
    """Decorator to require server owner status."""
    
    def decorator(func):
        @wraps(func)
        async def wrapper(self, ctx, *args, **kwargs):
            
            if not ctx.guild:
                embed = discord.Embed(
                    title="❌ Server Only Command",
                    description="This command can only be used in a server.",
                    color=discord.Color.red()
                )
                await ctx.send(embed=embed)
                return
                
            if ctx.author.id != ctx.guild.owner_id:
                embed = discord.Embed(
                    title="❌ Owner Only Command",
                    description="This command can only be used by the server owner.",
                    color=discord.Color.red()
                )
                await ctx.send(embed=embed)
                return
                
            return await func(self, ctx, *args, **kwargs)
            
        return wrapper
    return decorator
