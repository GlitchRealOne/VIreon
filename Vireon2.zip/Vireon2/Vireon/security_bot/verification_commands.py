"""
User verification system for Discord server security.
Provides captcha-like verification to prevent automated accounts.
"""

import asyncio
import random
import string
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
import discord
from discord.ext import commands
from discord import app_commands

from security_bot.permissions import require_admin_role
from security_bot.utils import create_success_embed, create_error_embed, create_info_embed, create_warning_embed
from database_wrapper import db_wrapper


class VerificationCommands(commands.Cog):
    """User verification system commands."""

    def __init__(self, bot):
        self.bot = bot
        self.verification_data = {}  # In-memory storage for verification data

    def get_guild_settings(self, guild_id: int) -> Dict[str, Any]:
        """Get or create guild settings from the wrapper."""
        settings = db_wrapper.get_guild_settings(str(guild_id))
        if not settings:
            settings = {
                "guild_id": str(guild_id),
                "verification_enabled": False,
                "verification_channel_id": None,
                "verified_role_id": None,
                "log_channel_id": None
            }
            db_wrapper.store_guild_settings(settings)
        return settings

    async def log_security_event(self, guild: discord.Guild, event_type: str, description: str, color: discord.Color = discord.Color.orange()):
        """Log security events to the configured log channel."""
        settings = self.get_guild_settings(guild.id)
        log_channel_id = settings.get("log_channel_id")
        if log_channel_id:
            channel = guild.get_channel(int(log_channel_id))
            if channel and hasattr(channel, 'send'):
                embed = discord.Embed(
                    title=f"🛡️ Security Event: {event_type}",
                    description=description,
                    color=color,
                    timestamp=datetime.utcnow()
                )
                embed.set_footer(text=f"Guild: {guild.name}")
                try:
                    await channel.send(embed=embed)
                except discord.Forbidden:
                    pass

    @commands.command(name='setup-verification', aliases=['setup-verify'])
    @require_admin_role()
    async def setup_verification(self, ctx, channel: discord.TextChannel, role: discord.Role):
        """Setup the verification system for this server."""
        settings = self.get_guild_settings(ctx.guild.id)

        # Check bot permissions
        if not channel.permissions_for(ctx.guild.me).send_messages:
            await ctx.send(embed=create_error_embed("Missing Permissions", "I don't have permission to send messages in that channel."))
            return

        if not ctx.guild.me.guild_permissions.manage_roles:
            await ctx.send(embed=create_error_embed("Missing Permissions", "I don't have permission to manage roles."))
            return

        if role.position > ctx.guild.me.top_role.position:
            await ctx.send(embed=create_error_embed("Role Too High", "The verification role is higher than my highest role. Please move my role above it."))
            return

        # Save settings
        settings["verification_enabled"] = True
        settings["verification_channel_id"] = str(channel.id)
        settings["verified_role_id"] = str(role.id)
        db_wrapper.store_guild_settings(settings)

        # Send verification message to channel
        verification_embed = discord.Embed(
            title="✅ Verification Required",
            description="Welcome to the server! To gain access, you need to verify your account.\n\n"
                       f"**How to verify:**\n"
                       f"1. Type `!verify` in this channel\n"
                       f"2. Solve the verification challenge\n"
                       f"3. Get the **{role.name}** role automatically\n\n"
                       f"⚠️ **This helps protect the server from raids and bots.**",
            color=discord.Color.green()
        )
        verification_embed.set_footer(text="Verification system active")

        try:
            await channel.send(embed=verification_embed)
        except discord.Forbidden:
            pass

        # Confirmation message
        setup_embed = create_success_embed(
            "Verification System Setup Complete",
            f"**Verification Channel:** {channel.mention}\n"
            f"**Verified Role:** {role.mention}\n"
            f"**Status:** Active\n\n"
            f"Users can now type `!verify` in {channel.mention} to get verified."
        )
        await ctx.send(embed=setup_embed)

        # Log the setup
        await self.log_security_event(
            ctx.guild,
            "Verification Setup",
            f"Verification system setup by {ctx.author.mention}\nChannel: {channel.mention}\nRole: {role.mention}",
            discord.Color.green()
        )

    @commands.command(name='disable-verification', aliases=['disable-verify'])
    @require_admin_role()
    async def disable_verification(self, ctx):
        """Disable the verification system."""
        settings = self.get_guild_settings(ctx.guild.id)

        if not settings.get("verification_enabled"):
            await ctx.send(embed=create_warning_embed("Already Disabled", "Verification system is already disabled."))
            return

        settings["verification_enabled"] = False
        settings["verification_channel_id"] = None
        settings["verified_role_id"] = None
        db_wrapper.store_guild_settings(settings)

        embed = create_success_embed(
            "Verification System Disabled",
            "The verification system has been disabled for this server."
        )
        await ctx.send(embed=embed)

    @commands.command(name='verify')
    async def verify_user(self, ctx):
        """Start the verification process for a user."""
        settings = self.get_guild_settings(ctx.guild.id)

        if not settings.get("verification_enabled"):
            await ctx.send(embed=create_error_embed("Verification system is not enabled on this server."))
            return

        # Check if in correct channel
        verification_channel_id = settings.get("verification_channel_id")
        if verification_channel_id and str(ctx.channel.id) != verification_channel_id:
            verification_channel = ctx.guild.get_channel(int(verification_channel_id))
            if verification_channel:
                await ctx.send(embed=create_error_embed(
                    "Wrong Channel",
                    f"Please use {verification_channel.mention} for verification."
                ))
                return

        # Check if already verified
        verified_role_id = settings.get("verified_role_id")
        verified_role = ctx.guild.get_role(int(verified_role_id)) if verified_role_id else None
        if verified_role and verified_role in ctx.author.roles:
            await ctx.send(embed=create_info_embed("Already Verified", "You are already verified!"))
            return

        # Check if verification is pending
        existing_verification = db_wrapper.get_verification(str(ctx.guild.id), str(ctx.author.id))

        if existing_verification and not existing_verification.get("is_verified") and existing_verification.get("expires_at") > datetime.utcnow():
            time_left = (existing_verification["expires_at"] - datetime.utcnow()).total_seconds() // 60
            await ctx.send(embed=create_warning_embed(
                "Verification Pending",
                f"You already have a pending verification.\n"
                f"Code expires in {int(time_left)} minutes.\n"
                f"Use `!confirm {existing_verification.get('code')}` to complete verification."
            ))
            return

        # Generate verification code (math problem)
        num1 = random.randint(10, 50)
        num2 = random.randint(1, 20)
        operation = random.choice(['+', '-', '*'])

        if operation == '+':
            answer = num1 + num2
        elif operation == '-':
            answer = num1 - num2
        else:  # multiplication
            answer = num1 * num2

        verification_code_str = str(answer)
        expires_at = datetime.utcnow() + timedelta(minutes=10)

        # Store verification data
        success = db_wrapper.store_verification(
            str(ctx.guild.id),
            str(ctx.author.id),
            verification_code_str,
            10  # 10 minutes expiry
        )

        if not success:
            await ctx.send(embed=create_error_embed("Error", "Could not initiate verification. Please try again later."))
            return

        # Send verification challenge
        verification_embed = discord.Embed(
            title="🔢 Verification Challenge",
            description=f"**{ctx.author.mention}, solve this math problem to verify:**\n\n"
                       f"**Question:** `{num1} {operation} {num2} = ?`\n\n"
                       f"**Instructions:**\n"
                       f"• Calculate the answer\n"
                       f"• Type `!confirm [your_answer]`\n"
                       f"• Example: `!confirm 42`\n\n"
                       f"⏰ **You have 10 minutes to complete this verification.**",
            color=discord.Color.blue()
        )
        verification_embed.set_footer(text="Anti-bot verification system")

        await ctx.send(embed=verification_embed)

        # Log verification attempt
        await self.log_security_event(
            ctx.guild,
            "Verification Started",
            f"{ctx.author.mention} started verification process",
            discord.Color.blue()
        )

    @commands.command(name='confirm')
    async def confirm_verification(self, ctx, answer: str):
        """Confirm verification with the provided answer."""
        settings = self.get_guild_settings(ctx.guild.id)

        if not settings.get("verification_enabled"):
            return

        # Check verification
        verification_result = db_wrapper.check_verification(str(ctx.guild.id), str(ctx.author.id), answer)

        if verification_result == "invalid":
            await ctx.send(embed=create_error_embed("❌ Invalid verification code. Please try `!verify` again."))
            return
        elif verification_result == "expired":
            await ctx.send(embed=create_error_embed("❌ Verification code has expired. Please try `!verify` again."))
            return
        elif verification_result == "already_verified":
            await ctx.send(embed=create_warning_embed("⚠️ You are already verified in this server."))
            return
        elif verification_result != "success":
            await ctx.send(embed=create_error_embed("❌ Verification failed. Please try again."))
            return

        # Give verified role
        verified_role_id = settings.get("verified_role_id")
        if verified_role_id:
            verified_role = ctx.guild.get_role(int(verified_role_id))
            if verified_role:
                try:
                    await ctx.author.add_roles(verified_role, reason="Completed verification")
                except discord.Forbidden:
                    await ctx.send(embed=create_error_embed(
                        "Role Assignment Failed",
                        "Verification complete but I couldn't assign the role. Please contact an admin."
                    ))
                    return

        # Success message
        success_embed = create_success_embed(
            "Verification Complete!",
            f"**{ctx.author.mention}, you have been successfully verified!**\n\n"
            f"✅ You now have access to the server\n"
            f"🎉 Welcome to **{ctx.guild.name}**!"
        )
        await ctx.send(embed=success_embed)

        # Log successful verification
        await self.log_security_event(
            ctx.guild,
            "User Verified",
            f"{ctx.author.mention} completed verification successfully",
            discord.Color.green()
        )

    @commands.command(name='verification-stats', aliases=['verify-stats'])
    @require_admin_role()
    async def verification_stats(self, ctx):
        """Show verification statistics for this server."""
        try:
            total_verified = db_wrapper.count_verifications(str(ctx.guild.id), is_verified=True)
            pending_verifications = db_wrapper.count_verifications(str(ctx.guild.id), is_verified=False)
            recent_verifications = db_wrapper.count_verifications(str(ctx.guild.id), is_verified=True, days=7)
        except Exception as e:
            # Fallback to default values if database wrapper fails
            total_verified = 0
            pending_verifications = 0
            recent_verifications = 0

        settings = self.get_guild_settings(ctx.guild.id)
        verification_channel_id = settings.get("verification_channel_id")
        verified_role_id = settings.get("verified_role_id")

        verification_channel = ctx.guild.get_channel(int(verification_channel_id)) if verification_channel_id else None
        verified_role = ctx.guild.get_role(int(verified_role_id)) if verified_role_id else None

        embed = discord.Embed(
            title="📊 Verification Statistics",
            description=f"Verification stats for **{ctx.guild.name}**",
            color=discord.Color.blue()
        )

        embed.add_field(
            name="📈 Overall Stats",
            value=f"**Total Verified:** {total_verified}\n"
                  f"**Pending:** {pending_verifications}\n"
                  f"**This Week:** {recent_verifications}",
            inline=True
        )

        embed.add_field(
            name="⚙️ Configuration",
            value=f"**Status:** {'✅ Enabled' if settings.get('verification_enabled') else '❌ Disabled'}\n"
                  f"**Channel:** {verification_channel.mention if verification_channel else 'Not set'}\n"
                  f"**Role:** {verified_role.mention if verified_role else 'Not set'}",
            inline=True
        )

        # Calculate verification rate if we have role members
        if verified_role:
            role_members = len(verified_role.members)
            total_members = ctx.guild.member_count
            verification_rate = (role_members / total_members * 100) if total_members > 0 else 0

            embed.add_field(
                name="📊 Server Impact",
                value=f"**Role Members:** {role_members}\n"
                      f"**Total Members:** {total_members}\n"
                      f"**Verification Rate:** {verification_rate:.1f}%",
                inline=True
            )

        embed.timestamp = datetime.utcnow()
        await ctx.send(embed=embed)

    @commands.group(name='logs', invoke_without_command=True)
    @require_admin_role()
    async def logs_group(self, ctx):
        """Manage logging settings."""
        settings = self.get_guild_settings(ctx.guild.id)
        log_channel_id = settings.get("log_channel_id")
        log_channel = ctx.guild.get_channel(int(log_channel_id)) if log_channel_id else None

        embed = discord.Embed(
            title="📜 Server Logs Configuration",
            description="Configure where and what security events are logged.",
            color=discord.Color.teal()
        )
        embed.add_field(
            name="Log Channel",
            value=log_channel.mention if log_channel else "Not set",
            inline=False
        )
        embed.add_field(
            name="Commands",
            value="`!logs set #channel` - Set the log channel.\n"
                  "`!logs disable` - Disable logging.",
            inline=False
        )
        await ctx.send(embed=embed)

    @logs_group.command(name='set')
    @require_admin_role()
    async def logs_set(self, ctx, channel: discord.TextChannel):
        """Set the channel for security logs."""
        settings = self.get_guild_settings(ctx.guild.id)
        settings["log_channel_id"] = str(channel.id)
        db_wrapper.store_guild_settings(settings)

        await ctx.send(embed=create_success_embed(
            "Log Channel Set",
            f"Security events will now be logged in {channel.mention}."
        ))
        await self.log_security_event(
            ctx.guild,
            "Log Channel Set",
            f"Log channel set to {channel.mention} by {ctx.author.mention}",
            discord.Color.blue()
        )

    @logs_group.command(name='disable')
    @require_admin_role()
    async def logs_disable(self, ctx):
        """Disable security logging."""
        settings = self.get_guild_settings(ctx.guild.id)
        if not settings.get("log_channel_id"):
            await ctx.send(embed=create_warning_embed("Already Disabled", "Logging is already disabled."))
            return

        settings["log_channel_id"] = None
        db_wrapper.store_guild_settings(settings)

        await ctx.send(embed=create_success_embed(
            "Logging Disabled",
            "Security event logging has been disabled for this server."
        ))
        await self.log_security_event(
            ctx.guild,
            "Logging Disabled",
            f"Security logging disabled by {ctx.author.mention}",
            discord.Color.orange()
        )

    @app_commands.command(name="setup-verification", description="Setup the verification system for this server")
    @app_commands.describe(
        channel="The channel where users will verify",
        role="The role to give to verified users"
    )
    async def slash_setup_verification(self, interaction: discord.Interaction, channel: discord.TextChannel, role: discord.Role):
        """Slash command to setup verification system."""
        # Check admin permissions
        if not interaction.user.guild_permissions.administrator:
            embed = create_error_embed("Permission Denied", "You need Administrator permissions to use this command.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        settings = self.get_guild_settings(interaction.guild.id)

        # Check bot permissions
        if not channel.permissions_for(interaction.guild.me).send_messages:
            await interaction.response.send_message(embed=create_error_embed("Missing Permissions", "I don't have permission to send messages in that channel."), ephemeral=True)
            return

        if not interaction.guild.me.guild_permissions.manage_roles:
            await interaction.response.send_message(embed=create_error_embed("Missing Permissions", "I don't have permission to manage roles."), ephemeral=True)
            return

        if role.position > interaction.guild.me.top_role.position:
            await interaction.response.send_message(embed=create_error_embed("Role Too High", "The verification role is higher than my highest role. Please move my role above it."), ephemeral=True)
            return

        # Save settings
        settings["verification_enabled"] = True
        settings["verification_channel_id"] = str(channel.id)
        settings["verified_role_id"] = str(role.id)
        db_wrapper.store_guild_settings(settings)

        # Send verification message to channel
        verification_embed = discord.Embed(
            title="✅ Verification Required",
            description="Welcome to the server! To gain access, you need to verify your account.\n\n"
                       f"**How to verify:**\n"
                       f"1. Type `/verify` or `!verify` in this channel\n"
                       f"2. Solve the verification challenge\n"
                       f"3. Get the **{role.name}** role automatically\n\n"
                       f"⚠️ **This helps protect the server from raids and bots.**",
            color=discord.Color.green()
        )
        verification_embed.set_footer(text="Verification system active")

        try:
            await channel.send(embed=verification_embed)
        except discord.Forbidden:
            pass

        # Confirmation message
        setup_embed = create_success_embed(
            "Verification System Setup Complete",
            f"**Verification Channel:** {channel.mention}\n"
            f"**Verified Role:** {role.mention}\n"
            f"**Status:** Active\n\n"
            f"Users can now type `/verify` or `!verify` in {channel.mention} to get verified."
        )
        await interaction.response.send_message(embed=setup_embed)

        # Log the setup
        await self.log_security_event(
            interaction.guild,
            "Verification Setup",
            f"Verification system setup by {interaction.user.mention}\nChannel: {channel.mention}\nRole: {role.mention}",
            discord.Color.green()
        )

    @app_commands.command(name="verify", description="Start the verification process")
    async def slash_verify(self, interaction: discord.Interaction):
        """Slash command to start verification."""
        settings = self.get_guild_settings(interaction.guild.id)

        if not settings.get("verification_enabled"):
            await interaction.response.send_message(embed=create_error_embed("Verification Disabled", "Verification system is not enabled on this server."), ephemeral=True)
            return

        # Check if in correct channel
        verification_channel_id = settings.get("verification_channel_id")
        if verification_channel_id and str(interaction.channel.id) != verification_channel_id:
            verification_channel = interaction.guild.get_channel(int(verification_channel_id))
            if verification_channel:
                await interaction.response.send_message(embed=create_error_embed(
                    "Wrong Channel",
                    f"Please use {verification_channel.mention} for verification."
                ), ephemeral=True)
                return

        # Check if already verified
        verified_role_id = settings.get("verified_role_id")
        verified_role = interaction.guild.get_role(int(verified_role_id)) if verified_role_id else None
        if verified_role and verified_role in interaction.user.roles:
            await interaction.response.send_message(embed=create_info_embed("Already Verified", "You are already verified!"), ephemeral=True)
            return

        # Check if verification is pending
        existing_verification = db_wrapper.get_verification(str(interaction.guild.id), str(interaction.user.id))

        if existing_verification and not existing_verification.get("is_verified") and existing_verification.get("expires_at") > datetime.utcnow():
            time_left = (existing_verification["expires_at"] - datetime.utcnow()).total_seconds() // 60
            await interaction.response.send_message(embed=create_warning_embed(
                "Verification Pending",
                f"You already have a pending verification.\n"
                f"Code expires in {int(time_left)} minutes.\n"
                f"Use `/confirm {existing_verification.get('code')}` to complete verification."
            ), ephemeral=True)
            return

        # Generate verification code (math problem)
        num1 = random.randint(10, 50)
        num2 = random.randint(1, 20)
        operation = random.choice(['+', '-', '*'])

        if operation == '+':
            answer = num1 + num2
        elif operation == '-':
            answer = num1 - num2
        else:  # multiplication
            answer = num1 * num2

        verification_code_str = str(answer)

        # Store verification data
        success = db_wrapper.store_verification(
            str(interaction.guild.id),
            str(interaction.user.id),
            verification_code_str,
            10  # 10 minutes expiry
        )

        if not success:
            await interaction.response.send_message(embed=create_error_embed("Error", "Could not initiate verification. Please try again later."), ephemeral=True)
            return

        # Send verification challenge
        verification_embed = discord.Embed(
            title="🔢 Verification Challenge",
            description=f"**{interaction.user.mention}, solve this math problem to verify:**\n\n"
                       f"**Question:** `{num1} {operation} {num2} = ?`\n\n"
                       f"**Instructions:**\n"
                       f"• Calculate the answer\n"
                       f"• Type `/confirm [your_answer]` or `!confirm [your_answer]`\n"
                       f"• Example: `/confirm 42`\n\n"
                       f"⏰ **You have 10 minutes to complete this verification.**",
            color=discord.Color.blue()
        )
        verification_embed.set_footer(text="Anti-bot verification system")

        await interaction.response.send_message(embed=verification_embed)

        # Log verification attempt
        await self.log_security_event(
            interaction.guild,
            "Verification Started",
            f"{interaction.user.mention} started verification process",
            discord.Color.blue()
        )

    @app_commands.command(name="confirm", description="Confirm verification with your answer")
    @app_commands.describe(answer="Your answer to the verification challenge")
    async def slash_confirm_verification(self, interaction: discord.Interaction, answer: str):
        """Slash command to confirm verification."""
        settings = self.get_guild_settings(interaction.guild.id)

        if not settings.get("verification_enabled"):
            await interaction.response.send_message(embed=create_error_embed("Verification Disabled", "Verification system is not enabled on this server."), ephemeral=True)
            return

        # Check verification
        verification_result = db_wrapper.check_verification(str(interaction.guild.id), str(interaction.user.id), answer)

        if verification_result == "invalid":
            await interaction.response.send_message(embed=create_error_embed("❌ Invalid verification code. Please try `/verify` again."), ephemeral=True)
            return
        elif verification_result == "expired":
            await interaction.response.send_message(embed=create_error_embed("❌ Verification code has expired. Please try `/verify` again."), ephemeral=True)
            return
        elif verification_result == "already_verified":
            await interaction.response.send_message(embed=create_warning_embed("⚠️ You are already verified in this server."), ephemeral=True)
            return
        elif verification_result != "success":
            await interaction.response.send_message(embed=create_error_embed("❌ Verification failed. Please try again."), ephemeral=True)
            return

        # Give verified role
        verified_role_id = settings.get("verified_role_id")
        if verified_role_id:
            verified_role = interaction.guild.get_role(int(verified_role_id))
            if verified_role:
                try:
                    await interaction.user.add_roles(verified_role, reason="Completed verification")
                except discord.Forbidden:
                    await interaction.response.send_message(embed=create_error_embed(
                        "Role Assignment Failed",
                        "Verification complete but I couldn't assign the role. Please contact an admin."
                    ), ephemeral=True)
                    return

        # Success message
        success_embed = create_success_embed(
            "Verification Complete!",
            f"**{interaction.user.mention}, you have been successfully verified!**\n\n"
            f"✅ You now have access to the server\n"
            f"🎉 Welcome to **{interaction.guild.name}**!"
        )
        await interaction.response.send_message(embed=success_embed)

        # Log successful verification
        await self.log_security_event(
            interaction.guild,
            "User Verified",
            f"{interaction.user.mention} completed verification successfully",
            discord.Color.green()
        )


async def setup(bot):
    """Setup function for the cog."""
    await bot.add_cog(VerificationCommands(bot))