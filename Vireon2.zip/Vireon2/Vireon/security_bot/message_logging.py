
"""
Message logging system for tracking edited/deleted messages and user activity.
"""

import discord
from discord.ext import commands
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
from database_wrapper import db_wrapper
from security_bot.permissions import require_admin_role
from security_bot.utils import create_success_embed, create_error_embed, create_info_embed

class MessageLogging(commands.Cog):
    """Message logging and activity tracking."""

    def __init__(self, bot):
        self.bot = bot
        self.message_cache = {}  # Store recent messages for edit tracking

    def get_guild_settings(self, guild_id: int) -> Dict[str, Any]:
        """Get or create guild settings."""
        return db_wrapper.get_guild_settings(str(guild_id))

    async def log_to_channel(self, guild: discord.Guild, embed: discord.Embed):
        """Send log message to the configured log channel."""
        settings = self.get_guild_settings(guild.id)
        log_channel_id = settings.get('log_channel_id')
        
        if log_channel_id:
            try:
                channel = guild.get_channel(int(log_channel_id))
                if channel and hasattr(channel, 'send'):
                    await channel.send(embed=embed)
            except (discord.Forbidden, discord.NotFound, ValueError):
                pass  # Channel not accessible or doesn't exist

    def cache_message(self, message):
        """Cache messages for edit tracking (called from main bot)."""
        if message.author.bot or not message.guild:
            return

        settings = self.get_guild_settings(message.guild.id)
        if not settings.get('message_logging_enabled', False):
            return

        # Store message for edit tracking (keep last 100 messages per channel)
        channel_id = message.channel.id
        if channel_id not in self.message_cache:
            self.message_cache[channel_id] = {}
        
        self.message_cache[channel_id][message.id] = {
            'content': message.content,
            'author': message.author,
            'timestamp': message.created_at,
            'attachments': [att.url for att in message.attachments],
            'embeds': len(message.embeds)
        }

        # Keep only recent messages (prevent memory bloat)
        if len(self.message_cache[channel_id]) > 100:
            oldest_msg = min(self.message_cache[channel_id].keys())
            del self.message_cache[channel_id][oldest_msg]

    @commands.Cog.listener()
    async def on_message_edit(self, before, after):
        """Log message edits."""
        if before.author.bot or not before.guild:
            return

        # Skip if content didn't change
        if before.content == after.content:
            return

        settings = self.get_guild_settings(before.guild.id)
        if not settings.get('message_logging_enabled', False):
            return

        embed = discord.Embed(
            title="📝 Message Edited",
            color=discord.Color.orange(),
            timestamp=datetime.utcnow()
        )

        embed.add_field(
            name="Author", 
            value=f"{after.author.mention} (`{after.author.id}`)",
            inline=True
        )
        
        embed.add_field(
            name="Channel",
            value=f"{after.channel.mention}",
            inline=True
        )
        
        embed.add_field(
            name="Message ID",
            value=f"`{after.id}`",
            inline=True
        )

        # Show before content
        before_content = before.content[:1000] if before.content else "*No content*"
        embed.add_field(
            name="Before",
            value=f"```{before_content}```" if before_content != "*No content*" else before_content,
            inline=False
        )

        # Show after content
        after_content = after.content[:1000] if after.content else "*No content*"
        embed.add_field(
            name="After",
            value=f"```{after_content}```" if after_content != "*No content*" else after_content,
            inline=False
        )

        embed.add_field(
            name="Jump to Message",
            value=f"[Click here]({after.jump_url})",
            inline=False
        )

        embed.set_footer(text=f"User ID: {after.author.id}")

        await self.log_to_channel(before.guild, embed)

        # Log to database/memory
        db_wrapper.log_activity(
            str(before.guild.id),
            'message_edit',
            f"{after.author.name} edited message in #{after.channel.name}"
        )

    @commands.Cog.listener()
    async def on_message_delete(self, message):
        """Log message deletions."""
        if message.author.bot or not message.guild:
            return

        settings = self.get_guild_settings(message.guild.id)
        if not settings.get('message_logging_enabled', False):
            return

        embed = discord.Embed(
            title="🗑️ Message Deleted",
            color=discord.Color.red(),
            timestamp=datetime.utcnow()
        )

        embed.add_field(
            name="Author",
            value=f"{message.author.mention} (`{message.author.id}`)",
            inline=True
        )
        
        embed.add_field(
            name="Channel",
            value=f"{message.channel.mention}",
            inline=True
        )
        
        embed.add_field(
            name="Message ID",
            value=f"`{message.id}`",
            inline=True
        )

        # Show deleted content
        content = message.content[:1500] if message.content else "*No text content*"
        embed.add_field(
            name="Deleted Content",
            value=f"```{content}```" if content != "*No text content*" else content,
            inline=False
        )

        # Show attachments if any
        if message.attachments:
            attachment_info = []
            for att in message.attachments:
                attachment_info.append(f"📎 {att.filename} ({att.size} bytes)")
            embed.add_field(
                name="Attachments",
                value='\n'.join(attachment_info[:5]),
                inline=False
            )

        # Show embeds if any
        if message.embeds:
            embed.add_field(
                name="Embeds",
                value=f"{len(message.embeds)} embed(s) were in this message",
                inline=False
            )

        embed.add_field(
            name="Original Timestamp",
            value=f"<t:{int(message.created_at.timestamp())}:F>",
            inline=False
        )

        embed.set_footer(text=f"User ID: {message.author.id}")

        await self.log_to_channel(message.guild, embed)

        # Log to database/memory
        db_wrapper.log_activity(
            str(message.guild.id),
            'message_delete',
            f"{message.author.name} had message deleted in #{message.channel.name}"
        )

    @commands.Cog.listener()
    async def on_bulk_message_delete(self, messages):
        """Log bulk message deletions."""
        if not messages or not messages[0].guild:
            return

        guild = messages[0].guild
        channel = messages[0].channel

        settings = self.get_guild_settings(guild.id)
        if not settings.get('message_logging_enabled', False):
            return

        embed = discord.Embed(
            title="🗑️ Bulk Messages Deleted",
            description=f"**{len(messages)}** messages were bulk deleted",
            color=discord.Color.red(),
            timestamp=datetime.utcnow()
        )

        embed.add_field(
            name="Channel",
            value=f"{channel.mention}",
            inline=True
        )

        embed.add_field(
            name="Messages Deleted",
            value=f"{len(messages)}",
            inline=True
        )

        # Show authors involved
        authors = set()
        for msg in messages[:20]:  # Limit to prevent spam
            if not msg.author.bot:
                authors.add(msg.author.name)

        if authors:
            embed.add_field(
                name="Authors Affected",
                value=', '.join(list(authors)[:10]),
                inline=False
            )

        embed.set_footer(text=f"Guild: {guild.name}")

        await self.log_to_channel(guild, embed)

        # Log to database/memory
        db_wrapper.log_activity(
            str(guild.id),
            'bulk_delete',
            f"{len(messages)} messages bulk deleted in #{channel.name}"
        )

    @commands.Cog.listener()
    async def on_member_join(self, member):
        """Log member joins."""
        settings = self.get_guild_settings(member.guild.id)
        if not settings.get('member_logging_enabled', False):
            return

        embed = discord.Embed(
            title="👋 Member Joined",
            color=discord.Color.green(),
            timestamp=datetime.utcnow()
        )

        embed.set_thumbnail(url=member.display_avatar.url)

        embed.add_field(
            name="Member",
            value=f"{member.mention} (`{member.id}`)",
            inline=True
        )

        embed.add_field(
            name="Account Created",
            value=f"<t:{int(member.created_at.timestamp())}:R>",
            inline=True
        )

        # Account age warning for new accounts
        account_age = datetime.utcnow() - member.created_at
        if account_age.days < 7:
            embed.add_field(
                name="⚠️ Warning",
                value=f"Account is only {account_age.days} days old",
                inline=False
            )

        embed.add_field(
            name="Member Count",
            value=f"{member.guild.member_count}",
            inline=True
        )

        embed.set_footer(text=f"User ID: {member.id}")

        await self.log_to_channel(member.guild, embed)

        # Log to database/memory
        db_wrapper.log_activity(
            str(member.guild.id),
            'member_join',
            f"{member.name} joined the server"
        )

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        """Log member leaves/kicks/bans."""
        settings = self.get_guild_settings(member.guild.id)
        if not settings.get('member_logging_enabled', False):
            return

        embed = discord.Embed(
            title="👋 Member Left",
            color=discord.Color.orange(),
            timestamp=datetime.utcnow()
        )

        embed.set_thumbnail(url=member.display_avatar.url)

        embed.add_field(
            name="Member",
            value=f"{member.mention} (`{member.id}`)",
            inline=True
        )

        if member.joined_at:
            embed.add_field(
                name="Joined",
                value=f"<t:{int(member.joined_at.timestamp())}:R>",
                inline=True
            )

        embed.add_field(
            name="Roles",
            value=', '.join([role.name for role in member.roles if role.name != "@everyone"][:5]) or "No roles",
            inline=False
        )

        embed.set_footer(text=f"User ID: {member.id}")

        await self.log_to_channel(member.guild, embed)

        # Log to database/memory
        db_wrapper.log_activity(
            str(member.guild.id),
            'member_leave',
            f"{member.name} left the server"
        )

    @commands.Cog.listener()
    async def on_member_ban(self, guild, user):
        """Log when members are banned."""
        settings = self.get_guild_settings(guild.id)
        if not settings.get('member_logging_enabled', False):
            return

        try:
            ban_entry = None
            async for entry in guild.audit_logs(action=discord.AuditLogAction.ban, limit=1):
                if entry.target.id == user.id:
                    ban_entry = entry
                    break
            
            moderator = ban_entry.user if ban_entry else "Unknown"
            reason = ban_entry.reason if ban_entry and ban_entry.reason else "No reason provided"
            
            embed = discord.Embed(
                title="🔨 Member Banned",
                color=discord.Color.dark_red(),
                timestamp=datetime.utcnow()
            )

            embed.set_thumbnail(url=user.display_avatar.url)

            embed.add_field(
                name="Member",
                value=f"{user.mention} (`{user.id}`)",
                inline=True
            )

            embed.add_field(
                name="Moderator",
                value=f"{moderator.mention}" if hasattr(moderator, 'mention') else str(moderator),
                inline=True
            )

            embed.add_field(
                name="Reason",
                value=reason,
                inline=False
            )

            embed.set_footer(text=f"User ID: {user.id}")

            await self.log_to_channel(guild, embed)

            # Log to database/memory
            db_wrapper.log_activity(
                str(guild.id),
                'member_ban',
                f"{user.name} was banned by {moderator}"
            )
        except Exception as e:
            # Fallback logging without audit log details
            embed = discord.Embed(
                title="🔨 Member Banned",
                description=f"**{user} was banned**\n**User ID:** {user.id}",
                color=discord.Color.dark_red(),
                timestamp=datetime.utcnow()
            )
            await self.log_to_channel(guild, embed)

    @commands.Cog.listener()
    async def on_member_unban(self, guild, user):
        """Log when members are unbanned."""
        settings = self.get_guild_settings(guild.id)
        if not settings.get('member_logging_enabled', False):
            return

        try:
            unban_entry = None
            async for entry in guild.audit_logs(action=discord.AuditLogAction.unban, limit=1):
                if entry.target.id == user.id:
                    unban_entry = entry
                    break
            
            moderator = unban_entry.user if unban_entry else "Unknown"
            
            embed = discord.Embed(
                title="✅ Member Unbanned",
                color=discord.Color.green(),
                timestamp=datetime.utcnow()
            )

            embed.set_thumbnail(url=user.display_avatar.url)

            embed.add_field(
                name="Member",
                value=f"{user.mention} (`{user.id}`)",
                inline=True
            )

            embed.add_field(
                name="Moderator",
                value=f"{moderator.mention}" if hasattr(moderator, 'mention') else str(moderator),
                inline=True
            )

            embed.set_footer(text=f"User ID: {user.id}")

            await self.log_to_channel(guild, embed)

            # Log to database/memory
            db_wrapper.log_activity(
                str(guild.id),
                'member_unban',
                f"{user.name} was unbanned by {moderator}"
            )
        except Exception as e:
            # Fallback logging without audit log details
            embed = discord.Embed(
                title="✅ Member Unbanned",
                description=f"**{user} was unbanned**\n**User ID:** {user.id}",
                color=discord.Color.green(),
                timestamp=datetime.utcnow()
            )
            await self.log_to_channel(guild, embed)

    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        """Log voice channel activity."""
        settings = self.get_guild_settings(member.guild.id)
        if not settings.get('voice_logging_enabled', False):
            return

        if before.channel == after.channel:
            return  # No channel change
            
        embed = discord.Embed(
            color=discord.Color.blue(),
            timestamp=datetime.utcnow()
        )

        embed.add_field(
            name="Member",
            value=f"{member.mention} (`{member.id}`)",
            inline=True
        )

        if before.channel is None and after.channel is not None:
            # Member joined voice
            embed.title = "🔊 Voice Channel Joined"
            embed.add_field(
                name="Channel",
                value=f"{after.channel.mention}",
                inline=True
            )
            
        elif before.channel is not None and after.channel is None:
            # Member left voice
            embed.title = "🔇 Voice Channel Left" 
            embed.add_field(
                name="Channel",
                value=f"{before.channel.mention}",
                inline=True
            )
            
        elif before.channel != after.channel:
            # Member switched channels
            embed.title = "🔄 Voice Channel Switched"
            embed.add_field(
                name="From",
                value=f"{before.channel.mention}",
                inline=True
            )
            embed.add_field(
                name="To", 
                value=f"{after.channel.mention}",
                inline=True
            )

        embed.set_footer(text=f"User ID: {member.id}")
        await self.log_to_channel(member.guild, embed)

    @commands.command(name='toggle-voice-logs')
    @require_admin_role()
    async def toggle_voice_logging(self, ctx, enabled: bool = None):
        """Enable or disable voice activity logging."""
        settings = self.get_guild_settings(ctx.guild.id)
        
        if enabled is None:
            # Show current status
            status = "Enabled" if settings.get('voice_logging_enabled', False) else "Disabled"
            embed = create_info_embed(
                "Voice Logging Status",
                f"Voice logging is currently **{status}**"
            )
            await ctx.send(embed=embed)
            return

        settings['voice_logging_enabled'] = enabled
        db_wrapper.store_guild_settings(settings)

        status = "enabled" if enabled else "disabled"
        embed = create_success_embed(
            "Voice Logging Updated",
            f"Voice logging has been **{status}** for this server."
        )
        await ctx.send(embed=embed)

    @commands.command(name='toggle-message-logs', aliases=['toggle-msg-logs'])
    @require_admin_role()
    async def toggle_message_logging(self, ctx, enabled: bool = None):
        """Enable or disable message logging."""
        settings = self.get_guild_settings(ctx.guild.id)
        
        if enabled is None:
            # Show current status
            status = "Enabled" if settings.get('message_logging_enabled', False) else "Disabled"
            embed = create_info_embed(
                "Message Logging Status",
                f"Message logging is currently **{status}**"
            )
            await ctx.send(embed=embed)
            return

        settings['message_logging_enabled'] = enabled
        db_wrapper.store_guild_settings(settings)

        status = "enabled" if enabled else "disabled"
        embed = create_success_embed(
            "Message Logging Updated",
            f"Message logging has been **{status}** for this server."
        )
        await ctx.send(embed=embed)

    @commands.command(name='toggle-member-logs')
    @require_admin_role()
    async def toggle_member_logging(self, ctx, enabled: bool = None):
        """Enable or disable member join/leave logging."""
        settings = self.get_guild_settings(ctx.guild.id)
        
        if enabled is None:
            # Show current status
            status = "Enabled" if settings.get('member_logging_enabled', False) else "Disabled"
            embed = create_info_embed(
                "Member Logging Status",
                f"Member logging is currently **{status}**"
            )
            await ctx.send(embed=embed)
            return

        settings['member_logging_enabled'] = enabled
        db_wrapper.store_guild_settings(settings)

        status = "enabled" if enabled else "disabled"
        embed = create_success_embed(
            "Member Logging Updated",
            f"Member logging has been **{status}** for this server."
        )
        await ctx.send(embed=embed)

    @commands.command(name='logging-status', aliases=['log-status'])
    @require_admin_role()
    async def logging_status(self, ctx):
        """Check current logging configuration."""
        settings = self.get_guild_settings(ctx.guild.id)
        
        embed = discord.Embed(
            title="📊 Logging Configuration",
            color=discord.Color.blue(),
            timestamp=datetime.utcnow()
        )

        # Get log channel
        log_channel_id = settings.get('log_channel_id')
        log_channel = ctx.guild.get_channel(int(log_channel_id)) if log_channel_id else None

        embed.add_field(
            name="Log Channel",
            value=log_channel.mention if log_channel else "Not set",
            inline=True
        )

        embed.add_field(
            name="Message Logging",
            value="✅ Enabled" if settings.get('message_logging_enabled', False) else "❌ Disabled",
            inline=True
        )

        embed.add_field(
            name="Member Logging",
            value="✅ Enabled" if settings.get('member_logging_enabled', False) else "❌ Disabled",
            inline=True
        )

        embed.add_field(
            name="Voice Logging",
            value="✅ Enabled" if settings.get('voice_logging_enabled', False) else "❌ Disabled",
            inline=True
        )

        embed.add_field(
            name="Setup Instructions",
            value="1. Set log channel: `!set-log-channel #channel`\n"
                  "2. Enable message logs: `!toggle-message-logs true`\n"
                  "3. Enable member logs: `!toggle-member-logs true`\n"
                  "4. Enable voice logs: `!toggle-voice-logs true`",
            inline=False
        )

        await ctx.send(embed=embed)


async def setup(bot):
    """Setup function for the cog."""
    await bot.add_cog(MessageLogging(bot))
