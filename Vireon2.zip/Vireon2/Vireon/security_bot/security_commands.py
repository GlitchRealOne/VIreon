"""
Real security commands for anti-raid, anti-nuke, and verification systems.
"""

import asyncio
import random
import string
from datetime import datetime, timedelta
from typing import Optional, List
import discord
from discord.ext import commands, tasks
from discord import app_commands
import json

# Import database models only when available to prevent connection errors
try:
    from models import db, app, ScammerList, ServerBackup, VerificationData, RaidAlert, GuildSettings
    DB_AVAILABLE = True
except Exception:
    DB_AVAILABLE = False
from security_bot.permissions import require_admin_role
from security_bot.utils import create_success_embed, create_error_embed, create_info_embed, create_warning_embed


class SecurityCommands(commands.Cog):
    """Real security commands for server protection."""

    def __init__(self, bot):
        self.bot = bot
        self.join_tracking = {}  # Track recent joins per guild
        self.message_tracking = {}  # Track message patterns
        self.lockdown_status = {}  # Track which servers are in lockdown

        # Start background tasks only if database is available
        self.cleanup_tracking.start()
        if DB_AVAILABLE:
            self.auto_backup.start()

    async def cog_unload(self):
        """Clean up background tasks when cog is unloaded."""
        self.cleanup_tracking.cancel()
        self.auto_backup.cancel()

    @tasks.loop(minutes=5)
    async def cleanup_tracking(self):
        """Clean up old tracking data every 5 minutes."""
        current_time = datetime.utcnow()

        # Clean join tracking (keep only last 10 minutes)
        for guild_id in list(self.join_tracking.keys()):
            self.join_tracking[guild_id] = [
                join_time for join_time in self.join_tracking[guild_id]
                if current_time - join_time < timedelta(minutes=10)
            ]
            if not self.join_tracking[guild_id]:
                del self.join_tracking[guild_id]

    @cleanup_tracking.before_loop
    async def before_cleanup_tracking(self):
        await self.bot.wait_until_ready()

    def get_guild_settings(self, guild_id: int):
        """Get or create guild settings."""
        from database_wrapper import db_wrapper
        return db_wrapper.get_guild_settings(str(guild_id))

    async def log_security_event(self, guild: discord.Guild, event_type: str, description: str, color: discord.Color = discord.Color.orange()):
        """Log security events to the configured log channel."""
        settings = self.get_guild_settings(guild.id)
        log_channel_id = settings.get('log_channel_id')
        if log_channel_id:
            channel = guild.get_channel(int(log_channel_id))
            if channel and hasattr(channel, 'send'):
                embed = discord.Embed(
                    title=f"🛡️ Security Event: {event_type}",
                    description=description,
                    color=color,
                    timestamp=datetime.utcnow()
                )
                embed.set_footer(text=f"Guild: {guild.name}")
                try:
                    await channel.send(embed=embed)
                except discord.Forbidden:
                    pass  # Can't send to log channel

    

    # Server Backup System (functionality moved to AdminCommands to avoid duplication)

    async def create_server_backup(self, guild: discord.Guild, user_id: Optional[int] = None, auto_backup: bool = False):
        """Create a server backup."""
        backup_data = {
            'guild_info': {
                'name': guild.name,
                'description': guild.description,
                'icon_url': str(guild.icon.url) if guild.icon else None,
                'verification_level': str(guild.verification_level),
                'explicit_content_filter': str(guild.explicit_content_filter),
                'default_notifications': str(guild.default_notifications)
            },
            'channels': [],
            'roles': [],
            'created_at': datetime.utcnow().isoformat()
        }

        # Backup channels
        for channel in guild.channels:
            channel_data = {
                'id': str(channel.id),
                'name': channel.name,
                'type': str(channel.type),
                'position': channel.position
            }

            if isinstance(channel, discord.TextChannel):
                channel_data.update({
                    'topic': channel.topic,
                    'slowmode_delay': channel.slowmode_delay,
                    'nsfw': channel.nsfw
                })
            elif isinstance(channel, discord.VoiceChannel):
                channel_data.update({
                    'bitrate': channel.bitrate,
                    'user_limit': channel.user_limit
                })
            elif isinstance(channel, discord.CategoryChannel):
                channel_data['channels'] = [str(c.id) for c in channel.channels]

            backup_data['channels'].append(channel_data)

        # Backup roles (excluding @everyone and bot roles)
        for role in guild.roles:
            if role.name != "@everyone" and not role.managed:
                role_data = {
                    'id': str(role.id),
                    'name': role.name,
                    'color': role.color.value,
                    'permissions': role.permissions.value,
                    'hoist': role.hoist,
                    'mentionable': role.mentionable,
                    'position': role.position
                }
                backup_data['roles'].append(role_data)

        # Save backup using database wrapper
        try:
            from database_wrapper import db_wrapper

            backup_id = db_wrapper.create_backup(
                guild_id=str(guild.id),
                guild_name=guild.name,
                backup_data=backup_data,
                created_by=str(user_id) if user_id else "System"
            )

            # Update guild settings with last backup time
            settings = db_wrapper.get_guild_settings(str(guild.id))
            settings['last_backup'] = datetime.utcnow().isoformat()
            db_wrapper.update_guild_settings(str(guild.id), settings)

            print(f"Backup #{backup_id} created for {guild.name} ({'auto' if auto_backup else 'manual'})")

        except Exception as e:
            print(f"Error saving backup for {guild.name}: {e}")
            return

        # Log the event if not auto backup
        if not auto_backup:
            await self.log_security_event(
                guild,
                "Server Backup",
                f"Server backup created by {'System' if auto_backup else f'<@{user_id}>'}",
                discord.Color.green()
            )

    # All backup commands moved to AdminCommands to avoid duplication
    
    @commands.command(name='anti-raid', aliases=['antiraid'])
    @require_admin_role()
    async def toggle_anti_raid(self, ctx, enabled: bool = None):
        """Enable or disable anti-raid protection."""
        settings = self.get_guild_settings(ctx.guild.id)

        if enabled is None:
            # Show current status
            status = "Enabled" if settings.get('anti_raid_enabled', False) else "Disabled"
            embed = create_info_embed(
                "Anti-Raid Status",
                f"Anti-raid protection is currently **{status}**\n\n"
                f"**Settings:**\n"
                f"Join rate limit: {settings.get('join_rate_limit', 10)} users/minute\n"
                f"Mass mention limit: {settings.get('mass_mention_limit', 5)} mentions/message"
            )
            await ctx.send(embed=embed)
            return

        # Update settings using database wrapper
        from database_wrapper import db_wrapper
        settings['anti_raid_enabled'] = enabled
        db_wrapper.save_guild_settings(str(ctx.guild.id), settings)

        status = "enabled" if enabled else "disabled"
        embed = create_success_embed(
            "Anti-Raid Updated",
            f"Anti-raid protection has been **{status}** for this server."
        )
        await ctx.send(embed=embed)

    @commands.command(name='lockdown', aliases=['lock'])
    @require_admin_role()
    async def server_lockdown(self, ctx, duration: str = "10"):
        """Lock down the server to prevent new joins and messages. Use 'permanent' for no time limit."""
        if ctx.guild.id in self.lockdown_status:
            await ctx.send(embed=create_warning_embed("⚠️ Lockdown Status", "Server is already in lockdown mode."))
            return

        # Parse duration
        permanent = False
        duration_minutes = 10
        
        if duration.lower() in ['permanent', 'perm', 'forever', 'indefinite', 'no-time']:
            permanent = True
            duration_text = "permanent"
        else:
            try:
                duration_minutes = int(duration)
                duration_text = f"{duration_minutes} minutes"
            except ValueError:
                await ctx.send(embed=create_error_embed("Invalid Duration", "Use a number for minutes or 'permanent' for no time limit."))
                return

        # Store original permissions
        self.lockdown_status[ctx.guild.id] = {
            'end_time': None if permanent else datetime.utcnow() + timedelta(minutes=duration_minutes),
            'original_perms': {},
            'locked_by': ctx.author.id,
            'permanent': permanent
        }

        # Remove send message permissions from @everyone
        try:
            everyone_role = ctx.guild.default_role
            channels_locked = 0
            
            for channel in ctx.guild.text_channels:
                try:
                    overwrites = channel.overwrites_for(everyone_role)
                    self.lockdown_status[ctx.guild.id]['original_perms'][channel.id] = overwrites.send_messages
                    overwrites.send_messages = False
                    await channel.set_permissions(everyone_role, overwrite=overwrites, reason=f"Server lockdown by {ctx.author}")
                    channels_locked += 1
                except discord.Forbidden:
                    continue

            embed = create_warning_embed(
                "🔒 Server Lockdown Activated",
                f"Server is now in **LOCKDOWN MODE** {'permanently' if permanent else f'for **{duration_text}**'}.\n\n"
                f"**🔐 Restrictions Active:**\n"
                f"• {channels_locked} channels locked\n"
                f"• Only administrators can send messages\n"
                f"• New members cannot join voice channels\n\n"
                f"**⏰ Duration:** {'Permanent (manual unlock required)' if permanent else duration_text}\n"
                f"**🚨 Use `{ctx.prefix}unlock` to end lockdown**"
            )
            embed.set_footer(text=f"Lockdown activated by {ctx.author}")
            await ctx.send(embed=embed)

            # Log the event
            await self.log_security_event(
                ctx.guild,
                "Server Lockdown",
                f"🔒 **{'PERMANENT ' if permanent else ''}LOCKDOWN ACTIVATED**\n"
                f"• **Activated by:** {ctx.author.mention}\n"
                f"• **Duration:** {duration_text}\n"
                f"• **Channels locked:** {channels_locked}\n"
                f"• **Reason:** Administrative action",
                discord.Color.red()
            )

            # Auto-unlock after duration (only if not permanent)
            if not permanent:
                await asyncio.sleep(duration_minutes * 60)
                if ctx.guild.id in self.lockdown_status:
                    await self.unlock_server(ctx.guild)

        except discord.Forbidden:
            await ctx.send(embed=create_error_embed("Permission Error", "Missing permissions to modify channel permissions."))
        except Exception as e:
            await ctx.send(embed=create_error_embed("Lockdown Error", f"Error activating lockdown: {str(e)}"))

    @commands.command(name='unlock')
    @require_admin_role()
    async def unlock_server_command(self, ctx):
        """Remove server lockdown."""
        guild = ctx.guild

        if guild.id not in self.lockdown_status:
            await ctx.send(embed=create_error_embed("Server is not in lockdown mode."))
            return

        await self.unlock_server(guild)

        embed = create_success_embed(
            "🔓 Server Unlocked",
            "Server lockdown has been removed. Normal operations restored."
        )
        await ctx.send(embed=embed)

    @commands.command(name='emergency-lock', aliases=['elock', 'emlock'])
    @require_admin_role()
    async def emergency_lockdown(self, ctx):
        """Immediately lock the entire server with all restrictions."""
        if ctx.guild.id in self.lockdown_status:
            await ctx.send(embed=create_warning_embed("⚠️ Lockdown Status", "Server is already in lockdown mode."))
            return

        # Store original permissions for comprehensive lockdown
        self.lockdown_status[ctx.guild.id] = {
            'end_time': None,  # Emergency locks are permanent until manually unlocked
            'original_perms': {},
            'original_voice_perms': {},
            'locked_by': ctx.author.id,
            'permanent': True,
            'emergency': True
        }

        try:
            everyone_role = ctx.guild.default_role
            channels_locked = 0
            voice_channels_locked = 0
            
            # Lock all text channels
            for channel in ctx.guild.text_channels:
                try:
                    overwrites = channel.overwrites_for(everyone_role)
                    self.lockdown_status[ctx.guild.id]['original_perms'][channel.id] = {
                        'send_messages': overwrites.send_messages,
                        'add_reactions': overwrites.add_reactions,
                        'create_public_threads': overwrites.create_public_threads,
                        'create_private_threads': overwrites.create_private_threads
                    }
                    overwrites.send_messages = False
                    overwrites.add_reactions = False
                    overwrites.create_public_threads = False
                    overwrites.create_private_threads = False
                    await channel.set_permissions(everyone_role, overwrite=overwrites, reason=f"Emergency lockdown by {ctx.author}")
                    channels_locked += 1
                except discord.Forbidden:
                    continue

            # Lock all voice channels
            for channel in ctx.guild.voice_channels:
                try:
                    overwrites = channel.overwrites_for(everyone_role)
                    self.lockdown_status[ctx.guild.id]['original_voice_perms'][channel.id] = {
                        'connect': overwrites.connect,
                        'speak': overwrites.speak
                    }
                    overwrites.connect = False
                    overwrites.speak = False
                    await channel.set_permissions(everyone_role, overwrite=overwrites, reason=f"Emergency lockdown by {ctx.author}")
                    voice_channels_locked += 1
                except discord.Forbidden:
                    continue

            embed = create_error_embed(
                "🚨 EMERGENCY LOCKDOWN ACTIVATED",
                f"**FULL SERVER LOCKDOWN IN EFFECT**\n\n"
                f"**🔐 Complete Restrictions:**\n"
                f"• {channels_locked} text channels locked\n"
                f"• {voice_channels_locked} voice channels locked\n"
                f"• All messaging disabled\n"
                f"• All voice access disabled\n"
                f"• Thread creation disabled\n"
                f"• Reactions disabled\n\n"
                f"**⚠️ Duration:** PERMANENT - Manual unlock required\n"
                f"**🚨 Use `{ctx.prefix}unlock` to restore server**"
            )
            embed.set_footer(text=f"Emergency lockdown by {ctx.author}")
            await ctx.send(embed=embed)

            # Log the event
            await self.log_security_event(
                ctx.guild,
                "EMERGENCY LOCKDOWN",
                f"🚨 **FULL EMERGENCY LOCKDOWN ACTIVATED**\n"
                f"• **Activated by:** {ctx.author.mention}\n"
                f"• **Type:** Complete server lockdown\n"
                f"• **Text channels locked:** {channels_locked}\n"
                f"• **Voice channels locked:** {voice_channels_locked}\n"
                f"• **Status:** Permanent until manual unlock",
                discord.Color.dark_red()
            )

        except discord.Forbidden:
            await ctx.send(embed=create_error_embed("Permission Error", "Missing permissions to modify channel permissions."))
        except Exception as e:
            await ctx.send(embed=create_error_embed("Emergency Lockdown Error", f"Error activating emergency lockdown: {str(e)}"))

    async def unlock_server(self, guild: discord.Guild):
        """Helper method to unlock a server."""
        if guild.id not in self.lockdown_status:
            return

        lockdown_info = self.lockdown_status[guild.id]
        everyone_role = guild.default_role
        is_emergency = lockdown_info.get('emergency', False)

        try:
            # Restore original text channel permissions
            for channel in guild.text_channels:
                if channel.id in lockdown_info['original_perms']:
                    overwrites = channel.overwrites_for(everyone_role)
                    original = lockdown_info['original_perms'][channel.id]
                    
                    if is_emergency:
                        # Restore all emergency lockdown permissions
                        overwrites.send_messages = original.get('send_messages')
                        overwrites.add_reactions = original.get('add_reactions')
                        overwrites.create_public_threads = original.get('create_public_threads')
                        overwrites.create_private_threads = original.get('create_private_threads')
                    else:
                        # Restore regular lockdown permissions
                        overwrites.send_messages = original if isinstance(original, bool) else original.get('send_messages')
                    
                    await channel.set_permissions(everyone_role, overwrite=overwrites, reason="Lockdown ended")

            # Restore original voice channel permissions (for emergency lockdown)
            if is_emergency and 'original_voice_perms' in lockdown_info:
                for channel in guild.voice_channels:
                    if channel.id in lockdown_info['original_voice_perms']:
                        overwrites = channel.overwrites_for(everyone_role)
                        original = lockdown_info['original_voice_perms'][channel.id]
                        overwrites.connect = original.get('connect')
                        overwrites.speak = original.get('speak')
                        await channel.set_permissions(everyone_role, overwrite=overwrites, reason="Emergency lockdown ended")

            del self.lockdown_status[guild.id]

            # Log the event
            lockdown_type = "Emergency Lockdown" if is_emergency else "Server Lockdown"
            await self.log_security_event(
                guild,
                f"{lockdown_type} Ended",
                f"{'🚨 Emergency lockdown' if is_emergency else '🔒 Server lockdown'} has been removed",
                discord.Color.green()
            )

        except Exception as e:
            print(f"Error unlocking server {guild.name}: {e}")

    @commands.command(name='security-scan', aliases=['scan'])
    @require_admin_role()
    async def security_scan(self, ctx):
        """Perform a comprehensive security scan of the server."""
        embed = discord.Embed(
            title="🔍 Security Scan in Progress...",
            description="Analyzing server security...",
            color=discord.Color.orange()
        )

        message = await ctx.send(embed=embed)

        # Analyze server security
        issues = []
        recommendations = []

        # Check for suspicious roles
        for role in ctx.guild.roles:
            if role.permissions.administrator and role != ctx.guild.default_role:
                if role.members:
                    admin_count = len(role.members)
                    if admin_count > 5:  # Too many admins
                        issues.append(f"Role '{role.name}' has {admin_count} administrators")

        # Check for channels without permissions
        public_channels = 0
        for channel in ctx.guild.text_channels:
            if channel.permissions_for(ctx.guild.default_role).read_messages:
                public_channels += 1

        if public_channels == len(ctx.guild.text_channels):
            recommendations.append("Consider making some channels private")

        # Check verification level
        if ctx.guild.verification_level == discord.VerificationLevel.none:
            issues.append("Server has no verification requirement")
            recommendations.append("Enable server verification level")

        # Create scan results embed
        scan_embed = discord.Embed(
            title="🛡️ Security Scan Results",
            color=discord.Color.red() if issues else discord.Color.green()
        )

        if issues:
            scan_embed.add_field(
                name="⚠️ Security Issues Found",
                value='\n'.join(f"• {issue}" for issue in issues[:5]),
                inline=False
            )
        else:
            scan_embed.add_field(
                name="✅ No Major Issues",
                value="Server security looks good!",
                inline=False
            )

        if recommendations:
            scan_embed.add_field(
                name="💡 Recommendations",
                value='\n'.join(f"• {rec}" for rec in recommendations[:5]),
                inline=False
            )

        scan_embed.add_field(
            name="📊 Server Stats",
            value=f"Members: {ctx.guild.member_count}\nChannels: {len(ctx.guild.channels)}\nRoles: {len(ctx.guild.roles)}",
            inline=True
        )

        await message.edit(embed=scan_embed)

    @commands.command(name='mass-ban', aliases=['massban'])
    @require_admin_role()
    async def mass_ban_users(self, ctx, *, user_ids: str):
        """Ban multiple users by their IDs (space separated)."""
        ids = user_ids.split()

        if len(ids) > 10:
            await ctx.send(embed=create_error_embed("Cannot ban more than 10 users at once for safety."))
            return

        embed = discord.Embed(
            title="⚠️ Mass Ban Confirmation",
            description=f"You are about to ban **{len(ids)}** users. React with ✅ to confirm.",
            color=discord.Color.orange()
        )

        message = await ctx.send(embed=embed)
        await message.add_reaction("✅")
        await message.add_reaction("❌")

        def check(reaction, user):
            return user == ctx.author and str(reaction.emoji) in ["✅", "❌"]

        try:
            reaction, user = await self.bot.wait_for('reaction_add', timeout=30.0, check=check)

            if str(reaction.emoji) == "❌":
                await ctx.send(embed=create_error_embed("Mass ban cancelled."))
                return

            banned_count = 0
            failed_bans = []

            for user_id in ids:
                try:
                    if user_id.isdigit():
                        user = await self.bot.fetch_user(int(user_id))
                        await ctx.guild.ban(user, reason=f"Mass ban by {ctx.author}")
                        banned_count += 1
                    else:
                        failed_bans.append(f"Invalid ID: {user_id}")
                except discord.NotFound:
                    failed_bans.append(f"User not found: {user_id}")
                except discord.Forbidden:
                    failed_bans.append(f"Cannot ban: {user_id}")
                except Exception as e:
                    failed_bans.append(f"Error with {user_id}: {str(e)}")

            result_embed = create_success_embed(
                "Mass Ban Results",
                f"Successfully banned {banned_count} users"
            )

            if failed_bans:
                result_embed.add_field(
                    name="Failed Bans",
                    value='\n'.join(failed_bans[:5]),
                    inline=False
                )

            await ctx.send(embed=result_embed)

            # Log the event
            await self.log_security_event(
                ctx.guild,
                "Mass Ban",
                f"{ctx.author.mention} banned {banned_count} users",
                discord.Color.red()
            )

        except asyncio.TimeoutError:
            await ctx.send(embed=create_error_embed("Mass ban confirmation timed out."))

    @commands.command(name='audit-log', aliases=['audit'])
    @require_admin_role()
    async def audit_log(self, ctx, limit: int = 10):
        """View recent audit log entries."""
        if limit > 20:
            limit = 20

        try:
            audit_entries = []
            async for entry in ctx.guild.audit_logs(limit=limit):
                audit_entries.append(entry)

            if not audit_entries:
                await ctx.send(embed=create_info_embed("No Audit Entries", "No recent audit log entries found."))
                return

            embed = discord.Embed(
                title="📋 Recent Audit Log",
                description=f"Last {len(audit_entries)} entries",
                color=discord.Color.blue()
            )

            for i, entry in enumerate(audit_entries[:10], 1):
                timestamp = entry.created_at.strftime("%m/%d %H:%M")
                embed.add_field(
                    name=f"{i}. {entry.action.name}",
                    value=f"By: {entry.user.mention if entry.user else 'Unknown'}\nTime: {timestamp}",
                    inline=True
                )

            await ctx.send(embed=embed)

        except discord.Forbidden:
            await ctx.send(embed=create_error_embed("Missing permissions to view audit log."))

    @commands.command(name='member-info', aliases=['memberinfo'])
    @require_admin_role()
    async def member_info(self, ctx, user: discord.Member = None):
        """Get detailed information about a member."""
        if user is None:
            user = ctx.author

        embed = discord.Embed(
            title=f"👤 Member Information: {user.display_name}",
            color=discord.Color.blue()
        )

        embed.set_thumbnail(url=user.display_avatar.url)

        embed.add_field(
            name="Basic Info",
            value=f"**Username:** {user.name}\n"
                  f"**ID:** {user.id}\n"
                  f"**Bot:** {'Yes' if user.bot else 'No'}",
            inline=True
        )

        embed.add_field(
            name="Server Info",
            value=f"**Joined:** {user.joined_at.strftime('%Y-%m-%d') if user.joined_at else 'Unknown'}\n"
                  f"**Roles:** {len(user.roles) - 1}\n"
                  f"**Top Role:** {user.top_role.mention}",
            inline=True
        )

        embed.add_field(
            name="Account Info",
            value=f"**Created:** {user.created_at.strftime('%Y-%m-%d')}\n"
                  f"**Account Age:** {(discord.utils.utcnow() - user.created_at).days} days",
            inline=True
        )

        await ctx.send(embed=embed)

    @commands.command(name='kick-inactive', aliases=['kickinactive'])
    @require_admin_role()
    async def kick_inactive_members(self, ctx, days: int = 30):
        """Kick members who haven't been active for specified days."""
        if days < 7:
            await ctx.send(embed=create_error_embed("Minimum inactive period is 7 days."))
            return

        embed = discord.Embed(
            title="⚠️ Kick Inactive Members",
            description=f"This will kick members inactive for {days}+ days. React with ✅ to confirm.",
            color=discord.Color.orange()
        )

        message = await ctx.send(embed=embed)
        await message.add_reaction("✅")
        await message.add_reaction("❌")

        def check(reaction, user):
            return user == ctx.author and str(reaction.emoji) in ["✅", "❌"]

        try:
            reaction, user = await self.bot.wait_for('reaction_add', timeout=30.0, check=check)

            if str(reaction.emoji) == "❌":
                await ctx.send(embed=create_error_embed("Operation cancelled."))
                return

            inactive_members = []
            cutoff_date = datetime.utcnow() - timedelta(days=days)

            for member in ctx.guild.members:
                if member.bot or member.guild_permissions.administrator:
                    continue

                # Check if member joined before cutoff and has no recent activity
                if member.joined_at and member.joined_at < cutoff_date:
                    # Simple activity check - you can enhance this
                    inactive_members.append(member)

            if not inactive_members:
                await ctx.send(embed=create_info_embed("No Inactive Members", "No inactive members found."))
                return

            kicked_count = 0
            for member in inactive_members[:20]:  # Limit to 20 for safety
                try:
                    await member.kick(reason=f"Inactive for {days}+ days")
                    kicked_count += 1
                except discord.Forbidden:
                    continue

            result_embed = create_success_embed(
                "Inactive Members Removed",
                f"Kicked {kicked_count} inactive members"
            )
            await ctx.send(embed=result_embed)

        except asyncio.TimeoutError:
            await ctx.send(embed=create_error_embed("Confirmation timed out."))

    @commands.command(name='channel-lockdown', aliases=['lockchannels'])
    @require_admin_role()
    async def channel_lockdown(self, ctx, *channels: discord.TextChannel):
        """Lock specific channels."""
        if not channels:
            channels = [ctx.channel]

        locked_channels = []

        for channel in channels:
            try:
                overwrites = channel.overwrites_for(ctx.guild.default_role)
                overwrites.send_messages = False
                await channel.set_permissions(ctx.guild.default_role, overwrite=overwrites, reason=f"Channel lockdown by {ctx.author}")
                locked_channels.append(channel.mention)
            except discord.Forbidden:
                continue

        if locked_channels:
            embed = create_success_embed(
                "🔒 Channels Locked",
                f"Locked {len(locked_channels)} channels:\n" + '\n'.join(locked_channels)
            )
            await ctx.send(embed=embed)
        else:
            await ctx.send(embed=create_error_embed("Failed to lock any channels."))

    @commands.command(name='clear', aliases=['purge'])
    @require_admin_role()
    async def clear_messages(self, ctx, amount: int = 10, channel: discord.TextChannel = None):
        """Delete messages in a specific channel."""
        if channel is None:
            channel = ctx.channel

        if amount < 1 or amount > 100:
            await ctx.send(embed=create_error_embed("Invalid Amount", "Amount must be between 1 and 100 messages."))
            return

        try:
            # Get confirmation for large deletions
            if amount > 50:
                embed = discord.Embed(
                    title="⚠️ Mass Message Deletion",
                    description=f"You are about to delete **{amount}** messages from {channel.mention}. React with ✅ to confirm.",
                    color=discord.Color.orange()
                )
                
                message = await ctx.send(embed=embed)
                await message.add_reaction("✅")
                await message.add_reaction("❌")

                def check(reaction, user):
                    return user == ctx.author and str(reaction.emoji) in ["✅", "❌"]

                try:
                    reaction, user = await self.bot.wait_for('reaction_add', timeout=30.0, check=check)
                    
                    if str(reaction.emoji) == "❌":
                        await ctx.send(embed=create_error_embed("Message deletion cancelled."))
                        return
                        
                except asyncio.TimeoutError:
                    await ctx.send(embed=create_error_embed("Confirmation timed out."))
                    return

            # Delete messages
            deleted = await channel.purge(limit=amount, check=lambda m: not m.pinned)
            
            embed = create_success_embed(
                "Messages Cleared",
                f"Successfully deleted **{len(deleted)}** messages from {channel.mention}\n"
                f"**Requested by:** {ctx.author.mention}"
            )
            
            # Send confirmation and auto-delete after 5 seconds
            confirmation = await ctx.send(embed=embed)
            await asyncio.sleep(5)
            try:
                await confirmation.delete()
            except discord.NotFound:
                pass

            # Log the event
            await self.log_security_event(
                ctx.guild,
                "Messages Cleared",
                f"**Channel:** {channel.mention}\n"
                f"**Messages deleted:** {len(deleted)}\n"
                f"**Cleared by:** {ctx.author.mention}",
                discord.Color.blue()
            )

        except discord.Forbidden:
            await ctx.send(embed=create_error_embed("Permission Error", "I don't have permission to delete messages in that channel."))
        except Exception as e:
            await ctx.send(embed=create_error_embed("Clear Error", f"Failed to clear messages: {str(e)}"))

    @commands.command(name='database-status', aliases=['dbstatus'])
    @require_admin_role()
    async def database_status(self, ctx):
        """Check database connection and status."""
        from database_wrapper import db_wrapper
        
        status = db_wrapper.get_status()
        
        embed = discord.Embed(
            title="🗄️ Database Status",
            color=discord.Color.green() if status['database_available'] else discord.Color.orange()
        )
        
        # Database availability
        db_status = "🟢 Connected" if status['database_available'] else "🟡 Memory Mode (Fallback)"
        embed.add_field(
            name="Database Connection",
            value=db_status,
            inline=False
        )
        
        # Fallback data counts
        embed.add_field(
            name="📊 Data Counts",
            value=f"**Backups:** {status['fallback_backups']}\n"
                  f"**Verifications:** {status['fallback_verifications']}",
            inline=True
        )
        
        # Status explanation
        if not status['database_available']:
            embed.add_field(
                name="ℹ️ Note",
                value="Bot is running in memory mode. Data will persist during this session but may be lost on restart.",
                inline=False
            )
        
        await ctx.send(embed=embed)

    @commands.command(name='role-audit', aliases=['roleaudit'])
    @require_admin_role()
    async def role_audit(self, ctx):
        """Audit dangerous role permissions."""
        dangerous_perms = [
            'administrator',
            'manage_guild',
            'manage_roles',
            'manage_channels',
            'ban_members',
            'kick_members'
        ]

        dangerous_roles = []

        for role in ctx.guild.roles:
            if role == ctx.guild.default_role:
                continue

            role_perms = []
            for perm, value in role.permissions:
                if value and perm in dangerous_perms:
                    role_perms.append(perm)

            if role_perms:
                dangerous_roles.append({
                    'role': role,
                    'permissions': role_perms,
                    'member_count': len(role.members)
                })

        if not dangerous_roles:
            await ctx.send(embed=create_success_embed("Role Audit", "No dangerous role permissions found."))
            return

        embed = discord.Embed(
            title="🔍 Role Permission Audit",
            description="Roles with elevated permissions:",
            color=discord.Color.orange()
        )

        for role_info in dangerous_roles[:10]:  # Limit to 10 roles
            role = role_info['role']
            perms = ', '.join(role_info['permissions'])
            members = role_info['member_count']

            embed.add_field(
                name=f"{role.name}",
                value=f"**Members:** {members}\n**Permissions:** {perms}",
                inline=True
            )

        await ctx.send(embed=embed)

    # Moderation Commands
    @commands.command(name='kick')
    @require_admin_role()
    async def kick_user(self, ctx, member: discord.Member, *, reason: str = "No reason provided"):
        """Kick a user from the server."""
        if member == ctx.author:
            await ctx.send(embed=create_error_embed("Action Denied", "You cannot kick yourself."))
            return
            
        if member.guild_permissions.administrator:
            await ctx.send(embed=create_error_embed("Action Denied", "Cannot kick administrators."))
            return

        if member.top_role >= ctx.author.top_role:
            await ctx.send(embed=create_error_embed("Action Denied", "Cannot kick users with equal or higher roles."))
            return

        try:
            # Send DM to user before kicking
            try:
                dm_embed = discord.Embed(
                    title="🚪 You have been kicked",
                    description=f"You were kicked from **{ctx.guild.name}**",
                    color=discord.Color.orange()
                )
                dm_embed.add_field(name="Reason", value=reason, inline=False)
                dm_embed.add_field(name="Kicked by", value=str(ctx.author), inline=False)
                await member.send(embed=dm_embed)
            except discord.Forbidden:
                pass  # User has DMs disabled

            await member.kick(reason=f"Kicked by {ctx.author}: {reason}")

            embed = create_success_embed(
                "User Kicked",
                f"**User:** {member.mention} ({member})\n"
                f"**Reason:** {reason}\n"
                f"**Kicked by:** {ctx.author.mention}"
            )
            await ctx.send(embed=embed)

            # Log the event
            await self.log_security_event(
                ctx.guild,
                "Member Kicked",
                f"**User:** {member} ({member.id})\n"
                f"**Reason:** {reason}\n"
                f"**Kicked by:** {ctx.author.mention}",
                discord.Color.orange()
            )

        except discord.Forbidden:
            await ctx.send(embed=create_error_embed("Permission Error", "I don't have permission to kick this user."))
        except Exception as e:
            await ctx.send(embed=create_error_embed("Kick Error", f"Failed to kick user: {str(e)}"))

    @commands.command(name='ban')
    @require_admin_role()
    async def ban_user(self, ctx, member: discord.Member, *, reason: str = "No reason provided"):
        """Ban a user from the server."""
        if member == ctx.author:
            await ctx.send(embed=create_error_embed("Action Denied", "You cannot ban yourself."))
            return
            
        if member.guild_permissions.administrator:
            await ctx.send(embed=create_error_embed("Action Denied", "Cannot ban administrators."))
            return

        if member.top_role >= ctx.author.top_role:
            await ctx.send(embed=create_error_embed("Action Denied", "Cannot ban users with equal or higher roles."))
            return

        try:
            # Send DM to user before banning
            try:
                dm_embed = discord.Embed(
                    title="🔨 You have been banned",
                    description=f"You were banned from **{ctx.guild.name}**",
                    color=discord.Color.red()
                )
                dm_embed.add_field(name="Reason", value=reason, inline=False)
                dm_embed.add_field(name="Banned by", value=str(ctx.author), inline=False)
                await member.send(embed=dm_embed)
            except discord.Forbidden:
                pass  # User has DMs disabled

            await member.ban(reason=f"Banned by {ctx.author}: {reason}")

            embed = create_success_embed(
                "User Banned",
                f"**User:** {member.mention} ({member})\n"
                f"**Reason:** {reason}\n"
                f"**Banned by:** {ctx.author.mention}"
            )
            await ctx.send(embed=embed)

            # Log the event
            await self.log_security_event(
                ctx.guild,
                "Member Banned",
                f"**User:** {member} ({member.id})\n"
                f"**Reason:** {reason}\n"
                f"**Banned by:** {ctx.author.mention}",
                discord.Color.red()
            )

        except discord.Forbidden:
            await ctx.send(embed=create_error_embed("Permission Error", "I don't have permission to ban this user."))
        except Exception as e:
            await ctx.send(embed=create_error_embed("Ban Error", f"Failed to ban user: {str(e)}"))

    @commands.command(name='unban')
    @require_admin_role()
    async def unban_user(self, ctx, user_id: int, *, reason: str = "No reason provided"):
        """Unban a user by their ID."""
        try:
            user = await self.bot.fetch_user(user_id)
            await ctx.guild.unban(user, reason=f"Unbanned by {ctx.author}: {reason}")

            embed = create_success_embed(
                "User Unbanned",
                f"**User:** {user} ({user.id})\n"
                f"**Reason:** {reason}\n"
                f"**Unbanned by:** {ctx.author.mention}"
            )
            await ctx.send(embed=embed)

            # Log the event
            await self.log_security_event(
                ctx.guild,
                "Member Unbanned",
                f"**User:** {user} ({user.id})\n"
                f"**Reason:** {reason}\n"
                f"**Unbanned by:** {ctx.author.mention}",
                discord.Color.green()
            )

        except discord.NotFound:
            await ctx.send(embed=create_error_embed("User Not Found", "User is not banned or doesn't exist."))
        except discord.Forbidden:
            await ctx.send(embed=create_error_embed("Permission Error", "I don't have permission to unban users."))
        except Exception as e:
            await ctx.send(embed=create_error_embed("Unban Error", f"Failed to unban user: {str(e)}"))

    @commands.command(name='mute')
    @require_admin_role()
    async def mute_user(self, ctx, member: discord.Member, duration: int = 60, *, reason: str = "No reason provided"):
        """Mute a user for a specified duration (in minutes)."""
        if member == ctx.author:
            await ctx.send(embed=create_error_embed("Action Denied", "You cannot mute yourself."))
            return
            
        if member.guild_permissions.administrator:
            await ctx.send(embed=create_error_embed("Action Denied", "Cannot mute administrators."))
            return

        if member.top_role >= ctx.author.top_role:
            await ctx.send(embed=create_error_embed("Action Denied", "Cannot mute users with equal or higher roles."))
            return

        try:
            # Calculate mute duration
            mute_until = datetime.utcnow() + timedelta(minutes=duration)
            
            await member.timeout(mute_until, reason=f"Muted by {ctx.author}: {reason}")

            embed = create_success_embed(
                "User Muted",
                f"**User:** {member.mention} ({member})\n"
                f"**Duration:** {duration} minutes\n"
                f"**Reason:** {reason}\n"
                f"**Muted by:** {ctx.author.mention}\n"
                f"**Mute expires:** <t:{int(mute_until.timestamp())}:R>"
            )
            await ctx.send(embed=embed)

            # Send DM to user
            try:
                dm_embed = discord.Embed(
                    title="🔇 You have been muted",
                    description=f"You were muted in **{ctx.guild.name}**",
                    color=discord.Color.orange()
                )
                dm_embed.add_field(name="Duration", value=f"{duration} minutes", inline=False)
                dm_embed.add_field(name="Reason", value=reason, inline=False)
                dm_embed.add_field(name="Muted by", value=str(ctx.author), inline=False)
                dm_embed.add_field(name="Expires", value=f"<t:{int(mute_until.timestamp())}:R>", inline=False)
                await member.send(embed=dm_embed)
            except discord.Forbidden:
                pass  # User has DMs disabled

            # Log the event
            await self.log_security_event(
                ctx.guild,
                "Member Muted",
                f"**User:** {member} ({member.id})\n"
                f"**Duration:** {duration} minutes\n"
                f"**Reason:** {reason}\n"
                f"**Muted by:** {ctx.author.mention}",
                discord.Color.orange()
            )

        except discord.Forbidden:
            await ctx.send(embed=create_error_embed("Permission Error", "I don't have permission to timeout this user."))
        except Exception as e:
            await ctx.send(embed=create_error_embed("Mute Error", f"Failed to mute user: {str(e)}"))

    @commands.command(name='unmute')
    @require_admin_role()
    async def unmute_user(self, ctx, member: discord.Member, *, reason: str = "No reason provided"):
        """Remove timeout/mute from a user."""
        try:
            await member.timeout(None, reason=f"Unmuted by {ctx.author}: {reason}")

            embed = create_success_embed(
                "User Unmuted",
                f"**User:** {member.mention} ({member})\n"
                f"**Reason:** {reason}\n"
                f"**Unmuted by:** {ctx.author.mention}"
            )
            await ctx.send(embed=embed)

            # Send DM to user
            try:
                dm_embed = discord.Embed(
                    title="🔊 You have been unmuted",
                    description=f"Your mute in **{ctx.guild.name}** has been removed",
                    color=discord.Color.green()
                )
                dm_embed.add_field(name="Unmuted by", value=str(ctx.author), inline=False)
                dm_embed.add_field(name="Reason", value=reason, inline=False)
                await member.send(embed=dm_embed)
            except discord.Forbidden:
                pass  # User has DMs disabled

            # Log the event
            await self.log_security_event(
                ctx.guild,
                "Member Unmuted",
                f"**User:** {member} ({member.id})\n"
                f"**Reason:** {reason}\n"
                f"**Unmuted by:** {ctx.author.mention}",
                discord.Color.green()
            )

        except discord.Forbidden:
            await ctx.send(embed=create_error_embed("Permission Error", "I don't have permission to remove timeout from this user."))
        except Exception as e:
            await ctx.send(embed=create_error_embed("Unmute Error", f"Failed to unmute user: {str(e)}"))

    @commands.command(name='warn')
    @require_admin_role()
    async def warn_user(self, ctx, member: discord.Member, *, reason: str = "No reason provided"):
        """Issue a warning to a user."""
        if member == ctx.author:
            await ctx.send(embed=create_error_embed("Action Denied", "You cannot warn yourself."))
            return

        try:
            # Send warning DM
            dm_embed = discord.Embed(
                title="⚠️ Warning Issued",
                description=f"You have received a warning in **{ctx.guild.name}**",
                color=discord.Color.yellow()
            )
            dm_embed.add_field(name="Reason", value=reason, inline=False)
            dm_embed.add_field(name="Warned by", value=str(ctx.author), inline=False)
            dm_embed.add_field(name="Note", value="Please review the server rules to avoid further warnings.", inline=False)
            
            try:
                await member.send(embed=dm_embed)
                dm_sent = "✅ DM sent"
            except discord.Forbidden:
                dm_sent = "❌ DM failed (user has DMs disabled)"

            embed = create_warning_embed(
                "Warning Issued",
                f"**User:** {member.mention} ({member})\n"
                f"**Reason:** {reason}\n"
                f"**Warned by:** {ctx.author.mention}\n"
                f"**DM Status:** {dm_sent}"
            )
            await ctx.send(embed=embed)

            # Log the event
            await self.log_security_event(
                ctx.guild,
                "Warning Issued",
                f"**User:** {member} ({member.id})\n"
                f"**Reason:** {reason}\n"
                f"**Warned by:** {ctx.author.mention}",
                discord.Color.yellow()
            )

        except Exception as e:
            await ctx.send(embed=create_error_embed("Warning Error", f"Failed to issue warning: {str(e)}"))

    # Slash Command Implementations
    @app_commands.command(name="kick", description="Kick a user from the server")
    @app_commands.describe(member="The member to kick", reason="Reason for the kick")
    async def slash_kick_user(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
        """Slash command version of kick."""
        # Check admin permissions
        if not interaction.user.guild_permissions.administrator:
            embed = create_error_embed("Permission Denied", "You need the Administrator permission to use this command.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        if member == interaction.user:
            await interaction.response.send_message(embed=create_error_embed("Action Denied", "You cannot kick yourself."), ephemeral=True)
            return
            
        if member.guild_permissions.administrator:
            await interaction.response.send_message(embed=create_error_embed("Action Denied", "Cannot kick administrators."), ephemeral=True)
            return

        if member.top_role >= interaction.user.top_role:
            await interaction.response.send_message(embed=create_error_embed("Action Denied", "Cannot kick users with equal or higher roles."), ephemeral=True)
            return

        try:
            # Send DM to user before kicking
            try:
                dm_embed = discord.Embed(
                    title="🚪 You have been kicked",
                    description=f"You were kicked from **{interaction.guild.name}**",
                    color=discord.Color.orange()
                )
                dm_embed.add_field(name="Reason", value=reason, inline=False)
                dm_embed.add_field(name="Kicked by", value=str(interaction.user), inline=False)
                await member.send(embed=dm_embed)
            except discord.Forbidden:
                pass  # User has DMs disabled

            await member.kick(reason=f"Kicked by {interaction.user}: {reason}")

            embed = create_success_embed(
                "User Kicked",
                f"**User:** {member.mention} ({member})\n"
                f"**Reason:** {reason}\n"
                f"**Kicked by:** {interaction.user.mention}"
            )
            await interaction.response.send_message(embed=embed)

            # Log the event
            await self.log_security_event(
                interaction.guild,
                "Member Kicked",
                f"**User:** {member} ({member.id})\n"
                f"**Reason:** {reason}\n"
                f"**Kicked by:** {interaction.user.mention}",
                discord.Color.orange()
            )

        except discord.Forbidden:
            await interaction.response.send_message(embed=create_error_embed("Permission Error", "I don't have permission to kick this user."), ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(embed=create_error_embed("Kick Error", f"Failed to kick user: {str(e)}"), ephemeral=True)

    @app_commands.command(name="ban", description="Ban a user from the server")
    @app_commands.describe(member="The member to ban", reason="Reason for the ban")
    async def slash_ban_user(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
        """Slash command version of ban."""
        # Check admin permissions
        if not interaction.user.guild_permissions.administrator:
            embed = create_error_embed("Permission Denied", "You need the Administrator permission to use this command.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        if member == interaction.user:
            await interaction.response.send_message(embed=create_error_embed("Action Denied", "You cannot ban yourself."), ephemeral=True)
            return
            
        if member.guild_permissions.administrator:
            await interaction.response.send_message(embed=create_error_embed("Action Denied", "Cannot ban administrators."), ephemeral=True)
            return

        if member.top_role >= interaction.user.top_role:
            await interaction.response.send_message(embed=create_error_embed("Action Denied", "Cannot ban users with equal or higher roles."), ephemeral=True)
            return

        try:
            # Send DM to user before banning
            try:
                dm_embed = discord.Embed(
                    title="🔨 You have been banned",
                    description=f"You were banned from **{interaction.guild.name}**",
                    color=discord.Color.red()
                )
                dm_embed.add_field(name="Reason", value=reason, inline=False)
                dm_embed.add_field(name="Banned by", value=str(interaction.user), inline=False)
                await member.send(embed=dm_embed)
            except discord.Forbidden:
                pass  # User has DMs disabled

            await member.ban(reason=f"Banned by {interaction.user}: {reason}")

            embed = create_success_embed(
                "User Banned",
                f"**User:** {member.mention} ({member})\n"
                f"**Reason:** {reason}\n"
                f"**Banned by:** {interaction.user.mention}"
            )
            await interaction.response.send_message(embed=embed)

            # Log the event
            await self.log_security_event(
                interaction.guild,
                "Member Banned",
                f"**User:** {member} ({member.id})\n"
                f"**Reason:** {reason}\n"
                f"**Banned by:** {interaction.user.mention}",
                discord.Color.red()
            )

        except discord.Forbidden:
            await interaction.response.send_message(embed=create_error_embed("Permission Error", "I don't have permission to ban this user."), ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(embed=create_error_embed("Ban Error", f"Failed to ban user: {str(e)}"), ephemeral=True)

    @app_commands.command(name="unban", description="Unban a user by their ID")
    @app_commands.describe(user_id="The user ID to unban", reason="Reason for the unban")
    async def slash_unban_user(self, interaction: discord.Interaction, user_id: str, reason: str = "No reason provided"):
        """Slash command version of unban."""
        # Check admin permissions
        if not interaction.user.guild_permissions.administrator:
            embed = create_error_embed("Permission Denied", "You need the Administrator permission to use this command.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        try:
            user_id_int = int(user_id)
            user = await self.bot.fetch_user(user_id_int)
            await interaction.guild.unban(user, reason=f"Unbanned by {interaction.user}: {reason}")

            embed = create_success_embed(
                "User Unbanned",
                f"**User:** {user} ({user.id})\n"
                f"**Reason:** {reason}\n"
                f"**Unbanned by:** {interaction.user.mention}"
            )
            await interaction.response.send_message(embed=embed)

            # Log the event
            await self.log_security_event(
                interaction.guild,
                "Member Unbanned",
                f"**User:** {user} ({user.id})\n"
                f"**Reason:** {reason}\n"
                f"**Unbanned by:** {interaction.user.mention}",
                discord.Color.green()
            )

        except ValueError:
            await interaction.response.send_message(embed=create_error_embed("Invalid ID", "Please provide a valid user ID."), ephemeral=True)
        except discord.NotFound:
            await interaction.response.send_message(embed=create_error_embed("User Not Found", "User is not banned or doesn't exist."), ephemeral=True)
        except discord.Forbidden:
            await interaction.response.send_message(embed=create_error_embed("Permission Error", "I don't have permission to unban users."), ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(embed=create_error_embed("Unban Error", f"Failed to unban user: {str(e)}"), ephemeral=True)

    @app_commands.command(name="mute", description="Mute a user for a specified duration")
    @app_commands.describe(member="The member to mute", duration="Duration in minutes", reason="Reason for the mute")
    async def slash_mute_user(self, interaction: discord.Interaction, member: discord.Member, duration: int = 60, reason: str = "No reason provided"):
        """Slash command version of mute."""
        # Check admin permissions
        if not interaction.user.guild_permissions.administrator:
            embed = create_error_embed("Permission Denied", "You need the Administrator permission to use this command.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        if member == interaction.user:
            await interaction.response.send_message(embed=create_error_embed("Action Denied", "You cannot mute yourself."), ephemeral=True)
            return
            
        if member.guild_permissions.administrator:
            await interaction.response.send_message(embed=create_error_embed("Action Denied", "Cannot mute administrators."), ephemeral=True)
            return

        if member.top_role >= interaction.user.top_role:
            await interaction.response.send_message(embed=create_error_embed("Action Denied", "Cannot mute users with equal or higher roles."), ephemeral=True)
            return

        try:
            # Calculate mute duration
            mute_until = datetime.utcnow() + timedelta(minutes=duration)
            
            await member.timeout(mute_until, reason=f"Muted by {interaction.user}: {reason}")

            embed = create_success_embed(
                "User Muted",
                f"**User:** {member.mention} ({member})\n"
                f"**Duration:** {duration} minutes\n"
                f"**Reason:** {reason}\n"
                f"**Muted by:** {interaction.user.mention}\n"
                f"**Mute expires:** <t:{int(mute_until.timestamp())}:R>"
            )
            await interaction.response.send_message(embed=embed)

            # Send DM to user
            try:
                dm_embed = discord.Embed(
                    title="🔇 You have been muted",
                    description=f"You were muted in **{interaction.guild.name}**",
                    color=discord.Color.orange()
                )
                dm_embed.add_field(name="Duration", value=f"{duration} minutes", inline=False)
                dm_embed.add_field(name="Reason", value=reason, inline=False)
                dm_embed.add_field(name="Muted by", value=str(interaction.user), inline=False)
                dm_embed.add_field(name="Expires", value=f"<t:{int(mute_until.timestamp())}:R>", inline=False)
                await member.send(embed=dm_embed)
            except discord.Forbidden:
                pass  # User has DMs disabled

            # Log the event
            await self.log_security_event(
                interaction.guild,
                "Member Muted",
                f"**User:** {member} ({member.id})\n"
                f"**Duration:** {duration} minutes\n"
                f"**Reason:** {reason}\n"
                f"**Muted by:** {interaction.user.mention}",
                discord.Color.orange()
            )

        except discord.Forbidden:
            await interaction.response.send_message(embed=create_error_embed("Permission Error", "I don't have permission to timeout this user."), ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(embed=create_error_embed("Mute Error", f"Failed to mute user: {str(e)}"), ephemeral=True)

    @app_commands.command(name="unmute", description="Remove timeout/mute from a user")
    @app_commands.describe(member="The member to unmute", reason="Reason for the unmute")
    async def slash_unmute_user(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
        """Slash command version of unmute."""
        # Check admin permissions
        if not interaction.user.guild_permissions.administrator:
            embed = create_error_embed("Permission Denied", "You need the Administrator permission to use this command.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        try:
            await member.timeout(None, reason=f"Unmuted by {interaction.user}: {reason}")

            embed = create_success_embed(
                "User Unmuted",
                f"**User:** {member.mention} ({member})\n"
                f"**Reason:** {reason}\n"
                f"**Unmuted by:** {interaction.user.mention}"
            )
            await interaction.response.send_message(embed=embed)

            # Send DM to user
            try:
                dm_embed = discord.Embed(
                    title="🔊 You have been unmuted",
                    description=f"Your mute in **{interaction.guild.name}** has been removed",
                    color=discord.Color.green()
                )
                dm_embed.add_field(name="Unmuted by", value=str(interaction.user), inline=False)
                dm_embed.add_field(name="Reason", value=reason, inline=False)
                await member.send(embed=dm_embed)
            except discord.Forbidden:
                pass  # User has DMs disabled

            # Log the event
            await self.log_security_event(
                interaction.guild,
                "Member Unmuted",
                f"**User:** {member} ({member.id})\n"
                f"**Reason:** {reason}\n"
                f"**Unmuted by:** {interaction.user.mention}",
                discord.Color.green()
            )

        except discord.Forbidden:
            await interaction.response.send_message(embed=create_error_embed("Permission Error", "I don't have permission to remove timeout from this user."), ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(embed=create_error_embed("Unmute Error", f"Failed to unmute user: {str(e)}"), ephemeral=True)

    @app_commands.command(name="warn", description="Issue a warning to a user")
    @app_commands.describe(member="The member to warn", reason="Reason for the warning")
    async def slash_warn_user(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
        """Slash command version of warn."""
        # Check admin permissions
        if not interaction.user.guild_permissions.administrator:
            embed = create_error_embed("Permission Denied", "You need the Administrator permission to use this command.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        if member == interaction.user:
            await interaction.response.send_message(embed=create_error_embed("Action Denied", "You cannot warn yourself."), ephemeral=True)
            return

        try:
            # Send warning DM
            dm_embed = discord.Embed(
                title="⚠️ Warning Issued",
                description=f"You have received a warning in **{interaction.guild.name}**",
                color=discord.Color.yellow()
            )
            dm_embed.add_field(name="Reason", value=reason, inline=False)
            dm_embed.add_field(name="Warned by", value=str(interaction.user), inline=False)
            dm_embed.add_field(name="Note", value="Please review the server rules to avoid further warnings.", inline=False)
            
            try:
                await member.send(embed=dm_embed)
                dm_sent = "✅ DM sent"
            except discord.Forbidden:
                dm_sent = "❌ DM failed (user has DMs disabled)"

            embed = create_warning_embed(
                "Warning Issued",
                f"**User:** {member.mention} ({member})\n"
                f"**Reason:** {reason}\n"
                f"**Warned by:** {interaction.user.mention}\n"
                f"**DM Status:** {dm_sent}"
            )
            await interaction.response.send_message(embed=embed)

            # Log the event
            await self.log_security_event(
                interaction.guild,
                "Warning Issued",
                f"**User:** {member} ({member.id})\n"
                f"**Reason:** {reason}\n"
                f"**Warned by:** {interaction.user.mention}",
                discord.Color.yellow()
            )

        except Exception as e:
            await interaction.response.send_message(embed=create_error_embed("Warning Error", f"Failed to issue warning: {str(e)}"), ephemeral=True)

    # Event listeners for anti-raid
    @commands.Cog.listener()
    async def on_member_join(self, member):
        """Monitor member joins for raid detection."""
        guild = member.guild
        settings = self.get_guild_settings(guild.id)

        if not settings.get('anti_raid_enabled', False):
            return

        # Track joins for raid detection
        current_time = datetime.utcnow()

        if guild.id not in self.join_tracking:
            self.join_tracking[guild.id] = []

        self.join_tracking[guild.id].append(current_time)

        # Remove joins older than 1 minute
        self.join_tracking[guild.id] = [
            join_time for join_time in self.join_tracking[guild.id]
            if current_time - join_time < timedelta(minutes=1)
        ]

        # Check if join rate exceeded
        recent_joins = len(self.join_tracking[guild.id])
        if recent_joins >= settings.get('join_rate_limit', 10):
            # Record raid alert
            with app.app_context():
                alert = RaidAlert()
                alert.guild_id = str(guild.id)
                alert.alert_type = 'mass_join'
                alert.user_count = recent_joins
                alert.action_taken = 'lockdown'
                db.session.add(alert)
                db.session.commit()

            # Auto-lockdown
            await self.log_security_event(
                guild,
                "Raid Detected",
                f"Mass join detected: {recent_joins} users in 1 minute\nActivating auto-lockdown",
                discord.Color.red()
            )

            # Activate lockdown
            self.lockdown_status[guild.id] = {
                'end_time': datetime.utcnow() + timedelta(minutes=30),
                'original_perms': {}
            }

            try:
                everyone_role = guild.default_role
                for channel in guild.text_channels:
                    overwrites = channel.overwrites_for(everyone_role)
                    self.lockdown_status[guild.id]['original_perms'][channel.id] = overwrites.send_messages
                    overwrites.send_messages = False
                    await channel.set_permissions(everyone_role, overwrite=overwrites, reason="Auto-lockdown: raid detected")
            except discord.Forbidden:
                pass

    # DISABLED: Commented out to prevent command duplication issues  
    # @commands.Cog.listener()
    async def on_message_disabled(self, message):
        """Monitor messages for spam and suspicious activity. (DISABLED TO FIX DUPLICATION)"""
        if message.author.bot or not message.guild:
            return

        settings = self.get_guild_settings(message.guild.id)

        if not settings.get('anti_raid_enabled', False):
            return

        # Check for mass mentions
        if len(message.mentions) >= settings.get('mass_mention_limit', 5):
            try:
                await message.delete()
                await self.log_security_event(
                    message.guild,
                    "Spam Detected",
                    f"Deleted message with {len(message.mentions)} mentions from {message.author.mention}",
                    discord.Color.orange()
                )

                # Warn the user
                warning_embed = create_warning_embed(
                    "Spam Warning",
                    f"{message.author.mention} Please don't mass mention users."
                )
                await message.channel.send(embed=warning_embed, delete_after=10)

            except discord.Forbidden:
                pass

        # Check for suspicious links
        suspicious_domains = [
            'discord-nitro',
            'steam-community',
            'discord-gift',
            'free-nitro'
        ]

        message_lower = message.content.lower()
        for domain in suspicious_domains:
            if domain in message_lower and 'http' in message_lower:
                try:
                    await message.delete()
                    await self.log_security_event(
                        message.guild,
                        "Suspicious Link",
                        f"Deleted suspicious link from {message.author.mention}: {domain}",
                        discord.Color.red()
                    )

                    

                    break

                except discord.Forbidden:
                    pass

    @commands.Cog.listener()
    async def on_member_update(self, before, after):
        """Monitor member updates for suspicious activity."""
        if before.bot:
            return

        # Check for suspicious nickname changes
        if before.display_name != after.display_name:
            suspicious_terms = ['admin', 'mod', 'owner', 'staff', 'discord']
            new_nick = after.display_name.lower() if after.nick else after.name.lower()

            for term in suspicious_terms:
                if term in new_nick and not after.guild_permissions.administrator:
                    await self.log_security_event(
                        after.guild,
                        "Suspicious Nickname",
                        f"{after.mention} changed nickname to '{after.display_name}' (contains '{term}')",
                        discord.Color.orange()
                    )
                    break


    # Slash Commands
    @app_commands.command(name="lockdown", description="Lock down the server to prevent new joins and messages")
    @app_commands.describe(
        duration="Duration in minutes or 'permanent' for no time limit (default: 10)"
    )
    async def slash_lockdown(self, interaction: discord.Interaction, duration: str = "10"):
        """Slash command for server lockdown."""
        # Check admin permissions
        if not interaction.user.guild_permissions.administrator:
            embed = create_error_embed("Permission Denied", "You need Administrator permissions to use this command.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        if interaction.guild.id in self.lockdown_status:
            await interaction.response.send_message(embed=create_warning_embed("⚠️ Lockdown Status", "Server is already in lockdown mode."), ephemeral=True)
            return

        # Parse duration
        permanent = False
        duration_minutes = 10
        
        if duration.lower() in ['permanent', 'perm', 'forever', 'indefinite', 'no-time']:
            permanent = True
            duration_text = "permanent"
        else:
            try:
                duration_minutes = int(duration)
                duration_text = f"{duration_minutes} minutes"
            except ValueError:
                await interaction.response.send_message(embed=create_error_embed("Invalid Duration", "Use a number for minutes or 'permanent' for no time limit."), ephemeral=True)
                return

        # Store original permissions
        self.lockdown_status[interaction.guild.id] = {
            'end_time': None if permanent else datetime.utcnow() + timedelta(minutes=duration_minutes),
            'original_perms': {},
            'locked_by': interaction.user.id,
            'permanent': permanent
        }

        # Remove send message permissions from @everyone
        try:
            everyone_role = interaction.guild.default_role
            channels_locked = 0
            
            for channel in interaction.guild.text_channels:
                try:
                    overwrites = channel.overwrites_for(everyone_role)
                    self.lockdown_status[interaction.guild.id]['original_perms'][channel.id] = overwrites.send_messages
                    overwrites.send_messages = False
                    await channel.set_permissions(everyone_role, overwrite=overwrites, reason=f"Server lockdown by {interaction.user}")
                    channels_locked += 1
                except discord.Forbidden:
                    continue

            embed = create_warning_embed(
                "🔒 Server Lockdown Activated",
                f"Server is now in **LOCKDOWN MODE** {'permanently' if permanent else f'for **{duration_text}**'}.\n\n"
                f"**🔐 Restrictions Active:**\n"
                f"• {channels_locked} channels locked\n"
                f"• Only administrators can send messages\n"
                f"• New members cannot join voice channels\n\n"
                f"**⏰ Duration:** {'Permanent (manual unlock required)' if permanent else duration_text}\n"
                f"**🚨 Use `/unlock` to end lockdown**"
            )
            embed.set_footer(text=f"Lockdown activated by {interaction.user}")
            await interaction.response.send_message(embed=embed)

            # Log the event
            await self.log_security_event(
                interaction.guild,
                "Server Lockdown",
                f"🔒 **{'PERMANENT ' if permanent else ''}LOCKDOWN ACTIVATED**\n"
                f"• **Activated by:** {interaction.user.mention}\n"
                f"• **Duration:** {duration_text}\n"
                f"• **Channels locked:** {channels_locked}\n"
                f"• **Reason:** Administrative action",
                discord.Color.red()
            )

            # Auto-unlock after duration (only if not permanent)
            if not permanent:
                await asyncio.sleep(duration_minutes * 60)
                if interaction.guild.id in self.lockdown_status:
                    await self.unlock_server(interaction.guild)

        except discord.Forbidden:
            await interaction.response.send_message(embed=create_error_embed("Permission Error", "Missing permissions to modify channel permissions."), ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(embed=create_error_embed("Lockdown Error", f"Error activating lockdown: {str(e)}"), ephemeral=True)

    @app_commands.command(name="emergency-lock", description="Immediately lock the entire server with all restrictions")
    async def slash_emergency_lockdown(self, interaction: discord.Interaction):
        """Slash command for emergency lockdown."""
        # Check admin permissions
        if not interaction.user.guild_permissions.administrator:
            embed = create_error_embed("Permission Denied", "You need Administrator permissions to use this command.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        if interaction.guild.id in self.lockdown_status:
            await interaction.response.send_message(embed=create_warning_embed("⚠️ Lockdown Status", "Server is already in lockdown mode."), ephemeral=True)
            return

        # Store original permissions for comprehensive lockdown
        self.lockdown_status[interaction.guild.id] = {
            'end_time': None,  # Emergency locks are permanent until manually unlocked
            'original_perms': {},
            'original_voice_perms': {},
            'locked_by': interaction.user.id,
            'permanent': True,
            'emergency': True
        }

        try:
            everyone_role = interaction.guild.default_role
            channels_locked = 0
            voice_channels_locked = 0
            
            # Lock all text channels
            for channel in interaction.guild.text_channels:
                try:
                    overwrites = channel.overwrites_for(everyone_role)
                    self.lockdown_status[interaction.guild.id]['original_perms'][channel.id] = {
                        'send_messages': overwrites.send_messages,
                        'add_reactions': overwrites.add_reactions,
                        'create_public_threads': overwrites.create_public_threads,
                        'create_private_threads': overwrites.create_private_threads
                    }
                    overwrites.send_messages = False
                    overwrites.add_reactions = False
                    overwrites.create_public_threads = False
                    overwrites.create_private_threads = False
                    await channel.set_permissions(everyone_role, overwrite=overwrites, reason=f"Emergency lockdown by {interaction.user}")
                    channels_locked += 1
                except discord.Forbidden:
                    continue

            # Lock all voice channels
            for channel in interaction.guild.voice_channels:
                try:
                    overwrites = channel.overwrites_for(everyone_role)
                    self.lockdown_status[interaction.guild.id]['original_voice_perms'][channel.id] = {
                        'connect': overwrites.connect,
                        'speak': overwrites.speak
                    }
                    overwrites.connect = False
                    overwrites.speak = False
                    await channel.set_permissions(everyone_role, overwrite=overwrites, reason=f"Emergency lockdown by {interaction.user}")
                    voice_channels_locked += 1
                except discord.Forbidden:
                    continue

            embed = create_error_embed(
                "🚨 EMERGENCY LOCKDOWN ACTIVATED",
                f"**FULL SERVER LOCKDOWN IN EFFECT**\n\n"
                f"**🔐 Complete Restrictions:**\n"
                f"• {channels_locked} text channels locked\n"
                f"• {voice_channels_locked} voice channels locked\n"
                f"• All messaging disabled\n"
                f"• All voice access disabled\n"
                f"• Thread creation disabled\n"
                f"• Reactions disabled\n\n"
                f"**⚠️ Duration:** PERMANENT - Manual unlock required\n"
                f"**🚨 Use `/unlock` to restore server**"
            )
            embed.set_footer(text=f"Emergency lockdown by {interaction.user}")
            await interaction.response.send_message(embed=embed)

            # Log the event
            await self.log_security_event(
                interaction.guild,
                "EMERGENCY LOCKDOWN",
                f"🚨 **FULL EMERGENCY LOCKDOWN ACTIVATED**\n"
                f"• **Activated by:** {interaction.user.mention}\n"
                f"• **Type:** Complete server lockdown\n"
                f"• **Text channels locked:** {channels_locked}\n"
                f"• **Voice channels locked:** {voice_channels_locked}\n"
                f"• **Status:** Permanent until manual unlock",
                discord.Color.dark_red()
            )

        except discord.Forbidden:
            await interaction.response.send_message(embed=create_error_embed("Permission Error", "Missing permissions to modify channel permissions."), ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(embed=create_error_embed("Emergency Lockdown Error", f"Error activating emergency lockdown: {str(e)}"), ephemeral=True)

    @app_commands.command(name="unlock", description="Remove server lockdown")
    async def slash_unlock_server(self, interaction: discord.Interaction):
        """Slash command to unlock server."""
        # Check admin permissions
        if not interaction.user.guild_permissions.administrator:
            embed = create_error_embed("Permission Denied", "You need Administrator permissions to use this command.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        guild = interaction.guild

        if guild.id not in self.lockdown_status:
            await interaction.response.send_message(embed=create_error_embed("Server is not in lockdown mode."), ephemeral=True)
            return

        await self.unlock_server(guild)

        embed = create_success_embed(
            "🔓 Server Unlocked",
            "Server lockdown has been removed. Normal operations restored."
        )
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="clear", description="Delete messages in a specific channel")
    @app_commands.describe(
        amount="Number of messages to delete (1-100, default: 10)",
        channel="Channel to clear messages from (default: current channel)"
    )
    async def slash_clear_messages(self, interaction: discord.Interaction, amount: int = 10, channel: discord.TextChannel = None):
        """Slash command for clearing messages."""
        # Check admin permissions
        if not interaction.user.guild_permissions.administrator:
            embed = create_error_embed("Permission Denied", "You need Administrator permissions to use this command.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        if channel is None:
            channel = interaction.channel

        if amount < 1 or amount > 100:
            await interaction.response.send_message(embed=create_error_embed("Invalid Amount", "Amount must be between 1 and 100 messages."), ephemeral=True)
            return

        try:
            # For slash commands, we'll defer the response for large deletions
            if amount > 50:
                await interaction.response.defer(ephemeral=True)
                
                # Delete messages
                deleted = await channel.purge(limit=amount, check=lambda m: not m.pinned)
                
                embed = create_success_embed(
                    "Messages Cleared",
                    f"Successfully deleted **{len(deleted)}** messages from {channel.mention}\n"
                    f"**Requested by:** {interaction.user.mention}"
                )
                
                await interaction.followup.send(embed=embed, ephemeral=True)
            else:
                # Delete messages
                deleted = await channel.purge(limit=amount, check=lambda m: not m.pinned)
                
                embed = create_success_embed(
                    "Messages Cleared",
                    f"Successfully deleted **{len(deleted)}** messages from {channel.mention}\n"
                    f"**Requested by:** {interaction.user.mention}"
                )
                
                await interaction.response.send_message(embed=embed, ephemeral=True)

            # Log the event
            await self.log_security_event(
                interaction.guild,
                "Messages Cleared",
                f"**Channel:** {channel.mention}\n"
                f"**Messages deleted:** {len(deleted)}\n"
                f"**Cleared by:** {interaction.user.mention}",
                discord.Color.blue()
            )

        except discord.Forbidden:
            embed = create_error_embed("Permission Error", "I don't have permission to delete messages in that channel.")
            if interaction.response.is_done():
                await interaction.followup.send(embed=embed, ephemeral=True)
            else:
                await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception as e:
            embed = create_error_embed("Clear Error", f"Failed to clear messages: {str(e)}")
            if interaction.response.is_done():
                await interaction.followup.send(embed=embed, ephemeral=True)
            else:
                await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot):
    """Setup function for the cog."""
    await bot.add_cog(SecurityCommands(bot))